#include <iostream>
#include <fstream>
#include "md5.hh"

using namespace std;

main() {

	MD5 tocheck;

	// Should return _3035f1472b39226eb82a95b4ecfa6be4_
	ifstream file("md5.cc");

	tocheck.update(file);
	tocheck.finalize();

	cout << tocheck << endl;
}
