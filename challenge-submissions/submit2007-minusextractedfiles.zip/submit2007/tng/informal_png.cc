// Ideas: one-time hints for matching image separators based on length and 
// width. The first sane header it detects, the one-time hint is removed.
// But one-time hints mean that we may have to scan in multiple passes. Yurgh!

#include "spec.cc"
#include "tree.cc"
#include "rippers.cc"
#include "dummy_dump.cc"
#include "i_png_end_coalesce.cc"
#include "dfs_dumper.cc"

#include <vector>
#include <list>

using namespace std;

#define PNG_CM_DEFLATE 0

class png_initial_header : public specification {

	public:
		png_initial_header(int inst_in);
		bool is_sane(const structured_chunk & to_check, const gi_val
				max_size) const;
};

png_initial_header::png_initial_header(int inst_in) {

	set_type(PNG_INIT_HEADER);
	set_terse("PNG_INIT_HEADER");
	set_verbose("PNG initial signature and header");
	set_inst_code(inst_in);

	string signature = "\x89PNG\r\n\x1A\n";

	add_spec_entry(specification_entry("PNG_signature", signature.size(), 
				SPC_STRING, signature, true, signature, 0));

	add_spec_entry(specification_entry("PNG_chunk_datalen", 4, SPC_INTEGER,
				"", false, "", 0));
	add_spec_entry(specification_entry("PNG_chunk_type", 4, SPC_STRING,
				"", false, "", 0));

	add_spec_entry(specification_entry("PNG_width", 4, SPC_INTEGER, "",
				false, "", 0));
	add_spec_entry(specification_entry("PNG_height", 4, SPC_INTEGER, "",
				false, "", 0));
	add_spec_entry(specification_entry("PNG_bitdepth", 1, SPC_INTEGER, "",
				false, "", 0));
	add_spec_entry(specification_entry("PNG_colortype", 1, SPC_INTEGER, "",
				false, "", 0));
	add_spec_entry(specification_entry("PNG_compression_method", 1,
				SPC_INTEGER, "", false, "", 0));
	add_spec_entry(specification_entry("PNG_filter_type", 1, SPC_INTEGER,
				"", false, "", 0));
	add_spec_entry(specification_entry("PNG_interlace_type", 1, SPC_INTEGER,
				"", false, "", 0));

	add_spec_entry(specification_entry("PNG_CRC32", 4, SPC_INTEGER, "",
				false, "", 0));
	// Really belongs to IHDR
	//DWORD DataLength;   /* Size of Data field in bytes */
	//DWORD Type;         /* Code identifying the type of chunk */

	// DWORD Width;        /* Width of image in pixels */
	// DWORD Height;       /* Height of image in pixels */
	// BYTE BitDepth;      /* Bits per pixel or per sample */
	// BYTE ColorType;     /* Color interpretation indicator */
	// BYTE Compression;   /* Compression type indicator */
	// BYTE Filter;        /* Filter type indicator */
	// BYTE Interlace;     /* Type of interlacing scheme used */
	
	// DWORD Crc;          /* CRC-32 value of the Type and Data fields */
};

bool png_initial_header::is_sane(const structured_chunk & to_check, const
		gi_val max_size) const {
	// TODO: CRC check
	
	// From the specs:
	if (to_check.get_integer("PNG_width") <= 0) return(false);
	if (to_check.get_integer("PNG_height") <= 0) return(false);
	// Width and height > 0
	// BitDepth is one of (1, 2, 4, 8, 16)
	int bitdepth = to_check.get_integer("PNG_bitdepth");
	if (bitdepth != 1 && bitdepth != 2 && bitdepth != 4 && bitdepth != 8 &&
			bitdepth != 16)
		return(false);

	// Colortype is one of (0 (greyscale), 2 (truecolor), 3 (indexed),
	// 	4 (gray+alpha) or 6 (truecolor w/ alpha)).
	//		If grey, then bitdepth is 1,2,4,8,16
	//		If truecolor or w/alpha, then bitdepth is 8,16
	//		If indexed, then bitdepth is 1,2,4,8
	int colortype = to_check.get_integer("PNG_colortype");
	if (colortype != 0 && colortype != 2 && colortype != 3 && colortype !=
			4 && colortype != 6)
		return(false);

	// Compression must be 0 (deflate)
	if (to_check.get_integer("PNG_compression_method") != PNG_CM_DEFLATE)
		return(false);

	// Filter must be 0 (adaptive filter)
	if (to_check.get_integer("PNG_filter_type") != 0)
		return(false);
	// Interlace must be 0 or 1.
	int interlace_type = to_check.get_integer("PNG_interlace_type");
	if (interlace_type != 0 && interlace_type != 1)
		return(false);
	
	return(matches_knowns(to_check) && matches_size(to_check, max_size));
}

class png_palette : public specification {

	public:
		png_palette(int inst_in);
};

// I really hope I don't get this one, or I'll have to rewrite schunk.
// I may have to anyway to account for the interleaving.
png_palette::png_palette(int inst_in) {

	set_type(PNG_PALETTE);
	set_terse("PNG_PALETTE");
	set_verbose("PNG palette chunk");
	set_inst_code(inst_in);

	add_spec_entry(specification_entry("PNG_chunk_datalen", 4, SPC_INTEGER,
				"", false, "", 0));
	add_spec_entry(specification_entry("PNG_chunk_type", 4, SPC_STRING,
				"PLTE", false, "PLTE", 0));
	add_spec_entry(specification_entry("PNG_palette", "PNG_chunk_datalen",
				0, SPC_DATA, "", false, "", 0));
	add_spec_entry(specification_entry("PNG_CRC32", 4, SPC_INTEGER, "",
				false, "", 0));
};

class png_generic_data : public specification {

	public:
		png_generic_data(string chunkname, chunk_id type, 
				string terse_name, string verbose_name, 
				int inst_in);
};

png_generic_data::png_generic_data(string chunkname, chunk_id type,
		string terse_name, string verbose_name, int inst_in) {

	set_type(type);
	set_terse(terse_name);
	set_verbose(verbose_name);
	set_inst_code(inst_in);

	// Nothing more to do here yet..
	add_spec_entry(specification_entry("PNG_chunk_datalen", 4, SPC_INTEGER,
				"", false, "", 0));
	add_spec_entry(specification_entry("PNG_chunk_type", 4, SPC_STRING,
				chunkname, false, chunkname, 0));
	add_spec_entry(specification_entry("PNG_data", "PNG_chunk_datalen",
				0, SPC_DATA, "", false, "", 0));
	add_spec_entry(specification_entry("PNG_CRC32", 4, SPC_INTEGER, "",
				false, "", 0));
};

class png_data : public png_generic_data {

	public:
		png_data(int inst_in) : png_generic_data("IDAT", 
				PNG_IMAGE_DATA, "PNG_IMAGE_DATA", 
				"PNG image data", inst_in) {}
		transform_method identify_data_type(const structured_chunk &
				to_check, string data_key_name) const;
};

transform_method png_data::identify_data_type(const structured_chunk &
		to_check, string data_key_name) const {
	if (data_key_name != "PNG_data") return(TM_UNKNOWN);
	return (TM_GZIP_DEFLATE);
}

class png_trailer : public specification {

	public:
		png_trailer(int instin);
		bool is_sane(const structured_chunk & to_check, const
				gi_val max_size) const;
};

png_trailer::png_trailer(int inst_in) {
	
	set_type(PNG_TRAILER);
	set_terse("PNG_TRAILER");
	set_verbose("PNG end of image chunk");
	set_inst_code(inst_in);

	add_spec_entry(specification_entry("PNG_chunk_datalen", 4, SPC_INTEGER,
				"", false, "", 0));
	add_spec_entry(specification_entry("PNG_chunk_type", 4, SPC_STRING,
				"IEND", false, "IEND", 0));
	add_spec_entry(specification_entry("PNG_data", "PNG_chunk_datalen",
				0, SPC_DATA, "", false, "", 0));
	add_spec_entry(specification_entry("PNG_CRC32", 4, SPC_INTEGER, "",
				false, "", 2923585666U));
};

bool png_trailer::is_sane(const structured_chunk & to_check, const gi_val
		max_size) const {
	if (to_check.get_integer("PNG_chunk_datalen") != 0) return(false);
	// Somehow, the CRC ends up *in front* of the data! This is wrong.
	// (Why didn't I see it before now?)
	// I know, it's because of the data. (Even when the length is zero)
	cout << "RFC: " << to_check.get_integer("PNG_CRC32") << endl;
	cout << "RFCd: " << to_check.get_string("PNG_chunk_type") << endl;
	if (to_check.get_integer("PNG_CRC32") != 2923585666U) return(false);
	return(matches_knowns(to_check) && matches_size(to_check, max_size));
}

//00 00 00  |����o�t.|�w�....|
//00001600  00 49 45 4e 44 ae 42 60  82

// --------------------------------------------------------------------- //

class informal_png_ripper : public ripper {
	private:
		tree<reconstructor_info> * coalescer_guide;
		tree<chunk_id> hierarchy_relation;
		qnd_png_coalescer pngc;

	public:
		informal_png_ripper();
		~informal_png_ripper();
		tree<reconstructor_info> * get_coalescer_guide();
		tree<chunk_id> * get_relation();
};

informal_png_ripper::informal_png_ripper() : hierarchy_relation(NO_TYPE) {

	format_name_short = "PNG";
	format_name_long = "Portable Network Graphics image";
	suggested_field = "PNG_chunk_type";

	unstructured_data_type = PNG_UNSTRUCTURED;

	int inst = 0;
	specs.push_back(new png_initial_header(inst++));
	specs.push_back(new png_palette(inst++));
	specs.push_back(new png_data(inst++));
	//
	//png_data(int inst_in) : png_generic_data("IDAT",
	//  PNG_IMAGE_DATA, "PNG_IMAGE_DATA",
	//  "PNG image data", inst_in) {}
	//	Chunk tpe	multi	optional	position
	//	IHDR		no	no		First
	//	cHRM		no	yes		Before PLTE/IDAT
	//	gAMA		no	yes		Before PLTE/IDAT
	//	sBIT		no	yes		Before PLTE/IDAT
	//	PLTE		no	yes		Before IDAT
	//	bKGD		no	yes		Between PLTE and IDAT
	//	hIST		no	yes		Between PLTE and IDAT
	//	tRNS		no	yes		Between PLTE and IDAT
	//	oFFs		no	yes		Before IDAT
	//	pHYs		no	yes		Before IDAT
	//	sCAL		no	yes		Before IDAT
	//	IDAT		yes	no		Along other IDATs
	//	tIME		no	yes		Any
	//	tEXt		yes	yes		Any
	//	zTXt		yes	yes		Any
	//	fRAc		yes	yes		Any
	//	gIFg		yes	yes		Any
	//	gIFt		yes	yes		Any
	//	gIFx		yes	yes		Any
	//	IEND		no	no		Last chunk

	specs.push_back(new png_generic_data("cHRM", PNG_CHROMA, "PNG_CHROMA",
				"PNG chromacity/white-point data", inst++));
	specs.push_back(new png_generic_data("gAMA", PNG_GAMMA, "PNG_GAMMA",
				"PNG gamma information", inst++));
	specs.push_back(new png_generic_data("sBIT", PNG_SBIT, "PNG_SBIT",
				"PNG significant bits chunk", inst++));
	specs.push_back(new png_generic_data("bKGD", PNG_BACKGROUND, 
				"PNG_BACKGROUND", "PNG background color data", 
				inst++));
	specs.push_back(new png_generic_data("hIST", PNG_HISTORY, "PNG_HISTORY",
				"PNG histogram", inst++));
	specs.push_back(new png_generic_data("tRNS", PNG_TRANS, "PNG_TRANS",
				"PNG transparency data", inst++));
	specs.push_back(new png_generic_data("oFFS", PNG_OFFSET, "PNG_OFFSET",
				"PNG chunk", inst++));
	specs.push_back(new png_generic_data("pHYs", PNG_PHYS, "PNG_PHYS",
				"PNG pixel dimension information", inst++));
	specs.push_back(new png_generic_data("sCAL", PNG_SCALE, "PNG_SCALE",
				"PNG chunk", inst++));
	specs.push_back(new png_generic_data("tIME", PNG_TIME, "PNG_TIME",
				"PNG creation time data", inst++));
	specs.push_back(new png_generic_data("tEXt", PNG_COMMENT, 
				"PNG_COMMENT", "PNG text comment", inst++));
	specs.push_back(new png_generic_data("zTXt", PNG_COMP_COMMENT, 
				"PNG_COMP_COMMENT", "PNG compressed comment", 
				inst++));
	specs.push_back(new png_generic_data("gIFg", PNG_GIFG, "PNG_GIFG",
				"PNG chunk", inst++));
	specs.push_back(new png_generic_data("gIFt", PNG_GIFT, "PNG_GIFT",
				"PNG chunk", inst++));
	specs.push_back(new png_generic_data("gIFx", PNG_CHROMA, "PNG_GIFX",
				"PNG chunk", inst++));

	specs.push_back(new png_trailer(3));

	coalescer_guide = new tree<reconstructor_info>(
			reconstructor_info(PNG_INIT_HEADER, &pngc, NULL));

	file_extractor = auto_ptr<dumper>(new dfs_dumper(PNG_INIT_HEADER));

	has_naive_extractor = false;
};

tree<reconstructor_info> * informal_png_ripper::get_coalescer_guide() {
	return(coalescer_guide);
}

tree<chunk_id> * informal_png_ripper::get_relation() {
	return(&hierarchy_relation);
}

informal_png_ripper::~informal_png_ripper() {

	for(int counter = 0; counter < specs.size(); counter++)
		delete specs[counter];
}
