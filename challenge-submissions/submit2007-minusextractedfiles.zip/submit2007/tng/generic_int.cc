// Generic int: header structure. This int stores the value, and also how much
// space the int actually occupies in the header it's associated with, as well
// as whether it's in LSB or MSB order.

// Limitations: doesn't handle values > 2^31 (because it's an int), though this
// can easily be changed. It's also signed. (Because the size counter is also
// an int, even changing gi_val to infinite precision won't let it go past 
// 2^2^31, but that should be plenty)

#ifndef __GENINT
#define __GENINT

#include "rope.cc"

typedef int gi_val;

class generic_int {

	private:
		gi_val value;
		bool lsb;
		int length;

		// For parsing from a stream
		template<typename inIter> inIter set_value_from_msb(int size_in,
				inIter & input, inIter & end);
		template<typename inIter> inIter set_value_from_lsb(int size_in,
				inIter & input, inIter & end);
		template<typename inIter> inIter set_value_from_raw(int size_in,
				bool lsb_input, inIter & input, inIter & end);

		// And for outputting to it
		// Slightly different pattern because we insert
		template<typename out, typename outIter> outIter dump_msb_value(
				int size_in, out & dest, outIter & start_at) const;
		template<typename out, typename outIter> outIter dump_lsb_value(
				int size_in, out & dest, outIter & start_at) const;
		template<typename out, typename outIter> outIter dump_integer(
				int size_in, bool lsb_output, out & dest, 
				outIter & start_at) const;

		// And this is for streams, because I'm not sure if I can make
		// output ropes; on the other hand, I don't want to sacrifice
		// the generality of the class.
		// Only appends if at the end.
		ostream_iterator<char> streamdump_msb_value(int size_in, 
				ostream_iterator<char> & out) const;
		ostream_iterator<char> streamdump_lsb_value(int size_in,
				ostream_iterator<char> & out) const;

	public:
		void set_integer(gi_val value_in);
		void set_integer(gi_val value_in, int size_in);
		void set_integer(gi_val value_in, int size_in, bool lsb_in);
		void set_size(int size_in);
		void set_lsb(bool lsb_in);
		generic_int();
		generic_int(gi_val value_in);
		generic_int(gi_val value_in, int size_in);
		generic_int(gi_val value_in, int size_in, bool lsb_in);
		// Sets the value by going through the input iterator
		template <typename inIter> inIter set_integer(inIter &
				source, inIter & end, int size_in, bool lsb_in);

		gi_val get_value() const;
		int get_size() const;
		int size() const { return(get_size()); }
		bool is_lsb() const;

		bool operator== (const generic_int & other);

		// Dumps the value as raw output
		// Appends. (Handle both append and replace later.)
		template <typename out, typename outIter> outIter dump(out &
				destination, outIter pos) const;

		ostream_iterator<char> dump_to_stream(ostream_iterator<char> 
				& out) const;
};

// private

template<typename inIter> inIter generic_int::set_value_from_msb(int size_in,
		inIter & input, inIter & end) {
	// For size bytes
	// 	value = (value << 8) + (unsigned char)(next byte)
	
	value = 0;

	inIter pos = input;

	for (int counter = 0; counter < size_in && pos != end; counter++) 
		value = (value << 8) + (unsigned char)(*pos++);
	

	return(pos);
}

template<typename inIter> inIter generic_int::set_value_from_lsb(int size_in,
		inIter & input, inIter & end) {
	// for size bytes
	// 	value = value + (unsigned char)(next byte) << 8*counter
	// A truly good function would just call set_value_from_msb with 
	// reverse_iterators, but I'm not that good.
	
	inIter pos = input;
	value = 0;

	for (int counter = 0; counter < length && pos != end; counter++) 
		value += (int)( (unsigned char)(*pos++) << (8*counter));

	return(pos);
}

template<typename inIter> inIter generic_int::set_value_from_raw(int size_in,
		bool lsb_input, inIter & input, inIter & end) {
	lsb = lsb_input;

	if (lsb_input)
		return(set_value_from_lsb(size_in, input, end));
	else	return(set_value_from_msb(size_in, input, end));
}

template<typename out, typename outIter> outIter generic_int::dump_msb_value(
		int size_in, out & dest, outIter & start_at) const {

	// Just run set_value_from_lsb in reverse. Since "insert" inserts
	// /before/ pos, we actually run in reverse by default.
	
	outIter pos = start_at;

	for (int counter = 0; counter < size_in; counter++)
		pos = start_at.insert(pos, (unsigned char)
				(value >> (8*counter)));

	return (pos + size_in);
}

ostream_iterator<char> generic_int::streamdump_msb_value(int size_in, 
		ostream_iterator<char> & out) const {

	ostream_iterator<char> pos = out;

	// This time it isn't reverse. Confused yet?
	// (Seems a bit ugly... it's really insert's fault up there)
	for (int counter = size_in-1; counter >= 0; counter--)
		*pos++ = (char)(value >> (8*counter));

	return(pos);
}

template<typename out, typename outIter> outIter generic_int::dump_lsb_value(
		int size_in, out & dest, outIter & start_at) const {

	// The other way around
	
	outIter pos = start_at;

	for (int counter = size_in-1; counter >= 0; counter--)
		pos = start_at.insert(pos, (unsigned char)
				(value >> (8*counter)));

	return(pos + size_in);
}

ostream_iterator<char> generic_int::streamdump_lsb_value(int size_in,
		ostream_iterator<char> & out) const {

	ostream_iterator<char> pos = out;

	for (int counter = 0; counter < length; counter++)
		*pos++ = (char)(value >> (8*counter));

	return(pos);
}

template<typename out, typename outIter> outIter generic_int::dump_integer(int
		size_in, bool lsb_output, out & dest, outIter & start_at) const{
	if (lsb_output)
		return(dump_lsb_value(size_in, dest, start_at));
	else	return(dump_msb_value(size_in, dest, start_at));
}

// public

void generic_int::set_integer(gi_val value_in) {
	value = value_in;
}

void generic_int::set_integer(gi_val value_in, int size_in) {
	set_integer(value_in);
	length = size_in;
}

void generic_int::set_integer(gi_val value_in, int size_in, bool lsb_in) {
	set_integer(value_in, size_in);
	lsb = lsb_in;
}

void generic_int::set_size(int size_in) { length = size_in; }
void generic_int::set_lsb(bool lsb_in) {lsb = lsb_in; }

generic_int::generic_int() {
	set_integer(0, 0, true);
}

generic_int::generic_int(gi_val value_in) {
	set_integer(value_in, sizeof(gi_val)/sizeof(char), true);
}

generic_int::generic_int(gi_val value_in, int size_in) {
	set_integer(value_in, size_in, true);
}

generic_int::generic_int(gi_val value_in, int size_in, bool lsb_in) {
	set_integer(value_in, size_in, lsb_in);
}


template <typename inIter> inIter generic_int::set_integer(inIter & source, 
		inIter & end, int size_in, bool lsb_in) {
	set_size(size_in);
	set_lsb(lsb_in);
	return(set_value_from_raw(length, lsb, source, end));
}

gi_val generic_int::get_value() const {
	return(value);
}

int generic_int::get_size() const { return(length); }
bool generic_int::is_lsb() const { return(lsb); }

bool generic_int::operator== (const generic_int & other) {
	return(is_lsb() == other.is_lsb() && get_size() == other.get_size() &&
			get_value() == other.get_value());
}

template <typename out, typename outIter> outIter generic_int::dump(out &
		destination, outIter pos) const {
	if (is_lsb())
		return(dump_lsb_value(get_size(), destination, pos));
	else	return(dump_msb_value(get_size(), destination, pos));
}

ostream_iterator<char> generic_int::dump_to_stream(ostream_iterator<char>
		& destination) const {

	if (is_lsb())
		return(streamdump_lsb_value(get_size(), destination));
	else	return(streamdump_msb_value(get_size(), destination));
}

// UNIT TEST
// ute should be 01 02 03 04 05 06 07 08
// then it reports values of 67305985, 134678021, 16909060, and 84281096
/*
main() {
	file_char_prod * fcp_in = new file_char_prod("ute");
	ofstream out("reconst");
	ostream_iterator<char> os(out), osend();

	//file_char_prod * fcp_out = new file_char_prod("reconst");

	SGI::rope<char> file_in(fcp_in, fcp_in->len(), true);
	//SGI::rope<char> file_out(fcp_out, fcp_out->len(), true);

	generic_int xav;
	SGI::crope::const_iterator pos = file_in.begin();
	pos = xav.set_integer(pos, file_in.end(), 4, true);
	os = xav.dump_to_stream(os);
	cout << "The LSB value is " << xav.get_value() << endl;
	if (xav.is_lsb()) cout << "and it is LSB." << endl;
	cout << "The size is " << xav.get_size() << endl;
	pos = xav.set_integer(pos, file_in.end(), 4, true);
	os = xav.dump_to_stream(os);
	cout << "Then it is " << xav.get_value() << endl;
	pos = file_in.begin();
	pos = xav.set_integer(pos, file_in.end(), 4, false);
	os = xav.dump_to_stream(os);
	cout << "The MSB value is " << xav.get_value() << endl;
	pos = xav.set_integer(pos, file_in.end(), 4, false);
	os = xav.dump_to_stream(os);
	cout << "Then it is " << xav.get_value() << endl;
}
*/

#endif
