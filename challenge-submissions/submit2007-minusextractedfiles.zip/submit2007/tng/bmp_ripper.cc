#include "spec.cc"
#include "tree.cc"
#include "rippers.cc"
#include "dummy_dump.cc"
#include "dfs_dumper.cc"
#include "whole_verifier.cc"

#include <vector>
#include <list>

using namespace std;

class bmp_header : public specification {

	public:
		bool is_sane(const structured_chunk & to_check, const gi_val max_size) const;
		bmp_header(int inst_in);
};

bool bmp_header::is_sane(const structured_chunk & to_check, const
		                gi_val max_size) const {
	// Bitoffbits must be >= 40.
	if (to_check.get_integer("BMP_bitoffbits") < 40) return(false);
	
	return(matches_knowns(to_check) && matches_size(to_check, max_size));
}


bmp_header::bmp_header(int inst_in) {
	set_type(BMP_HEADER);
	set_terse("BMP_HEADER");
	set_verbose("Microsoft Device Independent Bitmap header");
	set_inst_code(inst_in);

	add_spec_entry(specification_entry("BMP_signature", 2, SPC_STRING,
				"BM", true, "BM", 0));
	add_spec_entry(specification_entry("BMP_total_length", 4, SPC_INTEGER,
				"", true, "", 6));
	/*
	add_spec_entry(specification_entry("BMP_reserved_1", 2, SPC_INTEGER,
				"", true, "", 0));
	add_spec_entry(specification_entry("BMP_reserved_2", 2, SPC_INTEGER,
				"", true, "", 0))*/
	string nulls(4, 0);
	add_spec_entry(specification_entry("BMP_reserved", 4, SPC_STRING,
				nulls, true, nulls, 0));
	add_spec_entry(specification_entry("BMP_bitoffbits", 4, SPC_INTEGER,
				"", true, "", 1078));
	// offset of 14
	add_spec_entry(specification_entry("BMP_data", "BMP_total_length", 14,
				SPC_DATA, "", true, "", 0));
};

class bmp_ripper : public ripper {
	private:
		tree<reconstructor_info> * coalescer_guide;
		tree<chunk_id> hierarchy_relation;
		
	public:
		bmp_ripper();
		~bmp_ripper();
		tree<reconstructor_info> * get_coalescer_guide();
		tree<chunk_id> * get_relation() { return(&hierarchy_relation); }
};

bmp_ripper::bmp_ripper() : hierarchy_relation(NO_TYPE) {
	
	format_name_short = "BMP";
	format_name_long = "Microsoft Windows Bitmap/Device Independent Bitmap";
	suggested_field = "BM_length";

	unstructured_data_type = BMP_UNSTRUCTURED;

	int inst = 0;
	specs.push_back(new bmp_header(inst++));

	coalescer_guide = new tree<reconstructor_info>(
			reconstructor_info(BMP_HEADER, NULL, NULL));

	file_extractor = auto_ptr<dumper>(new dfs_dumper(BMP_HEADER));
};

tree<reconstructor_info> * bmp_ripper::get_coalescer_guide() {
	return(coalescer_guide);
}

bmp_ripper::~bmp_ripper() {
	for (int counter = 0; counter < specs.size(); counter++)
		delete specs[counter];

	delete coalescer_guide;
}
