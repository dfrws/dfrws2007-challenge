#ifndef __TRISTATE
#define __TRISTATE

typedef enum comp_dir { 
	TC_LESS = -1, TC_EQUAL = 0, TC_GREATER = 1, TC_NEXIST = -3 };

#endif
