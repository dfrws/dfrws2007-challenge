
// These classes should be rather dumb; the real logic should reside within the
// rippers and coalescers.

// Note that this limits the type of outIters even though chunk et al allows
// any sort of outIter. The problem is that C++ doesn't permit pure virtual
// templated functions.

#ifndef __DUMPERS
#define __DUMPERS

#include <iostream>
#include "detected_headers.h"
#include "tree.cc"
#include "chunk.cc"

using namespace std;

class dumper {

	public:
		virtual chunk_id handles_this_hierarchy() = 0;
		virtual ostream_iterator<char> dump_to_file(const 
				tree<structured_chunk> & to_dump, 
				ostream_iterator<char> start_here) = 0;
};

#endif
