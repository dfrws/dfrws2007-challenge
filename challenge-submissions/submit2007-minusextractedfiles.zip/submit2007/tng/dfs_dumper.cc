#ifndef __PNG_DUMPER
#define __PNG_DUMPER

#include "dump.h"

// Depth first dumper!
// Used for PNG and others; because the coalescer there has done all the hard
// work (or there is only ever one chunk), we just have to travel down the tree
// to dump in depth-first fashion.

class dfs_dumper : public dumper {
	private:
		chunk_id associated_chunk;

	public:
		chunk_id handles_this_hierarchy() { return(associated_chunk); }
		dfs_dumper(chunk_id assoc) { associated_chunk = assoc; }

		ostream_iterator<char> dump_to_file(const 
				tree<structured_chunk> & to_dump, 
				ostream_iterator<char> start_here); 
};

ostream_iterator<char> dfs_dumper::dump_to_file(const tree<structured_chunk> &
		to_dump, ostream_iterator<char> start_here) {

	ostream_iterator<char> current = start_here;

	// First dump the tree's node
	current = to_dump.get_value().dump_to_stream(current);
	// Then dump all subordinates
	for (list<tree<structured_chunk> >::const_iterator pos =
			to_dump.subordinates.begin(); pos != to_dump.
			subordinates.end(); ++pos) 
		current = dump_to_file(*pos, current);

	return(current);
}

#endif
