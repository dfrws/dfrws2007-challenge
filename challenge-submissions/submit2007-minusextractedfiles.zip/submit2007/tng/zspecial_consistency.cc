#ifndef __ZIP_SPECIAL_CONSISTENCY
#define __ZIP_SPECIAL_CONSISTENCY

#include <list>
#include "chunk.cc"
#include "tree.cc"
#include "consistency.h"
#include "slptr.h"
#include <math.h>

using namespace std;

// Could be made into 0.5 N^2 by removing candidates we've already checked.
// Do that later? Worth it?

// TODO: Document the functions (once they work).

class pk_file_footer_hgen : public hypothesis_generator {

	public:

		list<structured_list_ptr> get_potential_candidates(
				list<tree<structured_chunk> > & all,
				structured_list_ptr needle);

		double get_consistency_measure(tree<structured_chunk> & 
				to_check);

		// No need for exclude yet. Or include for that matter.

};

// move all of this into a "special_hypothesis_generator"?
list<structured_list_ptr> pk_file_footer_hgen :: get_potential_candidates(
		list<tree<structured_chunk> > & all, structured_list_ptr 
		needle) {

	list<structured_list_ptr> to_ret;
	for (list<tree<structured_chunk> >::iterator pos = all.begin(); 
			pos != all.end(); ++pos)
		if (pos != needle)
			to_ret.push_back(pos);

	return(to_ret);
}

double pk_file_footer_hgen::get_consistency_measure(tree<structured_chunk> & 
		to_check) {

	if (to_check.subordinates.empty()) return(0);

	// TODO: Do this from the POV of the PK_FILE_FOOTER.
	
	list<tree<structured_chunk> >::iterator first_down = to_check.
		subordinates.end();
	list<tree<structured_chunk> >::iterator sec_down = first_down;
	bool investigate_multi = false;

	cout << "PK_FILE_FOOTER: Checking consistency: ";

	/* First get the required pointers if there is indeed a
	 * DIR_ENTRY/FILE_HEADER/FILE_FOOTER progression. */
	if (to_check.get_value().get_type() == PK_DIR_ENTRY) {
		cout << "A " << flush;
		if (!to_check.subordinates.empty()) {
			first_down = to_check.subordinates.begin();
			if (first_down->get_value().get_type() ==
					PK_FILE_HEADER) {
                                if (!first_down->subordinates.empty()) {
                                        sec_down = first_down->subordinates.
                                                begin();
                                        if (sec_down->get_value().get_type() ==
                                                        PK_FILE_FOOTER)
                                                investigate_multi = true;
                                }
                        }
                }
        }

        if (investigate_multi) {

		cout << " D" << flush;

		// Now check. First, does it have the general bit on?
		// If not, it has no business having a FILE_FOOTER.
		// Second, does it have the same file name? If so, OK, else
		// not. (WEAK.)

		// See if it really is the third bit. Fourth works.

                if (!first_down->get_value().has_integer("PK_general_bitfield"))                        return(NAN);
                if ((first_down->get_value().get_integer("PK_general_bitfield")
                                & 8) == 0) return(NAN);

                cout << " E " << flush;

                if (first_down->get_value().get_string("PK_filename") ==
                                to_check.get_value().get_string("PK_filename")){
			cout << "All clear" << endl;
                        return(1);
		}
                else    return(NAN);
        }

	cout << "Haven't got the faintest. " << endl;
	return(0); // Don't know
}

#endif
