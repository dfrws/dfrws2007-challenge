#ifndef __LOGCOMP_VERIFY
#define __LOGCOMP_VERIFY

#include <iostream>
#include <fstream>
#include <vector>
#include <iterator>
#include <deque>
#include <math.h>

#include "data_verifier.cc"

using namespace std;

class ngram_classifier {
	private:
		unsigned long long total_count;
		unsigned int * counts;
		int sequence;
		unsigned int maxval;
		void load(unsigned long long totcount_in, int sequence_in,
				istream & source);
		void load_old(istream & source, int alt_sequence);
		void load_all(istream & source);
		unsigned int string_to_int(deque<unsigned char> & in, 
				int size) const;

	public:
		ngram_classifier(istream & input);
		ngram_classifier(string input_filename);
		ngram_classifier(string input_filename, bool old, 
				int alt_sequence);
		ngram_classifier(const ngram_classifier & source);
		~ngram_classifier();

		unsigned long long get_total_count() const { 
			return(total_count); }
		int get_sequence_length() const { return(sequence); }
		unsigned int get_maxval() const { return(maxval); }
		unsigned int get_count_for(int index) const;
		template<typename T> unsigned int get_count_for(T & string)
			const;
};

void ngram_classifier::load(unsigned long long totcount_in, int sequence_in,
		istream & source) {
	// Model format is:
	// 1 byte: sequence (the n in n-gram)
	// sizeof(int) bytes: The total count
	// then maxval * sizeof(int) bytes: the counts themselves
	
	// Since totcount_in and sequence_in are given separately, we assume
	// only filling the counts is left.
	
	total_count = totcount_in;
	sequence = sequence_in;
	maxval = 1 << (8 * sequence);

	counts = new unsigned int[maxval];

	source.read((char *)counts, sizeof(int)*maxval);
}

void ngram_classifier::load_old(istream & source, int alt_sequence) {
	// Old format: just the total count and counts data - and the
	// counts are of unsigned int type.
	
	unsigned int totcount_in;
	source.read((char *)&totcount_in, sizeof(unsigned int));
	load(totcount_in, alt_sequence, source);
}

void ngram_classifier::load_all(istream & source) {

	unsigned long long totcount_in;
	unsigned char sequence_in;

	source.read((char *)&sequence_in, 1);
	source.read((char *)&totcount_in, sizeof(totcount_in));
	load(totcount_in, sequence_in, source);
}

unsigned int ngram_classifier::string_to_int(deque<unsigned char> & in, 
		int size) const {
        unsigned int toRet = 0;

        for (int p = 0; p < size; p++)
		toRet = (toRet << 8) + (unsigned char) in[p];

        return(toRet);
}

ngram_classifier::ngram_classifier(istream & input) {
	load_all(input);
}

ngram_classifier::ngram_classifier(string input_filename) {
	ifstream ifile(input_filename.c_str());

	if (!ifile) {
		cerr << "Cannot open n-gram model file " << input_filename
			<< endl;
		exit(-1);
	}

	load_all(ifile);
	ifile.close();
}

ngram_classifier::ngram_classifier(string input_filename, bool old,
		int alt_sequence) {
	ifstream ifile(input_filename.c_str());

	if (!ifile) {
		cerr << "Cannot open n-gram model file " << input_filename
			<< endl;
		exit(-1);
	}

	if (!old)
		load_all(ifile);
	else	load_old(ifile, alt_sequence);

	ifile.close();
}

ngram_classifier::~ngram_classifier() {
	delete[] counts;
}

ngram_classifier::ngram_classifier(const ngram_classifier & source) {
	   total_count = source.total_count;
	   sequence = source.sequence;
	   maxval = source.maxval;
	   counts = new unsigned int[maxval];
	   copy (source.counts, source.counts+maxval, counts);
}

unsigned int ngram_classifier::get_count_for(int index) const {
	if (index < 0 || index > maxval) return(0);

	return (counts[index]);
}

template<typename T> unsigned int ngram_classifier::get_count_for(
		T & string) const {
	return (get_count_for(string_to_int(string, min(string.size(),
						(size_t)sequence))));
}

class ngram_verifier : public data_verifier {

	private:
		template<typename inIter> double get_lognormal_score(inIter
				start_at, const inIter end, inIter & curpos,
				const ngram_classifier & classifier) const;

		ngram_classifier model;
		transform_method type, prereq;

	public:
		ngram_verifier(const string input_model_filename, const
				transform_method type_in, transform_method
				prerequisite);
		bool sufficient_prerequisite(const 
				transform_method prerequisite) const;
		transform_method get_method_handled() const { return(type); }
		data_certificate verify_data(data_iterator beginning, 
				data_iterator pos, data_iterator end,
				int max_length, double ancestral_score) const;
};

/* This function returns > 0 if it believes the data can be classified under
 the classifier corresponding to that column, otherwise < 0. The threshhold
 is based on the results that fitting to a purely random model would give,
 but it isn't infallible; it's much better at saying "it fits A better than B"
 than "it fits A, but not B". This is probably due to that each model works
 in isolation; it doesn't consider the others, which is counterintuitive
 (since having lots of other models should decrease the chance that this
 particular one is the one that fits.) */

// If wishes were horses, I'd have a PPM classifier here. Or if I *had* to
// stick with n-grams, I'd use k-means to select subsets of the documents
// to minimize the error rate, and separate for beginning/end/middle too.
// So many ideas, so little time.

template<typename inIter> double ngram_verifier::get_lognormal_score(inIter 
		start_at, const inIter end, inIter & curpos, const 
		ngram_classifier & classifier) const {

	deque<unsigned char> window;
	int gramcount = 0;

	double log_probability = 0;

	for (curpos = start_at; curpos != end; ++curpos) {
		window.push_back(*curpos);

		while (window.size() > classifier.get_sequence_length())
			window.pop_front();

		if (window.size() != classifier.get_sequence_length()) 
			continue;

		gramcount++;
		// Calculate the logarithm of the probability using
		// Laplace's rule of succession.
		unsigned int count_here = 1 + classifier.get_count_for(window);
		long double pcount = count_here/(double)(classifier.
				get_total_count()+2);

		log_probability += log(pcount);
	}

	// Calculate the logarithm of the probability for a single n-gram, as 
	// well as the expected logarithm given a random model; the result
	// is the latter subtracted from the former.
	double uniform_count = 1 + (classifier.get_total_count()/(double)
			classifier.get_maxval());
	double randomness = log(uniform_count/(classifier.get_total_count() 
				+ 2));
	double current = log_probability/(double)gramcount;

	return(current - randomness);
}

ngram_verifier::ngram_verifier(const string input_model_filename, const 
		transform_method type_in, const transform_method 
		prerequisite) : model(input_model_filename) {

	prereq = prerequisite;
	type = type_in;
}

bool ngram_verifier::sufficient_prerequisite(const transform_method 
		prerequisite) const {
	return(prerequisite == prereq);
}

data_certificate ngram_verifier::verify_data(data_iterator beginning, 
		data_iterator pos, data_iterator end, int max_length,
		double ancestral_score) const {

	data_certificate guess;
	data_iterator curpos = pos;
	if (end-pos > max_length)
		guess.score = get_lognormal_score(pos, pos+max_length,
				curpos, model);
	else
		guess.score = get_lognormal_score(pos, end, curpos, model);

	guess.break_location = -1;
	if (guess.score > 0) guess.outcome = VO_SUCCESS;
	else guess.outcome = VO_FAIL;

	// Now map -inf..0 to -1..0 and 0..inf to 0..1
	// Reduce this to the problem of mapping 0..inf to 0..1:
	// 	1- 1/(1 + whatever). For 0, we get 1 - 1/1 = 1 - 1 = 0
	// 	For inf, we get 1 - 1/(inf+1) = 1 - 1/inf = 1 - 0 = 1.
	
	double abscore = copysign(1 - 1.0/(1 + fabs(guess.score)), guess.score);
	guess.score = compound_score(ancestral_score, abscore);

	return(guess);
}

#endif
