#ifndef __OCCUPANCY
#define __OCCUPANCY

#include <vector>
#include <iostream>
#include <assert.h>

using namespace std;

// Will be used when we move from ropes.

// TODO: "CDF" so that we can use iterators in a transparent fashion.
// Ropes could work, but the iterators don't conserve, so it's a pain.

// TODO: Use advance when marking as used. For this reason, don't require
// beginning, pos, and end, but just pos and length (because we don't know
// where end will be).

// No indirect addressing.

class file_occupancy {

	private:
		// Should be vector<short> but the grinding, oh the grinding!
		vector<char> occupied_by;

	public:
		file_occupancy(unsigned int file_length);
		int advance(int location, int our_type) const;
		int count_between(int start_pos, int end_pos,
				int our_type) const;
		template<typename inIter> int count_between(inIter beginning,
				inIter start_pos, inIter end_pos, inIter end,
				int our_type) const;
		template<typename inIter> inIter advance(inIter beginning,
				inIter pos, inIter end, int & 
				actually_advanced, int our_type) const;
		void mark_as_used(int offset_start, int offset_end, int type);
		int is_occupied_by(unsigned int offset) const;
		template<typename inIter> int is_occupied_by(inIter beginning,
				inIter position, inIter end) const;
		int occupied_bytes() const;
		template<typename inIter> bool is_completely_occupied(inIter
				beginning, inIter position, inIter end,
				int length) const;
};

file_occupancy::file_occupancy(unsigned int file_length) {
	occupied_by.resize(file_length, -1); // SPACE HOG, BEWARE
};

int file_occupancy::advance(int location, int our_type) const {
	int initial_location = location;

	assert((size_t)initial_location < occupied_by.size());
	// Off by one error present with ++location? Check.. Nah.

	do {
		++location;
		if (location < occupied_by.size()) {
	//		cout << location << " occupied by " << is_occupied_by(location) << " against " << our_type << endl;
			if (is_occupied_by(location) == our_type ||
					is_occupied_by(location) == -1) break;
		}
	} while (location < occupied_by.size());

	return(location - initial_location);
}

template<typename inIter> inIter file_occupancy::advance(inIter beginning,
		inIter pos, inIter end, int & actually_advanced, int 
		our_type) const {

	actually_advanced = advance(pos-beginning, our_type);

	return(pos + actually_advanced);
}

int file_occupancy::count_between(int start_pos, int end_pos, 
		int our_type) const {
	// Not so slow
	int relevant_bytes = 0;
	for (int counter = start_pos; counter < end_pos; counter++) {
		if (is_occupied_by(counter) == -1 || is_occupied_by(counter)
				== our_type) relevant_bytes++;
	}
	
	return(relevant_bytes);
}

template<typename inIter> int file_occupancy::count_between(inIter beginning, 
		inIter start_pos, inIter end_pos, inIter end, 
		int our_type) const {
	// SLOW!
	int relevant_bytes = 0;
	while (start_pos < end_pos) {
		start_pos = advance(beginning, start_pos, end, our_type);
		relevant_bytes++;
	}
	
	return(relevant_bytes);
}

void file_occupancy::mark_as_used(int offset_start, int offset_end, int type) {
	cout << "Marking " << offset_start << " to " << offset_end << " as used by " << type << endl;
	for (int counter = offset_start; counter < offset_end; counter++)
		if (is_occupied_by(counter) == -1)
			occupied_by[counter] = type;
}

int file_occupancy::is_occupied_by(unsigned int offset) const {
	//cout << offset << "\t" << occupied_by.size() << endl;
	return(occupied_by[offset]);
}

template<typename inIter> int file_occupancy::is_occupied_by(inIter beginning,
		inIter position, inIter end) const {
	return(is_occupied_by(position-beginning));
}

int file_occupancy::occupied_bytes() const {

	int so_far = 0;

	for (size_t counter = 0; counter < occupied_by.size(); ++counter)
		if (is_occupied_by(counter) != -1) ++so_far;

	return(so_far);
}

template<typename inIter> bool file_occupancy::is_completely_occupied(inIter
		beginning, inIter position, inIter end, int length) const {

	//cout << "Checking between " << position-beginning << " and " << (position-beginning) + length << endl;

	int start_off = position-beginning;

	for (int counter = start_off; counter < start_off + length && counter <
			occupied_by.size(); ++counter)
		if (is_occupied_by(counter) == -1) {
	//		cout << "IOC detected false at " << counter << endl;
			return(false);
		}

	return(true);
}

#endif
