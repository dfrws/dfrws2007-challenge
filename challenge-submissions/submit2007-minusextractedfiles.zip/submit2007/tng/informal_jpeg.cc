#include "spec.cc"
#include "tree.cc"
#include "rippers.cc"
#include "dummy_dump.cc"
#include "whole_verifier.cc"

#include <vector>
#include <list>

// If the DFRWS pictures have different sizes, we'll be in luck, because each
// APP0 header seems to contain information about the size. Hm.

using namespace std;

class jpeg_appzero_header : public specification {

	public:
		jpeg_appzero_header(bool with_soi, int inst_in);

};

jpeg_appzero_header::jpeg_appzero_header(bool with_soi, int inst_in) {

	set_type(JPEG_APPZERO_HEADER);
	set_terse("JPEG_APPZERO_HEADER");
	set_verbose("JFIF-conforming JPEG header");
	set_inst_code(inst_in);

	if (with_soi)
		add_spec_entry(specification_entry("JPG_SOI_marker", 2, 
					SPC_STRING, "\xFF\xD8", true, 
					"\xFF\xD8", 0));

	string identifier = "JFIF?";
	identifier[4] = '\0';

	add_spec_entry(specification_entry("JPG_APP0_marker", 2, SPC_STRING,
				"\xFF\xE0", true, "\xFF\xE0", 0));
	add_spec_entry(specification_entry("JPG_APP0_length", 2, SPC_INTEGER,
				"", false, "", 0));
	add_spec_entry(specification_entry("JPG_JFIF_identifier", identifier,
				identifier));
	add_spec_entry(specification_entry("JPG_version", 2, SPC_INTEGER,
				"", false, "", 0));
	add_spec_entry(specification_entry("JPG_units", 1, SPC_INTEGER, "",
				false, "", 0));
	add_spec_entry(specification_entry("JPG_width", 2, SPC_INTEGER, "",
				false, "", 0));
	add_spec_entry(specification_entry("JPG_height", 2, SPC_INTEGER, "",
				false, "", 0));
	add_spec_entry(specification_entry("JPG_thumbnail_width", 2, 
				SPC_INTEGER, "", false, "", 0));
	add_spec_entry(specification_entry("JPG_thumbnail_height", 2,
				SPC_INTEGER, "", false, "", 0));

	// actual thumbnail data here?

	//BYTE SOI[2];          /* 00h  Start of Image Marker     */
	//BYTE APP0[2];         /* 02h  Application Use Marker    */
	//BYTE Length[2];       /* 04h  Length of APP0 Field      */
	//BYTE Identifier[5];   /* 06h  "JFIF" (zero terminated) Id String */
	//BYTE Version[2];      /* 07h  JFIF Format Revision      */
	//BYTE Units;           /* 09h  Units used for Resolution */
	//BYTE Xdensity[2];     /* 0Ah  Horizontal Resolution     */
	//BYTE Ydensity[2];     /* 0Ch  Vertical Resolution       */
	//BYTE XThumbnail;      /* 0Eh  Horizontal Pixel Count    */
	//BYTE YThumbnail;      /* 0Fh  Vertical Pixel Count      */
};

class jpeg_appone_header : public specification {

	        public:
			jpeg_appone_header(bool with_soi, int inst_in);

};

jpeg_appone_header::jpeg_appone_header(bool with_soi, int inst_in) {
	// Includes TIFF data, which we'll have to get from another ripper.
	
	set_type(JPEG_APPONE_HEADER);
	set_terse("JPEG_APPONE_HEADER");
	set_verbose("Exif APP1 JPEG header");
	set_inst_code(inst_in);

	if (with_soi)
		add_spec_entry(specification_entry("JPG_SOI_marker", 2,
					SPC_STRING, "\xFF\xD8", true,
					"\xFF\xD8", 0));

	string identifier = "Exif?";
	identifier[4] = '\0';

	add_spec_entry(specification_entry("JPG_APP0_marker", 2, SPC_STRING,
				"\xFF\xE1", true, "\xFF\xE1", 0));
	add_spec_entry(specification_entry("JPG_APP0_length", 2, SPC_INTEGER,
				"", false, "", 0));
	add_spec_entry(specification_entry("JPG_EXIF_ientifier", identifier,
				identifier));
	// data comes here
};


class informal_jpg_ripper : public ripper {
	private:
		tree<reconstructor_info> * coalescer_guide;
		tree<chunk_id> hierarchy_relation;
		whole_verifier * jpg_file_verifier;

	public:
		informal_jpg_ripper();
		~informal_jpg_ripper();
		tree<reconstructor_info> * get_coalescer_guide();
		tree<chunk_id> * get_relation() { return(&hierarchy_relation); }
};


informal_jpg_ripper::informal_jpg_ripper() : hierarchy_relation(NO_TYPE) {

	format_name_short = "JPG";
	format_name_long = "JPEG File Interchange Format image";
	suggested_field = "JPG_height";

	unstructured_data_type = JPEG_UNSTRUCTURED;

	int inst = 0;
	specs.push_back(new jpeg_appzero_header(true, inst++));
	specs.push_back(new jpeg_appzero_header(false, inst++));
	specs.push_back(new jpeg_appone_header(true, inst++));
	specs.push_back(new jpeg_appone_header(false, inst++));

	coalescer_guide = new tree<reconstructor_info>(
			reconstructor_info(JPEG_APPZERO_HEADER, NULL, NULL));

	file_extractor = auto_ptr<dumper>(new dummy_dumper);

	jpg_file_verifier = new file_verifier("temp", "djpeg", 32512, true);
	simple_extract = auto_ptr<naive_extractor>(new naive_extractor(
				jpg_file_verifier, JPEG_APPZERO_HEADER));
	has_naive_extractor = true;
	max_data_size = 6000000;
	average_data_size = 100000;

}

tree<reconstructor_info> * informal_jpg_ripper::get_coalescer_guide() {
	return(coalescer_guide);
}

informal_jpg_ripper::~informal_jpg_ripper() {
	for (int counter = 0; counter < specs.size(); counter++)
		delete specs[counter];

	delete coalescer_guide;
}
