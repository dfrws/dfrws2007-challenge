#include <iostream>
#include <ext/rope>
#include "generic_int.cc"
#include "detected_headers.h"
#include "tristate.h"
#include "data_verifier.cc"
#include "priority.cc"

#ifndef __CHUNK
#define __CHUNK

using namespace std;
namespace SGI = ::__gnu_cxx;

// Chunk. This is a generalization of a header (might be footer as well),
// basically a length of structured data. To keep the fields as malleable as
// possible, we have three possible field types: string, int, and data 
// (iterator, length pair).
// No two fields may be given the same key, even if this is technically
// possible. The class now enforces this.

// BLUESKY: Each data has a "type designator" set. Validation functions return
// how likely it is that the data is of each type.

// We also need some way of handling interleaving here.

// TODO: Bits instead of bytes (to handle bit fields).
template<typename T> class data_container {
	public:
		data_container() {}
		data_container(T start_in, T container_end_in, int length_in, 
				transform_method type_in) {
			start = start_in;
			length = length_in;
			data_type = type_in;
			container_end = container_end_in;
		}
		bool operator==(const data_container<T> & other) const {
			return (start == other.start && length == other.length);
		}
		bool operator<(const data_container<T> & other) const {
			return (start < other.start || length < other.length);
		}
		bool operator>(const data_container<T> & other) const {
			return (start > other.start || length > other.length);
		}
		size_t size() const { return(length); }
		T start;
		size_t length;
		T container_end;
		transform_method data_type;
}; 

typedef class unique_field_address {
	public:
		chunk_id type;
		string key_name;
		bool operator < (const unique_field_address & other) const {
			if (type < other.type) return(true);
			if (type == other.type && key_name < other.key_name)
				return(true);
			return(false);
		}
};

const int SC_NO_LOCATION = -1;	// location is set to this if the chunk has been
				// reconstructed
const int SC_NO_VALUE = -2;
//const int SC_LESS = -1, SC_EQUAL = 0, SC_GREATER = 1, SC_NEXIST = -3;

typedef enum field_type { SC_FT_STRING, SC_FT_INTEGER, SC_FT_DATA, SC_FT_NONE };

typedef SGI::crope data_type;
typedef data_type::const_iterator data_iterator;

class structured_chunk {

	private:
		data_type null_data; // for returning NO_VALUE data
		data_type unknown_data; // see above, only for data where
					// we don't know what the actual data 
					// is.
		// Use pointers because of parameter constructors
		// Maybe make null_value unneeded by priority map to clear
		// up this mess?
		priority_map<string> * string_fields;
		priority_map<generic_int> * int_fields;
		priority_map<data_container<data_iterator> > * data_fields;
		int last_priority;
		long long location;
		chunk_id type;
		int instantiated; // instantiation code - index to array of
				  // specifications. We can't use type because
				  // we might have more than one copy of the
				  // same spec. Instation codes aren't 
				  // necessarily unique either.
		int uid;

		void init_field_containers(); // NO ERROR CHECKING
		void deepcopy(const structured_chunk & source, 
				bool already_allocated);

		template<typename PMapType> bool set_generic(string key, 
				const PMapType & src, priority_map<PMapType> &
				dest, field_type own_field_type);

		// -1 is less, 0 is equal, 1 is greater
		template<typename T> comp_dir get_matching_direction(const T & 
				a, const T & b) const;

	public:
		field_type get_field_type(string key) const;
		// get_field_type is used for collision detection and for 
		// matches(), and to call only one of has_* for speed purposes.
		void set_references(long long loc, chunk_id type_in);
		structured_chunk(int uid_in);
		structured_chunk(const structured_chunk & source);
		structured_chunk & operator=(const structured_chunk & source);
		~structured_chunk();
		structured_chunk(int uid_in, chunk_id type_in);
		structured_chunk(int uid_in, int inst_code, long long loc, 
				chunk_id type_in);

		chunk_id get_type() const;
		int get_inst_code() const { return(instantiated); }
		void set_type(chunk_id type_in) { type = type_in; }
		void set_inst_code(int inst_code) { instantiated = inst_code; }
		long long get_location() const;
		int get_unique_id() const { return(uid); }

		// from literals
		bool set_string(string key, string value);
		bool set_gen_integer(string key, generic_int value);
		bool set_integer(string key, gi_val value, bool is_lsb, 
				int size);
		bool set_data(string key, data_container<data_iterator> value);
		bool set_data(string key, data_iterator position, data_iterator
				container_end, int length, transform_method 
				data_type);
		bool set_null_data(string key);
		bool set_undiscovered_data(string key, int length);

		// from iterators
		template<typename inIter> inIter set_string(string key, 
				inIter & source, inIter & end, int length);
		template<typename inIter> inIter set_integer(string key, 
				inIter & source, inIter & end, bool is_lsb, 
				int length);

		bool has_string(string key) const;
		bool has_integer(string key) const;
		bool has_data(string key) const;
		bool has_defined_field(string key) const;

		// For all others, we have set_*
		bool update_integer(string key, gi_val value);

		string get_string(string key) const;
		generic_int get_gen_integer(string key) const;
		gi_val get_integer(string key) const;
		data_container<data_iterator> get_data(string key) const;
		data_iterator get_data_location(string key) const;
		data_iterator get_data_container_end(string key) const;
		bool is_undiscovered_data(string key) const;
		int get_data_length(string key, bool count_padding) const;
		int get_data_length(string key) const;
		transform_method get_data_type(string key) const;

		int get_field_length(string key) const;

		// Perhaps this should be a set, to emphasize that it's not
		// ordered?
		list<string> get_field_names(field_type type_wanted) const;
		list<string> get_field_names() const; 

		// Returns true if we have the same value for key as the
		// other structured chunk has.
		// Returns -1 for less, 0 for equal, and 1 for greater, -3
		// means the key doesn't exist so we can't make a comparison. 
		// Boolean versions just return true for equal and false for not
		comp_dir matches_int(const structured_chunk & other, 
				string key, string others_key) const;
		comp_dir matches_int(const structured_chunk & other, string 
				key) const;
		bool matches(const structured_chunk & other, string key,
				string others_key) const;
		bool matches(const structured_chunk & other, string key)
			const;

		bool copy_key(string others_key, const structured_chunk & 
				other, string target_keyname);
		// Linear time. If count_data is true, data fields count 
		// according to their length parameters, i.e how much space
		// would be occupied by a dump.
		int size(bool count_data) const;
		int size() const;

		// TODO: Perhaps a "default data" here? Or just use nulls?
		ostream_iterator<char> dump_to_stream(ostream_iterator<char> 
				destination) const;

};

void structured_chunk::init_field_containers() {
	string_fields = new priority_map<string>("");
	int_fields = new priority_map<generic_int>(SC_NO_VALUE);

	// Conditional jump or move depends on uninitialized value(s)
	// (Haven't defined null!)
	data_container<data_iterator> null_val;
	null_val.length = 0;
	null_val.start = null_data.begin();
	null_val.container_end = null_data.end();
	data_fields = new priority_map<data_container<data_iterator> >
		(null_val);
}

void structured_chunk::set_references(long long loc, chunk_id type_in) {
        location = loc;
        type = type_in;
}

structured_chunk::structured_chunk(int uid_in) {
	uid = uid_in;
	init_field_containers();
	set_references(SC_NO_LOCATION, NO_TYPE);
	last_priority = 0;
	instantiated = -1;

	null_data = SGI::crope("null");
	unknown_data = SGI::crope("--UNRECOVERED--");
}

structured_chunk::structured_chunk(int uid_in, chunk_id type_in) {
	set_references(SC_NO_LOCATION, type_in);
	init_field_containers();
	last_priority = 0;
	instantiated = -1;
	uid = uid_in;

	null_data = SGI::crope("null");
	unknown_data = SGI::crope("--UNRECOVERED--");
}

structured_chunk::structured_chunk(int uid_in, int inst_code, long long loc, 
		chunk_id type_in) {
	uid = uid_in;
	set_references(loc, type_in);
	last_priority = 0;
	instantiated = inst_code;

	null_data = SGI::crope("null");
	unknown_data = SGI::crope("--UNRECOVERED--");

	init_field_containers();

}

structured_chunk::~structured_chunk() {
	delete string_fields;
	delete int_fields;
	delete data_fields;
}

void structured_chunk::deepcopy(const structured_chunk & from, bool
		already_allocated) {
	// copy by value
	if (already_allocated) {
		*int_fields = *from.int_fields;
		*string_fields = *from.string_fields;
		*data_fields = *from.data_fields;
	} else {
		int_fields = new priority_map<generic_int>(*from.int_fields);
		string_fields = new priority_map<string>(*from.string_fields);
		data_fields = new priority_map<data_container<data_iterator> >(
							*from.data_fields);
	}

	// This invalidates data_field's null value, so make a new one
	data_container<data_iterator> null_val;
	null_val.length = 0;
	null_val.start = null_data.begin();
	null_val.container_end = null_data.end();
	data_fields->set_null_value(null_val);

	// Then copy the rest
	set_references(from.get_location(), from.get_type());
	last_priority = from.last_priority;
	instantiated = from.instantiated;

	null_data = from.null_data;
	unknown_data = from.unknown_data;
	uid = from.uid;
}

structured_chunk::structured_chunk(const structured_chunk & source) {
	deepcopy(source, false);
}

structured_chunk & structured_chunk::operator=(const structured_chunk & source){
	// Don't copy if it's ourselves
	if (&source != this)
		deepcopy(source, true);
	return (*this);
}

chunk_id structured_chunk::get_type() const { return(type); }
long long structured_chunk::get_location() const { return(location); }

// These all follow the same pattern: if the key's already there, increment
// last priority for the new field. Otherwise, don't change it as it's not
// going to be used anyway. 

// If there's a key that corresponds to a field that isn't our own, abort.
// Otherwise, if there's a field of our own, update it, else add a new one.
template<typename PMapType> bool structured_chunk::set_generic(string key,
		const PMapType & src, priority_map<PMapType> & dest, field_type
		own_field_type) {
	field_type for_key = get_field_type(key);

	if (for_key != SC_FT_NONE && for_key != own_field_type) return(false);

	if (!dest.has_key(key)) 
		dest.append(key, src, ++last_priority);
	else	dest.update_value(key, src);

	return(true);
}

template<typename T> comp_dir structured_chunk::get_matching_direction(const T 
		& a, const T & b) const {
	if (a < b) return(TC_LESS);
	if (a > b) return(TC_GREATER);
	return(TC_EQUAL);
}


// Perhaps make an additional map for this, for speed purposes
// Nah, not worth it.
field_type structured_chunk::get_field_type(string key) const {
	if (has_integer(key)) return(SC_FT_INTEGER);
	if (has_string(key)) return(SC_FT_STRING);
	if (has_data(key)) return(SC_FT_DATA);
	return(SC_FT_NONE);
}

bool structured_chunk::set_string(string key, string value) {
	return(set_generic(key, value, *string_fields, SC_FT_STRING));
}

bool structured_chunk::set_gen_integer(string key, generic_int value) {
	return(set_generic(key, value, *int_fields, SC_FT_INTEGER));
}

bool structured_chunk::set_integer(string key, gi_val value, bool is_lsb, int
		size) {
	return(set_generic(key, generic_int(value, size, is_lsb), *int_fields,
				SC_FT_INTEGER));
}

bool structured_chunk::set_data(string key, data_container<data_iterator> 
		value) {
	return(set_generic(key, value, *data_fields, SC_FT_DATA));
}

// NOTE: Won't handle interfile chunks (e.g if the file to search contain two
// zip files A and B, A has a data field of the wrong size, then the padding
// won't be UNRECOVERED, it'll be B). Even if we could use data verifiers to
// find the unrecovered points, there'd be no way of communicating them here.
// Maybe later?
bool structured_chunk::set_data(string key, data_iterator position, 
		data_iterator container_end, int length, 
		transform_method data_type) {
	return(set_data(key, data_container<data_iterator>(position, 
					container_end, length, data_type)));
}

bool structured_chunk::set_null_data(string key) {
	return(set_data(key, null_data.begin(), null_data.end(), 0, 
				TM_UNKNOWN));
}

bool structured_chunk::set_undiscovered_data(string key, int length) {
	return(set_data(key, unknown_data.begin(), unknown_data.end(), length, 
				TM_UNKNOWN));
}

template<typename inIter> inIter structured_chunk::set_string(string key, 
		inIter & source, inIter & end, int length) {
	string to_add;
	to_add.resize(length);
	inIter pos = source;
	for (int counter = 0; counter < length && pos != end; counter++)
		to_add[counter] = *pos++;

	set_string(key, to_add);

	return(pos);
}

// TODO: some way of failing safe if we can't read the value. We can't use
// if pos_after == end because the value could be at the end.

template<typename inIter> inIter structured_chunk::set_integer(string key,
		inIter & source, inIter & end, bool is_lsb, int length) {

	generic_int to_add;
	inIter pos_after = to_add.set_integer(source, end, length, is_lsb);

	set_generic(key, to_add, *int_fields, SC_FT_INTEGER);

	return(pos_after);
}

bool structured_chunk::has_string(string key) const { 
	return (string_fields->has_key(key));
}

bool structured_chunk::has_integer(string key) const {
	return(int_fields->has_key(key));
}

bool structured_chunk::has_data(string key) const {
	return(data_fields->has_key(key));
}

bool structured_chunk::has_defined_field(string key) const {
	return (get_field_type(key) != SC_FT_NONE);
}

bool structured_chunk::update_integer(string key, gi_val value) {
	if (!has_integer(key)) return(false);

	generic_int to_modify = int_fields->get_by_key(key);
	to_modify.set_integer(value);
	int_fields->update_value(key, to_modify);
	return(true);
}

string structured_chunk::get_string(string key) const {
	return(string_fields->get_by_key(key));
}

generic_int structured_chunk::get_gen_integer(string key) const {
	return(int_fields->get_by_key(key));
}

gi_val structured_chunk::get_integer(string key) const {
	return (get_gen_integer(key).get_value());
}

data_container<data_iterator> structured_chunk::get_data(string key) const {
	return (data_fields->get_by_key(key));
}

data_iterator structured_chunk::get_data_location(string key) const {
	return(get_data(key).start);
}

data_iterator structured_chunk::get_data_container_end(string key) const {
	return(get_data(key).container_end);
}

transform_method structured_chunk::get_data_type(string key) const {
	return(get_data(key).data_type);
}

bool structured_chunk::is_undiscovered_data(string key) const {
	if (!has_data(key)) return(false);
	return(get_data(key).start == unknown_data.begin());
}

int structured_chunk::get_data_length(string key, bool count_padding) const {
	// If we count padding, just take the data field's length parameter
	// at it. Otherwise, return the minimum of the distance between the
	// data field position given and the end of the dfp and of the stated
	// data length. If the distance is shorter, then there's padding; that
	// is, the data field claims a large amount of data, but that amount
	// isn't actually available from the source.

	if (!has_data(key)) return(0);

	data_container<data_iterator> info = get_data(key);

	//cout << "[DEBUG chunklen: called " << info.length << " or " << (size_t)(info.container_end - info.start) << "]" << endl;

	if (info.start == null_data.begin()) return(0);

	if (count_padding)
		return(info.length);

	// Undiscovered data is, by its definition, padding. Kludgy? The problem
	// is that find_sector mistakes undiscovered data for real data because
	// we have no way to check which container the data belongs to. PROBNOTE
	if (is_undiscovered_data(key)) return(0);

	// WARNING: Int expansion issues! Beware when porting to 64 bits.
	return(min((size_t)(info.container_end - info.start), info.length));
}

int structured_chunk::get_data_length(string key) const {
	return(get_data_length(key, true));
}

int structured_chunk::get_field_length(string key) const {
	switch(get_field_type(key)) {
		case SC_FT_STRING: return(get_string(key).size());
		case SC_FT_INTEGER: return(get_gen_integer(key).size());
		case SC_FT_DATA: return(get_data_length(key));
		default: return(0);
	}
}

list<string> structured_chunk::get_field_names(field_type type_wanted) const {
	switch(type_wanted) {
		case SC_FT_STRING: return(string_fields->get_keys());
		case SC_FT_INTEGER: return(int_fields->get_keys());
		case SC_FT_DATA: return(data_fields->get_keys());
		default: return(list<string>());
	};
}

list<string> structured_chunk::get_field_names() const {
	list<string> to_ret, current;
	current = int_fields->get_keys();
	to_ret.splice(to_ret.end(), current);
	current = string_fields->get_keys();
	to_ret.splice(to_ret.end(), current);
	current = data_fields->get_keys();
	to_ret.splice(to_ret.end(), current);
	return(to_ret);
}

comp_dir structured_chunk::matches_int(const structured_chunk & other, string
		key, string others_key) const {
	// Since we don't know what field type we're looking for, try all of
	// them and return true as soon as we find something.
	// NOTE that integers don't match unless they're of the same length.
	// Should they do that? Intuition says no.
	// Now it matches all integers with the same value.
	
	if (get_field_type(key) != other.get_field_type(others_key)) 
		return (TC_NEXIST);

	switch(get_field_type(key)) {

		// None found or unknown type: return less (by convention)
		default:
		case SC_FT_NONE: return(TC_LESS);

		case SC_FT_INTEGER:
			 return (get_matching_direction(get_integer(key),
						 other.get_integer(
							 others_key)));
		case SC_FT_STRING:
			 return(get_matching_direction(get_string(key), 
						 other.get_string(
						 others_key)));

		case SC_FT_DATA:
			 return(get_matching_direction(get_data(key), 
						 other.get_data(
						 others_key)));
	};
}

comp_dir structured_chunk::matches_int(const structured_chunk & other, string 
		key) const {

	return(matches_int(other, key, key));	
}

bool structured_chunk::matches(const structured_chunk & other, string key,
		string others_key) const {
	return(matches_int(other, key, others_key) == TC_EQUAL);
}

bool structured_chunk::matches(const structured_chunk & other, string 
		key) const {

	return(matches(other, key, key));
}

bool structured_chunk::copy_key(string others_key, const structured_chunk & 
		other, string target_keyname) {
	switch(other.get_field_type(others_key)) {
		case SC_FT_STRING:
			set_string(target_keyname, other.get_string(
						others_key));
			break;
		case SC_FT_INTEGER:
			set_gen_integer(target_keyname, other.get_gen_integer(
						others_key));
			break;
		case SC_FT_DATA:
			set_data(target_keyname, other.get_data_location(
						others_key),other.
					get_data_container_end(others_key), 
					other.get_data_length(others_key), 
					other.get_data_type(others_key));
			break;
		default:
			return(false);
	}

	return(true);
}

int structured_chunk::size(bool count_data) const {

	// Size consists of:
	// 	string pfield: sum of sizes of strings
	// 	int: sum of sizes of the integer fields
	// 	data: sum as given by length (if count_data, otherwise 0)
	
	int sum = int_fields->size() + string_fields->size();
	if (count_data) sum += data_fields->size();

	return(sum);
}

// Default to counting data
int structured_chunk::size() const {
	return(size(true));
}

// function for straightforwards dumping (default)
// TODO: fix this ugliness

ostream_iterator<char> structured_chunk::dump_to_stream(ostream_iterator<char>
		dest) const {

	// The general idea here is:
	// 	Check all three fields to see which has the lowest relative
	// 	offset ("priority"). Dump that one and then walk forwards.
	// 	We're done when all three fields are at the end.

	priority_map<generic_int>::const_iterator int_fields_pos = 
		int_fields->begin();
	priority_map<string>::const_iterator string_fields_pos = 
		string_fields->begin();
	priority_map<data_container<data_iterator> >::
		const_iterator data_fields_pos = data_fields->begin();

	// While at least one isn't finished
	while ( int_fields_pos != int_fields->end() || string_fields_pos != 
			string_fields->end() || data_fields_pos != 
			data_fields->end()) {

		int if_priority = last_priority+1, sf_priority = 
			last_priority+1, df_priority = last_priority+1;

		// set the priority values for those that aren't at the end
		if (int_fields_pos != int_fields->end())
			if_priority = int_fields_pos->priority;
		if (string_fields_pos != string_fields->end())
			sf_priority = string_fields_pos->priority;
		if (data_fields_pos != data_fields->end())
			df_priority = data_fields_pos->priority;

		// Automatically select the one that is next
		int minval = min(if_priority, min(sf_priority, df_priority));

		if (minval == if_priority) { // generic int is next
			dest = int_fields_pos->content.dump_to_stream(dest);
			int_fields_pos++;
		}

		if (minval == sf_priority) { // string is next
			// Should find some way of generalizing this
			string to_dump = string_fields_pos->content;
			dest = copy(to_dump.begin(), to_dump.end(), dest);
			string_fields_pos++;
		}

		if (minval == df_priority) { // data is next
			data_iterator srcpos = data_fields_pos->content.start;
			// Since data length is decoupled from the data struct,
			// we must first copy the minimum of that length and
			// the real data length, and then fill the rest up with
			// unknowns.
			// TODO put this in a separate function? And beware
			// of int overflow.
			int pcount;
			int minimum_len = min(data_fields_pos->content.size(),
					(size_t)(data_fields_pos->content.
					container_end -	srcpos));
			int leftover = data_fields_pos->content.size() -
				minimum_len;

			dest = copy(srcpos, srcpos + minimum_len, dest);

			for (int padding = 0; padding < leftover;) {
				for (data_iterator padpos = unknown_data
						.begin(); padpos != unknown_data
						.end() && padding < leftover; 
						++padpos) {
					*dest++ = *padpos;
					padding++;
				}
			}

			data_fields_pos++;
		}
	}

	return(dest);
}

/* PHEW! Unit tests tomorrow.

int main() {
	structured_chunk first;
	SGI::crope r("We who test");
	first.set_string("FIRST_VAR", "Hello");
	first.set_integer("SECOND_VAR", 65535, true, 4);
	first.set_string("THIRD_VAR", "Hello thar");
	first.set_data("FOURTH_VAR", r.begin(), 2);

	cout << "Looking up values " << endl;
	cout << first.get_string("FIRST_VAR") << endl;
	cout << first.get_string("THIRD_VAR") << endl;
	cout << first.get_integer("SECOND_VAR") << endl;

	// Should be 4 + 5 + 10 + 2 = 21
	cout << "Size is " << first.size() << endl; 

	cout << "Trying to look up nonexistant values" << endl;
	cout << first.get_string("HelloDudes") << endl;
	//cout << first.get_null_value() << endl;
	if (first.has_string("HelloDudes")) cout << "Has hellodudes (wrong)"
		<< endl;
	if (first.has_string("FIRST_VAR")) cout << "Has FIRST_VAR (correct)"
		<< endl;
	if (first.has_integer("SECOND_VAR")) cout << "Has SECOND_VAR (correct)"
		<< endl;

	// Trying deep copy
	structured_chunk second = first;
	cout << "Checking lookup with copied var" << endl;
	cout << second.get_string("FIRST_VAR") << endl;
	cout << second.get_string("THIRD_VAR") << endl;
	cout << second.get_integer("SECOND_VAR") << endl;

	// Get and put
	ofstream out("out.cut");
	second.dump_to_stream(ostream_iterator<char>(out));
	out.close(); // Should be "Hello FF FF 00 00 Hello tharWe"

	structured_chunk third;
	file_char_prod * fcp = new file_char_prod("out.cut");
	SGI::crope file_access(fcp, fcp->len(), true);
	SGI::crope::const_iterator p = file_access.begin(), fcpend = file_access.end();
	p = third.set_string("FIRST_VAR", p, fcpend, 5);
	p = third.set_integer("SECOND_VAR", p, fcpend, true, 4);
	p = third.set_string("THIRD_VAR", p, fcpend, 10);
	third.set_data("FOURTH_VAR", p, 2);

	// Then verify
	ofstream outtwo("out2.cut");
	third.dump_to_stream(ostream_iterator<char>(outtwo));
	outtwo.close();

	// Should match and have md5 f4c3da75822ca6f3f2cb215572138256
}*/

#endif
