#include "spec.cc"

#include <vector>
#include <list>

#ifndef __ZIP_SPECS
#define __ZIP_SPECS

//PK_FILE_HEADER
// TODO: For if_sane, always check if the key actually exists, because it may
// be called in the middle of construction (not for ZIP, but for headers with
// data in the middle)

// compression methods
const int PK_CM_DEFLATE = 8, PK_CM_STORED = 0; 

// Use string signature to support both PK00PK\3\4 and PK\3\4
class pk_file_spec : public specification {
	private:
		bool version_sane(int version) const;
		void initialize(string signature, int inst_in);

	public:
		bool is_sane(const structured_chunk & to_check,
				const gi_val max_size) const;
		transform_method identify_data_type(const structured_chunk &
				to_check, string data_key_name) const;
		pk_file_spec(int inst_in, string signature);
		pk_file_spec(int inst_in);
};

bool pk_file_spec::version_sane(int version) const {
	if ((version & 0xFF) < 10 || (version & 0xFF) > 63) return(false);
	if ((version >> 8) > 20) return(false);
	return(true);
}

bool pk_file_spec::is_sane(const structured_chunk & to_check, const gi_val
		max_size) const {
	// The ZIP specs give the following constraints for file headers:
	// Version needed to extract should not have lower byte > 63 or
	// upper byte > 20. Also, lower byte should be >= 10.
	// Same for version made by.
	
	if (!version_sane(to_check.get_integer("PK_ver_needed"))) return(false);

	// Compression method should be one of {0, 1, 2, 3, 4, 5, 6, 7, 8, 9
	// 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 98} which is to say either
	// < 20 or 98. (WINZIP also adds the non-official method 99)
	int comp_method = to_check.get_integer("PK_compression_method");
	if (comp_method >= 20 && comp_method != 98 && comp_method != 99)
		return(false);

	// Unless the general purpose bit field says the info is somewhere else,
	// or the file being compressed is empty or close to it, the compressed
	// size shouldn't be more than twice the uncompressed size, and neither
	// should be negative.
	gi_val compressed = to_check.get_integer("PK_comp_size"),
	       uncompressed = to_check.get_integer("PK_uncomp_size");
	if (compressed < 0 || uncompressed < 0) return(false);
	if (uncompressed > 512 && 2 * uncompressed < compressed) return(false);

	// Finally, check that all knowns are in order and that it doesn't use
	// more space than the file has got.
	return(matches_knowns(to_check) && matches_size(to_check, max_size));
}

transform_method pk_file_spec::identify_data_type(const structured_chunk & 
		to_check, string data_key_name) const {

	// If it's not PK_data, we have no idea what type it is, so say so.
	if (data_key_name != "PK_data") return(TM_UNKNOWN);
	switch(to_check.get_integer("PK_compression_method")) {
		case PK_CM_DEFLATE: return(TM_RAW_DEFLATE);
		default: return(TM_UNKNOWN);
	}
}

void pk_file_spec::initialize(string signature, int inst_in) {
	set_type(PK_FILE_HEADER);
	set_terse("PK_FILE_HEADER");
	set_verbose("PKZIP file entry");
	set_inst_code(inst_in);

	add_spec_entry(specification_entry("PK_signature", signature.size(), 
				SPC_STRING, signature, true, signature, 0));
	// Default value: uncompress with > 2.0
	add_spec_entry(specification_entry("PK_ver_needed", 2, 
				SPC_INTEGER, "", true, "", 20));
	add_spec_entry(specification_entry("PK_general_bitfield", 2, 
				SPC_INTEGER, "", true, "", 0));
	add_spec_entry(specification_entry("PK_compression_method", 2,
				SPC_INTEGER, "", true, "", PK_CM_DEFLATE));
	// Date and time is in the "standard MS-DOS format" whatever that is.
	// BLUESKY would be to set these to the current time, but for now
	// the defaults are zero - they'll be overwritten anyhow.
	add_spec_entry(specification_entry("PK_lastmod_time", 2,
				SPC_INTEGER, "", true, "", 0));
	add_spec_entry(specification_entry("PK_lastmod_date", 2,
				SPC_INTEGER, "", true, "", 0));
	add_spec_entry(specification_entry("PK_CRC32", 4,
				SPC_INTEGER, "", true, "", 0));
	add_spec_entry(specification_entry("PK_comp_size", 4,
				SPC_INTEGER, "", true, "", 0));
	add_spec_entry(specification_entry("PK_uncomp_size", 4,
				SPC_INTEGER, "", true, "", 0));
	// Length of "DEFAULT"
	add_spec_entry(specification_entry("PK_fnlen", 2,
				SPC_INTEGER, "", true, "", 7));
	add_spec_entry(specification_entry("PK_efield_len", 2,
				SPC_INTEGER, "", true, "", 0));
	add_spec_entry(specification_entry("PK_filename", "PK_fnlen", 0,
				SPC_STRING, "", true, "DEFAULT", 0));
	add_spec_entry(specification_entry("PK_extrafield", "PK_efield_len", 
				0, SPC_STRING, "", true, "", 0));
	// Beware FILE_FOOTER
	add_spec_entry(specification_entry("PK_data", "PK_comp_size", 0,
				SPC_DATA, "", true, "", 0));
}

pk_file_spec::pk_file_spec(int inst_in, string signature) {
	initialize(signature, inst_in);
}

pk_file_spec::pk_file_spec(int inst_in) {
	initialize("PK\3\4", inst_in);
}

class pk_dir_spec : public specification {
	private:
		bool version_sane(int version) const;

	public:
		bool is_sane(const structured_chunk & to_check, const gi_val
				max_size) const;
		pk_dir_spec(int inst_in);
};

bool pk_dir_spec::version_sane(int version) const {
	if ((version & 0xFF) < 10 || (version & 0xFF) > 63) return(false);
	if ((version >> 8) > 20) return(false);
	return(true);
}

bool pk_dir_spec::is_sane(const structured_chunk & to_check, const gi_val
		max_size) const {
	// See pk_file_spec
	if (!version_sane(to_check.get_integer("PK_ver_needed"))) return(false);
	int comp_method = to_check.get_integer("PK_compression_method");
	if (comp_method >= 20 && comp_method != 98 && comp_method != 99)
		return(false);
	gi_val compressed = to_check.get_integer("PK_comp_size"),
	       uncompressed = to_check.get_integer("PK_uncomp_size");
	if (compressed < 0 || uncompressed < 0) return(false);
	if (uncompressed > 512 && 2 * uncompressed < compressed) return(false);

	return(matches_knowns(to_check) && matches_size(to_check, max_size));

}

pk_dir_spec::pk_dir_spec(int inst_in) {
	set_type(PK_DIR_ENTRY);
	set_terse("PK_DIR_ENTRY");
	set_verbose("PKZIP central directory entry");
	set_inst_code(inst_in);

	add_spec_entry(specification_entry("PK_signature", 4, SPC_STRING,
				"PK\1\2", true, "PK\1\2", 0));
	add_spec_entry(specification_entry("PK_made_by", 2, SPC_INTEGER, "",
				true, "", 20));
	add_spec_entry(specification_entry("PK_ver_needed", 2, SPC_INTEGER, 
				 "", true, "", 20));
	add_spec_entry(specification_entry("PK_general_bitfield", 2,
				SPC_INTEGER, "", true, "", 0));
	add_spec_entry(specification_entry("PK_compression_method", 2,
				SPC_INTEGER, "", true, "", PK_CM_DEFLATE));
	add_spec_entry(specification_entry("PK_lastmod_time", 2,
				SPC_INTEGER, "", true, "", 0));
	add_spec_entry(specification_entry("PK_lastmod_date", 2,
				SPC_INTEGER, "", true, "", 0));
	add_spec_entry(specification_entry("PK_CRC32", 4,
				SPC_INTEGER, "", true, "", 0));
	add_spec_entry(specification_entry("PK_comp_size", 4,
				SPC_INTEGER, "", true, "", 0));
	add_spec_entry(specification_entry("PK_uncomp_size", 4,
				SPC_INTEGER, "", true, "", 0));
	// Seen this before? I thought so.

	add_spec_entry(specification_entry("PK_fnlen", 2,
				SPC_INTEGER, "", true, "", 7));
	add_spec_entry(specification_entry("PK_efield_len", 2,
				SPC_INTEGER, "", true, "", 0));
	add_spec_entry(specification_entry("PK_file_comm_len", 2,
				SPC_INTEGER, "", true, "", 0));
	add_spec_entry(specification_entry("PK_disknum_start", 2,
				SPC_INTEGER, "", true, "", 0));
	add_spec_entry(specification_entry("PK_int_attribs", 2,
				SPC_INTEGER, "", true, "", 0));
	add_spec_entry(specification_entry("PK_ext_attribs", 4,
				SPC_INTEGER, "", true, "", 0));
	add_spec_entry(specification_entry("PK_relative_offset", 4,
				SPC_INTEGER, "", true, "", 0));

	add_spec_entry(specification_entry("PK_filename", "PK_fnlen", 0,
				SPC_STRING, "", true, "DEFAULT", 0));
	add_spec_entry(specification_entry("PK_extrafield", "PK_efield_len", 0,
				SPC_STRING, "", true, "", 0));
	add_spec_entry(specification_entry("PK_filecomment", "PK_file_comm_len",
				0, SPC_STRING, "", true, "", 0));
};


class pk_end_dir_spec : public specification {
	public:
		bool is_sane(const structured_chunk & to_check,
				const gi_val max_size) const;

		pk_end_dir_spec(int inst_in);
};

bool pk_end_dir_spec::is_sane(const structured_chunk & to_check,
		const gi_val max_size) const {

	// PK specs lead one to derive this:
	//	PK_disknum (number of disk in sequence) should be <=
	//	PK_disk_with_directory (last disk - the one with the central
	//		directory on it) [perhaps unless size is too large for
	//		a disk, but AFAIK zip never handled that]
	//	By the same reasoning, PK_entries_on_disk should be <=
	//	PK_entries_in_directory, and offset_of_directory should
	//	be positive.

	if (to_check.get_integer("PK_disk_with_directory") < to_check.
			get_integer("PK_disknum")) return(false);
	if (to_check.get_integer("PK_entries_in_directory") < to_check.
			get_integer("PK_entries_on_disk")) return(false);

	if (to_check.get_integer("PK_offset_of_directory") < 0) return(false);

	return(matches_knowns(to_check) && matches_size(to_check, max_size));
}

pk_end_dir_spec::pk_end_dir_spec(int inst_in) {

	set_type(PK_ENDDIR_HEADER);
	set_terse("PK_ENDDIR_HEADER");
	set_verbose("PKZIP end of central directory header");
	set_inst_code(inst_in);

	add_spec_entry(specification_entry("PK_signature", 4, SPC_STRING,
				"PK\5\6", true, "PK\5\6", 0));
	add_spec_entry(specification_entry("PK_disknum", 2, SPC_INTEGER, 
				"",  true, "", 0));
	add_spec_entry(specification_entry("PK_disk_with_directory", 2, 
				SPC_INTEGER, "", true, "", 0));
	add_spec_entry(specification_entry("PK_entries_on_disk", 2,
				SPC_INTEGER, "", true, "", 0));
	// should be at least 1?
	add_spec_entry(specification_entry("PK_entries_in_directory", 2,
				SPC_INTEGER, "", true, "", 0));
	// This is the sum of the sizes of the directory entries that this
	// enddir_header has as subordinates.
	add_spec_entry(specification_entry("PK_size_of_directory", 4,
				SPC_INTEGER, "", true, "", 0));
	// offset from first FILE_HEADER in this file to first DIR_ENTRY
	add_spec_entry(specification_entry("PK_offset_of_directory", 4,
				SPC_INTEGER, "", true, "", 0));

	string default_comment = "Reconstructed ZIP file";
	add_spec_entry(specification_entry("PK_ZIP_comment_len", 2,
				SPC_INTEGER, "", true, "", 
				default_comment.size()));

	add_spec_entry(specification_entry("PK_ZIP_comment", 
				"PK_ZIP_comment_len", 0, SPC_STRING, "", true, 
				default_comment, 0));
}

// There are two instances of this - one with and one without sig
// Needless to say, the one without sig will only be detectable through hints
class pk_file_footer_spec : public specification {
	private:
		void initialize(int inst_in, bool has_signature);
	public:
		bool is_sane(const structured_chunk & to_check,
				const gi_val max_size) const;
		pk_file_footer_spec(int inst_in, bool has_signature);
		pk_file_footer_spec(int inst_in);
};

void pk_file_footer_spec::initialize(int inst_in, bool has_signature) {
	// TODO: Move this somewhere else
	set_type(PK_FILE_FOOTER);
	set_terse("PK_FILE_FOOTER");
	set_verbose("PKZIP extended file information");
	set_inst_code(inst_in);

	if (has_signature)
		add_spec_entry(specification_entry("PK_signature", 4, 
					SPC_STRING, "PK\7\10", true, "PK\7\10", 
					0));
	add_spec_entry(specification_entry("PK_CRC32", 4, SPC_INTEGER, "", 
				true, "", 0));
	add_spec_entry(specification_entry("PK_comp_size", 4, SPC_INTEGER, "", 
				true, "", 0));
	add_spec_entry(specification_entry("PK_uncomp_size", 4,
				SPC_INTEGER, "", true, "", 0));
}

pk_file_footer_spec::pk_file_footer_spec(int inst_in, bool has_signature) {
	initialize(inst_in, has_signature);
}

pk_file_footer_spec::pk_file_footer_spec(int inst_in) {
	initialize(inst_in, true);
}

bool pk_file_footer_spec::is_sane(const structured_chunk & to_check,
		const gi_val max_size) const {
	gi_val compressed = to_check.get_integer("PK_comp_size"),
	       uncompressed = to_check.get_integer("PK_uncomp_size");

        if (compressed < 0 || uncompressed < 0) return(false);
	if (uncompressed > 512 && 2 * uncompressed < compressed) 
		return(false);

	return(matches_knowns(to_check) && matches_size(to_check, max_size));
}

#endif
