// These classes handle external verification. However we may gather files, if
// they do not pass external verification, they're put in a "does not pass"
// directory. Some files, like mail files (no clear footer) or HTML (people
// regularly write HTML that doesn't conform), do not have an external verifier.

// Because some of these classes rely on calling other programs, we pass file
// names as arguments to verify. It's up to the calling program to write the
// files and then pass the correct argument.
// (TODO: have a subclass "file_verifiers" that do this by itself, perhaps
//  also doing the binary search itself.)

// We assume the verifiers will be called from the rippers; therefore, there is
// no "is this the right type" check.

#ifndef __WHOLE_VERIFIER
#define __WHOLE_VERIFIER

#include "chunk.cc"
#include "occupancy.cc"
#include <vector>
#include <fstream>
#include <iterator>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

using namespace std;

typedef enum whole_verifier_outcome { WV_SUCCESS, WV_CORRUPTED_OR_MISSING, 
	WV_MULTIPLE_FILES, WV_ALLOC_ERROR };

class whole_verifier {
	public:
		virtual bool can_verify() = 0;
		virtual bool can_narrow_down() = 0;
		virtual whole_verifier_outcome verify_entirety(data_iterator 
				start, data_iterator pos, data_iterator end, 
				const file_occupancy & data_map, int our_type,
				int bytes_to_read) = 0;

};

// CONSTRAINT: If [0..a) is a valid file, then for no b > a should [0..b)
// return an error. djpeg satisfies this; zip doesn't. Therefore, 
// can_narrow_down is true for djpeg and false for zip.

const string FV_fn_replacement = "$FILE";

class file_verifier : public whole_verifier {

	private:
		string command;
		string temp_file_name;
		vector<string> parameters;
		int command_not_exist_error;
		bool narrowing_possible;
		bool verifiable;

		bool check_presence_of_command(string command_to_check,
				int shell_cmd_ne_error);

		void init(string temp_file_name_in, string command_in,
				vector<string> params_in, int nonexist_error, 
				bool can_narrow);

	public:
		file_verifier(string temp_file_name_in, string command_in,
				int nonexist_error, bool can_narrow);
		file_verifier(string temp_file_name_in, string command_in,
				vector<string> params_in, int nonexist_error,
				bool can_narrow);
		bool can_narrow_down() { return(narrowing_possible); }
		bool can_verify() { return(verifiable); }
		whole_verifier_outcome verify_entirety(data_iterator start,
				data_iterator pos, data_iterator end, 
				const file_occupancy & data_map, 
				int our_type, int bytes_to_read);
};

// shell_cmd_ne_error is here the error the shell presents if the command can't
// be found.
bool file_verifier::check_presence_of_command(string command_to_check,
		int shell_cmd_ne_error) {

	string full_command = command_to_check + " /dev/null >/dev/null";
	return(system(full_command.c_str()) != shell_cmd_ne_error);
}

void file_verifier::init(string temp_file_name_in, string command_in,
		vector<string> params_in, int nonexist_error, bool can_narrow) {
	narrowing_possible = can_narrow;
	verifiable = check_presence_of_command(command_in, nonexist_error);

	if (!verifiable) {
		cerr << "WARNING: Could not locate external program " << 
			command_in << " for short-cut verification." << endl;
	}

	command_not_exist_error = nonexist_error;
	command = command_in;
	temp_file_name = temp_file_name_in;
	parameters = params_in;

	//parameters.push_back(FV_fn_replacement); // will be replaced by the file
}

file_verifier::file_verifier(string temp_file_name_in, string command_in,
		vector<string> params_in, int nonexist_error, bool can_narrow) {
	init(temp_file_name_in, command_in, params_in, nonexist_error,
			can_narrow);
}

file_verifier::file_verifier(string temp_file_name_in, string command_in,
		int nonexist_error, bool can_narrow) {
	// Default parameter is just the file name.
	init(temp_file_name_in, command_in, vector<string>(1, 
				string(FV_fn_replacement)), 
			nonexist_error, can_narrow);
}

whole_verifier_outcome file_verifier::verify_entirety(data_iterator start,
		data_iterator pos, data_iterator end, const file_occupancy &
		data_map, int our_type, int bytes_to_read) {

	// First, construct the file. Then call the command. If we get a
	// successful return value (0), return WV_SUCCESS, else return 
	// WV_CORRUPTED.
	// Even better would be a fifo, but well..
	
	// TODO: Use advance instad of just ++ iterator.

	whole_verifier_outcome toRet = WV_ALLOC_ERROR;

	ofstream output(temp_file_name.c_str());
	if (!output)
		return(toRet);

	// Step one: copy
	//ostream_iterator<char> p(output);
	data_iterator minend = pos + bytes_to_read, curpos = pos;
	if (end-pos < bytes_to_read) minend = end;

	int current_location = pos - start;
	int current_end_location = minend - start;
	int count = 0;
	while (current_location < current_end_location /*&& 
			count < bytes_to_read*/) {
	//	cout << current_location << "\t" << current_end_location << endl;
		output << *curpos;

		int delta = data_map.advance(current_location, our_type);
		/*curpos = data_map.advance(start, curpos, end, advanced, 
				our_type);*/

	//	int delta = newloc-current_location;
		count += delta;
		curpos += delta;
		current_location += delta;
	}
	//copy(pos, minend, p);

	output.close();

	// Step two: check for success
	// Used to be just system() but that tries to copy the entire program
	// before spawning, which of course fails with the extremely large
	// occupancy vectors we're using.
	/*
	string full_command = command + " " + temp_file_name + " >/dev/null";
	int retval = system(full_command.c_str());

	cout << "[DEBUG: retval is " << retval << " ]" << endl;
	if (retval == 0)
		return(WV_SUCCESS);
	else	return(WV_CORRUPTED_OR_MISSING);*/

	// Construct parameters
	const char * c_params[parameters.size()+2];
	c_params[0] = command.c_str();
	for (int param_no = 0; param_no < parameters.size(); param_no++) 
		if (parameters[param_no] == FV_fn_replacement)
			c_params[param_no+1] = temp_file_name.c_str();
		else	c_params[param_no+1] = parameters[param_no].c_str();
	c_params[parameters.size()+1] = NULL; // null terminated

	cout << "----FORK---" << endl;

	pid_t pid = vfork();
	int retval;

	if (pid == -1) {
		cout << "Error forking" << endl;
		return(WV_ALLOC_ERROR);
	}
	if (pid) {
		// Parent
		// Just wait for the child to return the value we wanted
		wait(&retval);
		cout << "[DEBUG: retval is " << retval << " ] " << endl;
		if (retval == 0)
			return(WV_SUCCESS);
		else	return(WV_CORRUPTED_OR_MISSING);
	} else {
		// Child
		// First, redirect standard output to /dev/null so we won't
		// clutter up the screen
		int devnull = open("/dev/null", O_WRONLY);
		dup2(devnull, STDOUT_FILENO);
		// Then execute our program
		/*if (execlp(command.c_str(), command.c_str(), temp_file_name.
					c_str(), NULL) == -1) {*/
		if (execvp(command.c_str(), (char** const)c_params) == -1) {
			cerr << "Error executing program!" << endl;
			exit(1);
		}
	}
}

#endif
