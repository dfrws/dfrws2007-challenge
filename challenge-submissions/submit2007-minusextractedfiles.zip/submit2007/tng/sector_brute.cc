
// Rippers that work by bruteforcing sectors.
// QnD extreme
// Data-only ripper, speculates about the type of data we've got.

// We need two components; one that, on cue from rkarp, checks the header for
// consistency. It's a sort of spec with fluidity. The other gets data-based
// information about the area in question (all-7-bit etc) and slaps on a tag.
// But we already have the second component, in the form of verifiers!

/*class pure_text {

	public:

		template<typename> bool conforms*/
