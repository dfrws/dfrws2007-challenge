#ifndef __COAL_METHD
#define __COAL_METHD

// Coalesce method: This enum is used for entries to a map of chunk types,
// telling whether that chunk is ordinary (equivalence is sufficient for two
// to be consistent), special (doesn't use equivalences), or both (equivalence
// is in part necessary for consistency, but not sufficient). Ordinary chunks
// can be processed very quickly, while special ones may potentially be combined
// with all other chunks, and so are n^2.
// CM_OUT_OF_BAND means another coalescer is being used for this type. It's an
// ugly kludge because we shouldn't care which coalescer is doing the work as
// long as the result shows up correctly.

typedef enum coalesce_method { CM_ORDINARY = 0, CM_SPECIAL = 1, CM_BOTH = 2,
	CM_OUT_OF_BAND = 3, CM_MAXIMUM = 3};

#endif
