using namespace std;

#ifndef __SLPTR_
#include "tree.cc"
#include "chunk.cc"

typedef list<tree<structured_chunk> >::iterator structured_list_ptr;
typedef list<tree<structured_chunk> >::reverse_iterator structured_list_rev_ptr;
#endif
