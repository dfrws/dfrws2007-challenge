#ifndef __DUMMY_DUMP
#define __DUMMY_DUMP

#include <iostream>
#include "detected_headers.h"
#include "tree.cc"
#include "chunk.cc"
#include "dump.h"

using namespace std;

// This dumper does nothing. Its purpose is to allow testing of the coalescer/
// etc part without having to implement a working dumper.

class dummy_dumper : public dumper {

	public:
		chunk_id handles_this_hierarchy() { return(NO_TYPE); }
		ostream_iterator<char> dump_to_file(const
				 tree<structured_chunk> & to_dump,
				 ostream_iterator<char> start_here) 
		 { return(start_here); }
};

#endif
