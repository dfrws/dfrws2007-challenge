// Pseudo-random access file container.
// Amortized constant time, but if the accesses are too random, you'll pay
// for it.
// Since I'm mostly using sequential access and rope is about 6x slower than
// a raw stream, this is a good compromise. It contains two buffers. If we try
// to read before the beginning of the first, the first is moved to the last
// and the pointer of the last to the first, which is loaded with the 
// appropriate data. The same happens, except for being the other way around, if
// we try to read past the end.

// Iterators later.

#include <fstream>
#include <iostream>

using namespace std;

typedef int64_t fsize;
typedef int32_t csize;

class rand_file {
	private:
		char * beginning;
		char * ending;

		fsize maxsize;
		fsize beginning_pos;
		csize normalized_pos;
		csize chunksize;	// must be a power of 2

		ifstream source;

		fsize get_length(ifstream & source);
		void adjust_position(fsize target);
		void farjump(fsize target);
		char get_appropriate(fsize pos);

		// iterator kludge
		fsize current_position;

	public:
		rand_file(string filename, int exponent);
		fsize size() { return(maxsize); }
		char get();
		char get(fsize position);
		bool eof();
};

fsize rand_file::get_length(ifstream & source) {
	fsize curpos = source.tellg();
	source.seekg(0, ios::end);
	fsize length = source.tellg();
	source.seekg(curpos, ios::beg);
	return(length);
}

void rand_file::farjump(fsize target) {
	fsize new_start_pos = target - (target & (chunksize-1));
	cout << "Jumpint far to " << new_start_pos << endl;
	source.seekg(new_start_pos, ios::beg);
	beginning_pos = new_start_pos;
	source.read(beginning, chunksize);
	// Don't try to force another read when we're at the end; then it'll
	// go -1 on us and we're done for.
	if (source.tellg() < maxsize)
		source.read(ending, chunksize);
}

void rand_file::adjust_position(fsize target) {

	if (target < beginning_pos) {
		if (target < beginning_pos - chunksize) {
			farjump(target);
			return;
		}

		swap (beginning, ending);
		source.seekg(beginning_pos - chunksize, ios::beg);
		source.read(beginning, chunksize);
		beginning_pos -= chunksize;
		normalized_pos += chunksize;
		return;
	}

	if (target >= beginning_pos + 2 * chunksize) {
		if (target >= beginning_pos + 3 * chunksize) {
			farjump(target);
			return;
		}

		// if target >> ending_pos + chunksize, later
		// But beware if maxsize < chunksize as this may drive
		// the source to -1
		swap (beginning, ending);
		source.seekg(beginning_pos + 2*chunksize, ios::beg);
		source.read(ending, chunksize);
		beginning_pos += chunksize;
		normalized_pos -= chunksize;
		return;
	}
}

char rand_file::get_appropriate(fsize pos) {
	// throw something
	if (pos < 0 || pos >= maxsize) return(1);

	adjust_position(pos);
	fsize normalized_pos = pos - beginning_pos;
	if (normalized_pos >= chunksize)
		return(ending[normalized_pos-chunksize]);
	else	return(beginning[normalized_pos]);
}

rand_file::rand_file(string filename, int exponent) {
	source.open(filename.c_str());
	chunksize = 2<<exponent;
	beginning_pos = 0;
	maxsize = get_length(source);
	beginning = new char[chunksize];
	ending = new char[chunksize];
	source.read(beginning, chunksize);
	source.read(ending, chunksize);
	current_position = 0;
	normalized_pos = 0;
}

char rand_file::get() {
	// It'd been really nice to have had a quaject here.
	if (pos < 0 || pos >= maxsize) return(1);
	normalized_pos++;
	if (normalized_pos >= 2 * chunksize)
		return (get_appropriate(current_position++));
	current_position++;

	if (normalized_pos >= chunksize)
		return(ending[normalized_pos - chunksize]);
	else	return(beginning[normalized_pos]);

	//return (get_appropriate(current_position++));
}

char rand_file::get(fsize position) {
	current_position = position;
	return(get_appropriate(current_position++));
}

bool rand_file::eof() {
	return (current_position < 0 || current_position >= maxsize);
}

/*
main() {
	rand_file input("ute", 2);
	ofstream x("utecopy");

	input.get(17);
	input.get(0);

	while (!input.eof()) {
		x << input.get();
	}
	input.get(0);
	while (!input.eof()) {
		x << input.get();
	}
}
*/
