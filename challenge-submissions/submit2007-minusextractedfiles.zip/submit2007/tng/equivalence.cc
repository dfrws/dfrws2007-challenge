#ifndef __EQUIVALENCE
#define __EQUIVALENCE

#include "detected_headers.h"
#include "chunk.cc"
#include <string>
#include <map>
#include <set>

#include <iostream>
#include <iterator>

using namespace std;

// Equivalence classes - used for phantom header reconstruction and hierarchy
// grouping. The lookup value lookup[chunk_X][chunk_Y][string A] tells us what
// field in Y corresponds to X's field A. As a concrete example, ZIP 
// PK_FILE_HEADERs need corresponding PK_DIR_HEADERs, and these share some
// fields (like PK_filename or PK_fnlen), so we use equivalence classes to both
// match up PK_FILE_HEADERs with PK_DIR_HEADERs and making PK_DIR_HEADERs for
// those PK_FILE_HEADERs that have none.

// We also need a first equivalent value to map equivalent fields to same
// values when sorting prospective hierarchy parts by equivalence to coalesce.
// Just using map<chunk_id, map<string... wouldn't work because it'd make each
// comparison function n log n. Since we call set_equivalence a lot more times
// than we're going to look up the first equivalence, having a separate
// map for "first equivalence" makes sense.

// BLUESKY: Support multiple entries (not for equivalence, but for 'can use
// as this value' for phantom generation). Not needed yet.

// Lookup is log^3 n. get_chunks.. is worst case n log^2 n.

// Perhaps always return true for get_equivalence(chunk_id a, string b, a, b)
// to preserve identity? Then we'd also have to return first_equivalence for
// (a, b) as (a, b) if we have no equivalence for (a, b). Hmm. That messes up
// the program I'm using, so let's not use it.

class equivalence {

	private:
		map<chunk_id, map<chunk_id, map<string, string> > > lookup;
		// Should be iterator to the above, but that'd be a ginormous
		// mess. Maybe later.
		// TODO: unique_field_address
		map<unique_field_address, unique_field_address> first_equiv;
		/*map<chunk_id, map<string, chunk_id> > first_equiv_id;
		map<chunk_id, map<string, string> > first_equiv_keyname;*/

		void update_first_equivalence(chunk_id first_chunk, string
				first_chunk_field, chunk_id second_chunk,
				string second_chunk_field);
		bool symmetric;

	public:
		equivalence(bool is_symmetric);
		bool set_equivalence(chunk_id first_chunk, string 
				first_chunk_field, chunk_id second_chunk,
				string second_chunk_field);
		// if the field names are equal
		// TODO: Never allow insertion of an empty field name, because
		// that's what we use for "no such found".
		bool set_equivalence(chunk_id first_chunk, string field,
				chunk_id second_chunk);
		bool has_equivalence(chunk_id chunk, const string & field_name,
				chunk_id second_chunk) const;
		set<chunk_id> get_chunks_with_equivalent_fields(chunk_id chunk,
				string field_name) const;
		string get_equivalent_field(chunk_id chunk, const string & 
				field_name, chunk_id second_chunk) const;
		size_t num_equivalences(chunk_id first_chunk, chunk_id
				second_chunk) const;
		bool get_first_equivalence(chunk_id type, string input,
				chunk_id & out_chunk, string & out_keyname) 
			const;
		bool has_any_equivalence(chunk_id type, string input) const;
		bool is_symmetric() const { return(symmetric); }
};

// TODO: Unit test this. And handle asymmetry.
/*void equivalence::update_first_equivalence(chunk_id first_chunk, 
		string first_chunk_field, chunk_id second_chunk, 
		string second_chunk_field) {
	// There are two steps. First find out whichever is closer to zero
	// (checking by chunk_id and then string if there's ambiguity) and
	// set the other first equivalence to that, then go through the map
	// to find which used the other as first equivalence and set those.
	
	// We do this naively because we're not going to call the function
	// that often. If it takes too much time, fix later.

	chunk_id least_chunk; string least_string;
	if (first_chunk < second_chunk || (first_chunk == second_chunk &&
				first_chunk_field < second_chunk_field)) {
		update_first_equivalence(second_chunk, second_chunk_field,
				first_chunk, first_chunk_field);
		return;
	}

	cout << "Init argentum: fc " << first_chunk << " sc " << second_chunk;
	cout << "\t ff: " << first_chunk_field << " sf: " << second_chunk_field
		<< endl;

	// Now either first_chunk > second_chunk or both are equal. In the
	// former case, we should pick second_chunk, in the latter, it doesn't
	// matter what we pick.
	least_chunk = second_chunk;
	least_string = second_chunk_field;

	// Check that the first equivalence isn't already lower than what
	// we're trying to set. (Gah, fix later)
	

	// Set both to this
	first_equiv_id[first_chunk][first_chunk_field] = least_chunk;
	first_equiv_id[second_chunk][second_chunk_field] = least_chunk;

	first_equiv_keyname[first_chunk][first_chunk_field] = least_string;
	first_equiv_keyname[second_chunk][second_chunk_field] = least_string;

	// Now brute-force our way to victory
	// Cut and paste code?

	cout << "Updating.. " << endl;
	cout << "Least key: " << least_chunk << "\t" << least_string << endl;

	for (map<chunk_id, map<string, chunk_id> >::iterator pos =
			first_equiv_id.begin(); pos != first_equiv_id.end();
			++pos) {
		for (map<string, chunk_id>::iterator sec = pos->second.begin();
				sec != pos->second.end(); ++sec) {

			string fe_key = first_equiv_keyname[pos->first]
				[sec->first];

			cout << "update_first_equiv: current key is [" << sec->second << "\t" << fe_key << "] to match " << first_chunk << ", " << first_chunk_field << " or " << second_chunk << ", " << second_chunk_field << endl;

			if ((sec->second == first_chunk && fe_key ==
					first_chunk_field) || (sec->second ==
						second_chunk && fe_key ==
						second_chunk_field)) {
				cout << "Setting." << endl;
				sec->second = least_chunk;
				first_equiv_keyname[pos->first][sec->first] =
					least_string;
			}
		}
	}
}*/

void equivalence::update_first_equivalence(chunk_id first_chunk,
		string first_keyname, chunk_id second_chunk,
		string second_keyname) {
	// Assumes the required preparations for transitivity has been done.
	// If the first equivalence for first_chunk, first_chunk_field is
	// greater than second_chunk,second_chunk_field, just replace it.
	// Do the same the other way too.

	unique_field_address least_chunk, first_chunk_uf, second_chunk_uf;
	first_chunk_uf.type = first_chunk;
	first_chunk_uf.key_name = first_keyname;
	
	second_chunk_uf.type = second_chunk;
	second_chunk_uf.key_name = second_keyname;

	if(second_chunk_uf < first_chunk_uf)
		least_chunk = second_chunk_uf;
	else	least_chunk = first_chunk_uf;

	unique_field_address a_chunk, b_chunk;
	if (get_first_equivalence(first_chunk_uf.type, first_chunk_uf.key_name,
				b_chunk.type, b_chunk.key_name))
		if (b_chunk < least_chunk)
			least_chunk = b_chunk;

	if (get_first_equivalence(second_chunk_uf.type, second_chunk_uf.
				key_name, a_chunk.type, a_chunk.key_name))
		if (a_chunk < least_chunk)
			least_chunk = a_chunk;

	first_equiv[first_chunk_uf] = least_chunk;
	first_equiv[second_chunk_uf] = least_chunk;
}

equivalence::equivalence(bool is_symmetric) {
	symmetric = is_symmetric;
}

bool equivalence::set_equivalence(chunk_id first_chunk, string 
		first_chunk_field, chunk_id second_chunk, string 
		second_chunk_field) {

	if (first_chunk == second_chunk) return(false);

	// Is there a collision? If so, refuse
	if (has_equivalence(first_chunk, first_chunk_field, second_chunk))
		if (get_equivalent_field(first_chunk, first_chunk_field,
					second_chunk) == second_chunk_field) 
			return(false);

	// Otherwise, set it
	cout << "Setting equivalence: " << first_chunk << ", " << second_chunk 
		<< ", " << first_chunk_field << " = " << second_chunk_field << endl;
	lookup[first_chunk][second_chunk][first_chunk_field] = 
		second_chunk_field;
	update_first_equivalence(first_chunk, first_chunk_field, second_chunk,
			second_chunk_field);
	// TODO: Handle if asymmetric
	if (symmetric) {
		lookup[second_chunk][first_chunk][second_chunk_field] =
			first_chunk_field;
		// and set all fields linked to either [second_chunk]
		// [second_chunk_field] or [first_chunk][first_chunk_field]
		// to each other.
		// (Ensure a complete subgraph)
		set<chunk_id> equiv_chunks;
		set<chunk_id>::const_iterator pos;
		equiv_chunks = get_chunks_with_equivalent_fields(first_chunk, 
				first_chunk_field);

		for (pos = equiv_chunks.begin(); pos != equiv_chunks.end();
				pos++) {
			string equivname = get_equivalent_field(first_chunk,
					first_chunk_field, *pos);
			lookup[*pos][second_chunk][equivname] = 
				second_chunk_field;
			update_first_equivalence(*pos, equivname, second_chunk,
					second_chunk_field);
		}

		equiv_chunks = get_chunks_with_equivalent_fields(second_chunk,
				second_chunk_field);

		for (pos = equiv_chunks.begin(); pos != equiv_chunks.end();
				pos++) {
			string equivname = get_equivalent_field(second_chunk,
					second_chunk_field, *pos);
			lookup[*pos][first_chunk][equivname] = 
				first_chunk_field;
			update_first_equivalence(*pos, equivname, first_chunk,
					first_chunk_field);
		}
	}

	// And tell the user, A-OK!
	return(true);
}

bool equivalence::set_equivalence(chunk_id first_chunk, string field,
		chunk_id second_chunk) {
	return(set_equivalence(first_chunk, field, second_chunk, field));
}

// Since has_equivalent_field is called a lot fewer times than get_equivalent_
// field (outside of each other), we gain about 8% by rephrasing has_equivalent_
// field in terms of get_equivalent_field rather than vice versa.

string equivalence::get_equivalent_field(chunk_id chunk, const string & 
		field_name, chunk_id second_chunk) const {

	// Have to do it this way because of C++ iterator brittleness.

	/*if (!symmetric)
		cout << "Looking up " << chunk << ", " << second_chunk << ", " << field_name << endl;*/

	if (lookup.find(chunk) != lookup.end())
		if (lookup.find(chunk)->second.find(second_chunk) !=
				lookup.find(chunk)->second.end())
			if (lookup.find(chunk)->second.find(second_chunk)->
					second.find(field_name) !=
					lookup.find(chunk)->second.
					find(second_chunk)->second.end())

				return(lookup.find(chunk)->second.find(
							second_chunk)->second.
						find(field_name)->second);

	return("");
}

bool equivalence::has_equivalence(chunk_id chunk, const string & field_name,
		                chunk_id second_chunk) const {
	return(get_equivalent_field(chunk, field_name, second_chunk) != "");
}

size_t equivalence::num_equivalences(chunk_id first_chunk, chunk_id 
		second_chunk) const {
	if (lookup.find(first_chunk) == lookup.end()) return(0);
	if (lookup.find(first_chunk)->second.find(second_chunk) ==
				lookup.find(first_chunk)->second.end())
		return(0);
	return (lookup.find(first_chunk)->second.find(second_chunk)->
			second.size());
}


// "Outdegree"
set<chunk_id> equivalence::get_chunks_with_equivalent_fields(chunk_id chunk, 
		string field_name) const {
	// For all chunks associated by "chunk"
	//  If that chunk has an equivalence lookup for the field in question,
	//   add it to the set.
	
	set<chunk_id> toRet;

	if (lookup.find(chunk) == lookup.end()) return(toRet);

	map<chunk_id, map<string, string> >::const_iterator root = 
		lookup.find(chunk)->second.begin(), root_end = lookup.find(
				chunk)->second.end();

	for (map<chunk_id, map<string, string> > ::const_iterator
			pos  = lookup.find(chunk)->second.begin(); 
			pos != lookup.find(chunk)->second.end(); pos++) {
		if (pos->second.find(field_name) != pos->second.end()) 
			toRet.insert(pos->first);
	}

	return(toRet);
}

/*string equivalence::get_equivalent_field(chunk_id chunk, string field_name,
		chunk_id second_chunk) const {
	if (!has_equivalence(chunk, field_name, second_chunk)) return("");

	// Thread through and get the value
	return (lookup.find(chunk)->second.find(second_chunk)->second.
			find(field_name)->second);

}*/

bool equivalence::get_first_equivalence(chunk_id type, string input, chunk_id &
		out_chunk, string & out_keyname) const {

	unique_field_address query;
	query.type = type;
	query.key_name = input;

	if (first_equiv.find(query) == first_equiv.end()) return(false);

	out_chunk = first_equiv.find(query)->second.type;
	out_keyname = first_equiv.find(query)->second.key_name;

	return(true);
}

bool equivalence::has_any_equivalence(chunk_id type, string input) const {

	// Code duplication?
	
	unique_field_address query;
	query.type = type;
	query.key_name = input;

	if (first_equiv.find(query) == first_equiv.end()) return(false);

	return(true);
}

// Hey, we're the fifty third unit (test)!

/*
main() {
	equivalence zip_relate(true);
	// true equivalences
	zip_relate.set_equivalence(PK_DIR_ENTRY, "PK_filename", 
			PK_FILE_HEADER);
	zip_relate.set_equivalence(PK_DIR_ENTRY, "PK_fnlen",
			PK_FILE_HEADER);
	zip_relate.set_equivalence(PK_DIR_ENTRY, "PK_uncomp_size",
			PK_FILE_HEADER);
	zip_relate.set_equivalence(PK_DIR_ENTRY, "PK_comp_size", 
			PK_FILE_HEADER);
	zip_relate.set_equivalence(PK_DIR_ENTRY, "PK_CRC32", PK_FILE_HEADER);
	// ... etc
	// This one isn't true, but just to see it work with multiple sets
	zip_relate.set_equivalence(PK_DIR_ENTRY, "PK_none", NO_TYPE, "PK_not");
	zip_relate.set_equivalence(PK_DIR_ENTRY, "PK_none", UNKNOWN_TYPE, 
			"PK_odd");
	
	// Check collision resistance
	if (zip_relate.set_equivalence(PK_DIR_ENTRY, "PK_filename",
				PK_FILE_HEADER))
		cout << "Shouldn't happen (collision passed)" << endl;

	// Check has
	if (zip_relate.has_equivalence(PK_DIR_ENTRY, "PK_nothing", PK_FILE_HEADER))
		cout << "Returned equivalent something that isn't" << endl;

	// Retrieval
	cout << "Match " << zip_relate.get_equivalent_field(PK_DIR_ENTRY,
			"PK_none", PK_FILE_HEADER) << endl;

	// Set
	// Should return -2 -1
	set<chunk_id> setret = zip_relate.get_chunks_with_equivalent_fields(
			PK_DIR_ENTRY, "PK_none");

	copy(setret.begin(), setret.end(), ostream_iterator<int>(cout, "\n"));
	cout << endl;

	// Get first equivalence
	// Should return PK_FILE_HEADER since PK_FILE_HEADER < PK_DIR_HEADER
	// (not specified explicitly though)
	chunk_id out_chunk; string out_val;
	zip_relate.get_first_equivalence(PK_DIR_ENTRY, "PK_filename", out_chunk,
			out_val);
	if (out_chunk != PK_FILE_HEADER || out_val != "PK_filename")
		cout << "Error at first_equivalence" << endl;
	else	cout << "First equivalence OK" << endl;
	// Check that it can update
	// Since NO_TYPE is < PK_FILE_HEADER, we should now get a NO_TYPE
	// to our next request
	zip_relate.set_equivalence(PK_FILE_HEADER, "PK_filename", NO_TYPE);

	zip_relate.get_first_equivalence(PK_DIR_ENTRY, "PK_filename",
			out_chunk, out_val);
	if (out_chunk != NO_TYPE || out_val != "PK_filename")
		cout << "Error at first_equivalence after redefine" << endl;
	else	cout << "First equivalence after redefine OK" << endl;

	// Transitivity
	// if a equiv b and b equiv c then a equiv c
	zip_relate.set_equivalence((chunk_id)0, "Transitivity", (chunk_id)1, "Tetra");
	zip_relate.set_equivalence((chunk_id)1, "Tetra", (chunk_id)2, "Transitivity 2");

	// Should be "Transitivity 2"
	cout << "Checking trans: " << zip_relate.get_equivalent_field((chunk_id)0, "Transitivity", (chunk_id)2) << endl;
	// Should be "Transitivity"
	zip_relate.get_first_equivalence((chunk_id)2, "Transitivity 2", 
			out_chunk, out_val);
	cout << "Checking trans, ii: " << out_val << endl;
}*/

#endif
