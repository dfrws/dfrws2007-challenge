// VERY QnD PNG identifier.
// Made just to see how many PDFs there are.

#ifndef __PDF_RIPPER
#define __PDF_RIPPER

#include "spec.cc"
#include "tree.cc"
#include "rippers.cc"
#include "dummy_dump.cc"

#include <vector>
#include <list>

using namespace std;

class pdf_initial_header : public specification {

	public:
		pdf_initial_header(int inst_in);
		~pdf_initial_header() {}
};

pdf_initial_header::pdf_initial_header(int inst_in) {
	set_type(PDF_INIT_HEADER);
	set_terse("PDF_INIT_HEADER");
	set_verbose("PDF initial header");
	set_inst_code(inst_in);

	add_spec_entry(specification_entry("PDF_signature", "%PDF-1.", "%PDF-1."));
	add_spec_entry(specification_entry("PDF_minor_version", 1, SPC_STRING,
				"", true, "", 0));
}

class informal_pdf_ripper : public ripper {
	private:
		tree<reconstructor_info> * coalescer_guide;
		tree<chunk_id> hierarchy_relation;
		whole_verifier * pdf_file_verifier;

	public:
		informal_pdf_ripper();
		~informal_pdf_ripper();
		tree<reconstructor_info> * get_coalescer_guide();
		tree<chunk_id> * get_relation() { return(&hierarchy_relation); }
};

informal_pdf_ripper::informal_pdf_ripper() : hierarchy_relation(NO_TYPE) {

	format_name_short = "PDF";
	format_name_long = "Portable Document Format document";
	suggested_field = "PDF_minor_version";

	unstructured_data_type = PDF_UNSTRUCTURED;

	int inst = 0;
	specs.push_back(new pdf_initial_header(inst++));

	coalescer_guide = new tree<reconstructor_info>(
			reconstructor_info(PDF_INIT_HEADER, NULL, NULL));

	file_extractor = auto_ptr<dumper>(new dummy_dumper);

	vector<string> gs_params;
	gs_params.push_back("-dBATCH"); // don't wait for user input
	gs_params.push_back("-dNODISPLAY"); // don't render to display
	gs_params.push_back("-dSAFER"); // don't let the file monkey around
	gs_params.push_back(FV_fn_replacement);

	pdf_file_verifier = new file_verifier("temp", "gs", gs_params,
			32512, true);
	// TODO: Provide maximum and average information here instead of
	// in main.cc
	simple_extract = auto_ptr<naive_extractor>(new naive_extractor(
				pdf_file_verifier, PDF_INIT_HEADER));
	has_naive_extractor = true;
	max_data_size = 8000000;
	average_data_size = 500000;

}

informal_pdf_ripper::~informal_pdf_ripper() {
	for (int counter = 0; counter < specs.size(); counter++)
		delete specs[counter];

	delete coalescer_guide;
}

tree<reconstructor_info> * informal_pdf_ripper::get_coalescer_guide() {
	return(coalescer_guide);
}


#endif
