#include <list>
#include "chunk.cc"
#include "tree.cc"
#include "slptr.h"

using namespace std;

#ifndef __CONSIST
#define __CONSIST

// maybe inherit from consistency_check st we can have a data-wise consistency
// checker... later.

// TODO: The "includes all" part of the specialized hypothesis generators is
// kinda ugly; one'd think that the hgens would provide a list and then the
// result to check would be the union of all of those or something. Fix that
// in a way that doesn't impact performance.. but maybe only when we need it.

class hypothesis_generator {

	public:
		// In this function, we get a list of possible candidates to
		// needle. The function should always err conservatively.
		// The input is a list of hierarchies known so far, and the
		// output is a list of pointers (iterators) to those that might
		// be suitable candidates.
		virtual list<structured_list_ptr> get_potential_candidates(
				list<tree<structured_chunk> > & all,
				structured_list_ptr needle) = 0;

		// This function returns a consistency measure based on the
		// current node and its children. It can either return NAN,
		// which means the tree is inconsistent, 0, which means it
		// doesn't know, or >0 which means it is consistent, with
		// greater values being better.
		virtual double get_consistency_measure(tree<structured_chunk> &
				check) = 0;

		// This function is used for cleaning up any internal state
		// for the nex iteration's get_potential_candidates, so that
		// the trees we give as input don't show up on the list again.
		virtual void exclude(structured_list_ptr combined, 
				structured_list_ptr obsoleted) {}

		// And this one is used to include members into the internal
		// state.
		virtual void include(structured_list_ptr to_include) {}

		virtual ~hypothesis_generator() {}
};

#endif
