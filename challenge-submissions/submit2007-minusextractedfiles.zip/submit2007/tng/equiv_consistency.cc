#ifndef __EQUIVALENCE_CONSISTENCY
#define __EQUIVALENCE_CONSISTENCY

#include <list>
#include "chunk.cc"
#include "tree.cc"
#include "consistency.h"
#include "simple_utility.cc"

using namespace std;

// This is the CM_ORDINARY generator. The candidates, when included, are
// added to a simple_utility class over a given equivalence. Then, when we
// want to find the potential candidates, we just get equivalent chunks from
// the simple_utility class, which gives us all the classes that have equivalent
// values on the fields defined in the equivalence class.

class equivalence_hgen : public hypothesis_generator {

	private:
		simple_utility grouper;
		equivalence complete;

		int get_num_matching_fields(const equivalence & match_against,
				const structured_chunk & a, 
				const structured_chunk & b, bool necessary);

	public:
		equivalence_hgen(equivalence & necessary_criteria, 
				equivalence & complete_criteria) : 
			grouper(necessary_criteria), 
			complete(complete_criteria) {}

		void include(structured_list_ptr to_include);

		void exclude(structured_list_ptr combined, structured_list_ptr
				obsoleted);

		list<structured_list_ptr> get_potential_candidates(
				list<tree<structured_chunk> > & all,
				structured_list_ptr needle);

		double get_consistency_measure(tree<structured_chunk> &
				check);
};

// TODO: Description of each of these algorithms.

int equivalence_hgen::get_num_matching_fields(const equivalence & match_against,
		const structured_chunk & a, const structured_chunk & b, 
		bool necessary) {

	// For all fields in A, get equivalent name for B, then check if those
	// two fields have the same value. If not, return false.

	list<string> a_names = a.get_field_names();

	int matches = 0;

	for (list<string>::const_iterator pos = a_names.begin(); pos != 
			a_names.end(); ++pos) {

		if (!match_against.has_equivalence(a.get_type(), *pos,
					b.get_type())) continue;

		string b_field_name = match_against.get_equivalent_field(
				a.get_type(), *pos, b.get_type());

		if (a.matches(b, *pos, b_field_name))
			matches++;
		else	if (necessary) return(-1);
	}

	return(matches);
}

void equivalence_hgen::include (structured_list_ptr to_include) {
	if (!to_include->is_redundant())
		grouper.insert_chunk(to_include);
}

void equivalence_hgen::exclude(structured_list_ptr combined, 
		structured_list_ptr obsoleted) {
	grouper.erase_chunk(combined);

	if (combined != obsoleted)
		grouper.erase_chunk(obsoleted);
}

list<structured_list_ptr> equivalence_hgen::get_potential_candidates(
		list<tree<structured_chunk> > & all, structured_list_ptr 
		needle) {

	// This function simple queries grouper for the list of equivalent 
	// chunks to needle. We don't need all here, but since the consistency
	// class defines the function as including it, we have to follow.
	
	multiset<structured_list_ptr, sort_by_location> candidates = grouper.
		get_equivalent_chunks(needle);

	list<structured_list_ptr> to_return;
	copy(candidates.begin(), candidates.end(), inserter(to_return, 
				to_return.end()));

	return(to_return);
}

// Through equivalence "all"!!
double equivalence_hgen::get_consistency_measure(tree<structured_chunk> &
		check) {

	if (check.subordinates.empty()) return(0);

	// Shouldn't be here!

	return(get_num_matching_fields(complete, check.get_value(), 
				check.subordinates.begin()->get_value(), 
				false));
}

#endif
