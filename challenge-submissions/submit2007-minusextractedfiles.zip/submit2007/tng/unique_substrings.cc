// Implements the naive version of the unique substrings problem (which is to
// find relative offsets so that a fixed-window search never mistakes one for 
// the other).
//
// Uses sets now.

#include <iostream>
#include <iterator>
#include <vector>
#include <list>
#include <string>
#include <set>

using namespace std;

class substring_set {
	private:
		string full_string;
		int ref_no;

		set<string> expand_to_substrings(string input, int substr_len,
				char wildcard);

        public:
		set<string> possible_substrings; // Evil, is it not? But it's
		// the best solution short of dozens of iterators
	
		void set_full_string(string full_string_in, int substr_len,
				char wildcard);
		void set_reference_number(int ref_no_in);
		substring_set(string full_string_in, int substr_len, char
				wildcard, int ref_no_in);

		int get_reference_number() const;
		string get_full_string() const;

		/* Remove substrings common to both from this */
		void pare(const substring_set & other);

		/* by number of elements in the substring set */
		bool operator<(const substring_set & other) const;
		bool operator>(const substring_set & other) const;

};

// private

// Given a string, construct all possible substrings of substr_len size, where
// no substring contains the wildcard.
// Brute force, nm time.
set<string> substring_set::expand_to_substrings(string input, int substr_len,
		char wildcard) {

	set<string> output;

	int in_size = input.size();
	
	const size_t npos = (size_t)-1;

	for (int counter = 0; counter <= in_size - substr_len; counter++) {
		string candidate = string(input, counter, substr_len);
		if (candidate.find(wildcard) != npos) continue;
		
		output.insert(candidate);
	}

        return(output);
}

// public

void substring_set::set_full_string(string full_string_in, int substr_len,
		char wildcard) {
	full_string = full_string_in;
	possible_substrings = expand_to_substrings(full_string, substr_len,
			wildcard);
}

void substring_set::set_reference_number(int ref_no_in) { 
	ref_no = ref_no_in;
}

substring_set::substring_set(string full_string_in, int substr_len, char 
		wildcard, int ref_no_in) {
	set_full_string(full_string_in, substr_len, wildcard);
	set_reference_number(ref_no_in);
}

int substring_set::get_reference_number() const {
	return(ref_no);
}

string substring_set::get_full_string() const {
	return(full_string);
}

void substring_set::pare(const substring_set & other) {

	set<string> difference;
	// Now remove those that the other set has got too
	set_difference(possible_substrings.begin(), possible_substrings.end(),
			other.possible_substrings.begin(), other.
			possible_substrings.end(), inserter(difference, 
				difference.end()));

	// And assign
	possible_substrings = difference;
}

bool substring_set::operator<(const substring_set & other) const {
	return(possible_substrings.size() < other.possible_substrings.size());
}

bool substring_set::operator>(const substring_set & other) const {
	return(possible_substrings.size() > other.possible_substrings.size());
}

// Should this belong to a class?
vector<int> determine_offsets(vector<string> & patterns, int substring_length,
		char wildcard){

	// AAAAA
	// AAAAB
	// AAAAC
	// So we must sort in order of increasing size; otherwise the first
	// iteration would see the other's "AAAA" substring and return nothing

	size_t counter;

	// First construct all possible substrings
	list<substring_set> substrings;
	for (counter = 0; counter < patterns.size(); counter++)
		substrings.push_back(substring_set(patterns[counter], 
					substring_length, wildcard, counter));

	// (This is needed to correctly resolve for "default case" scenarios
	// like the one shown in get_difference().)
	substrings.sort(greater<substring_set>());

	vector<int> offsets(patterns.size());

	// Then for each string...

	for (counter = 0; counter < patterns.size(); counter++) {
		// (Maybe make possible the choice of trying to match against
		//  all strings first, so as to minimize the false positives.
		//  Later.)

		// The string we want to pare is always at the beginning because
		// we pop the substring set from the front once we're done.

		for (list<substring_set>::const_iterator pos = ++substrings.
				begin(); pos != substrings.end(); pos++)
			substrings.begin()->pare(*pos);

		list<substring_set>::const_iterator pared = substrings.begin();

		// Turn substring into offset
		int offset_of_cur;
		if (!pared->possible_substrings.empty())
			offset_of_cur = pared->get_full_string().find(*
					pared->possible_substrings.begin());
		else	offset_of_cur = -1;

		// set the right string's return value
		offsets[pared->get_reference_number()] = offset_of_cur;

		// and remove the string we've just found the match for
		substrings.pop_front();
	}

	return(offsets);
}

/*
main() {

	//for (int p = 0; p < 102480; p++) {
	vector<string> patterns;
	patterns.push_back("FORMXABM"); // 3
	patterns.push_back("FORMXBBM"); // 3
	patterns.push_back("FORMXBCM"); // 0
	patterns.push_back("AAAAA");    // 0
	patterns.push_back("AAAAB");    // 1
	patterns.push_back("AAAAAC");   // 2

	vector<int> offsets = determine_offsets(patterns, 4, '?');
	//}

	copy(offsets.begin(), offsets.end(), ostream_iterator<int>(
				cout, " "));
}*/
