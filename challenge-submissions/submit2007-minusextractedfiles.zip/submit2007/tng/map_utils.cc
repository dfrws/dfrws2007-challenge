#ifndef __MAP_UTILS
#define __MAP_UTILS

#include <map>

using namespace std;

template<typename R, typename T> T lookup_default(const R check_for, const
		map<R, T> & lookup, const T default_return) {
	if (lookup.find(check_for) == lookup.end()) return(default_return);
	return(lookup.find(check_for)->second);
}

#endif
