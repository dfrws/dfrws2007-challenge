#include "detected_headers.h"
#include "ind_coalesc.cc"
#include "phantom.cc"

#ifndef __RECONST_INFO
#define __RECONST_INFO

class reconstructor_info {
	public:
		chunk_id this_chunk_id;
		bool can_coalesce, can_generate_phantom;
		individual_coalescer * coalescer;
		phantom_generator * generator;
		reconstructor_info(chunk_id this_chunk, individual_coalescer *
				coalescer_in, phantom_generator * pgen_in);
		reconstructor_info() {}
};

reconstructor_info::reconstructor_info(chunk_id this_chunk, 
		individual_coalescer * coalescer_in, phantom_generator * 
		pgen_in) {
	this_chunk_id = this_chunk;
	coalescer = coalescer_in;
	generator = pgen_in;

	can_coalesce = (coalescer != NULL);
	can_generate_phantom = (generator != NULL);
}

#endif
