// Priority list
// This is a more-or-less hacky solution to allow us to define and handle 
// header fields at runtime, while having to-file and from-file dumps work
// correctly. Each priority list contains a linked list of the actual values,
// as well as a map that refers to the list, for lookup.

// We now define this separate from the header/chunk class proper to facilitate
// code reuse.

// The int "priority" define the relative location of each field in the
// structured data chunk that the header reflects. We need this int because
// when there are multiple field types, we can't just traverse a single list
// to get the members in order.

// TODO: "get_next_priority" for writing to output. Probably easiest to 
// implement by an internal iterator.

// TODO: use a different term than priority. It's actually relative offset,
// but that's too long.

#ifndef __PRILIST
#define __PRILIST

#include <string>
#include <list>
#include <map>

#include <iostream>

using namespace std;

const int PC_NO_PRIORITY = -1;

template<typename T> class priority_container {
	public:
		T content;
		int priority;

		template<class X> bool operator< (const priority_container<X>
				& b) const { return(priority < b.priority); }
		int size() const { return(content.size()); }
};

// TODO: Iterators for addressing by priority.
// We could just put list as public, but that would break abstraction.
// But STL iterators are too complex and line heavy, I got lost in the code.
// Therefore, for now, this just implements a go_next, get_at, etc.

template<typename T> class priority_map {

	private:
		T null_value; // returned by get_by_key if we don't have 
				// that entry
		list<priority_container<T> > values;
		// for the pseudo-iterator
		map<string, _List_iterator<priority_container<T> > > lookup;
		int last_priority;
		// Ugly hack for copying lookup
		void deepcopy(const priority_map<T> & source);

	public:
		priority_map(T null_value_in);
		priority_map(const priority_map<T> & source);
		priority_map<T> & operator=(const priority_map<T> & source);
		void set_null_value(T new_null_value);
		bool append(string key, T input, int priority);
		bool update_value(string key, T input);
		bool has_key(string key) const;
		T get_by_key(const string key) const;

		list<string> get_keys() const;

		T get_null_value() const;
		int size() const;

		// Iterator stuff below

		class const_iterator {
			public:
				_List_const_iterator<priority_container<T> >
					position;

				const_iterator & next() {
					++position;
					return(*this);
				}

				const_iterator & prev() {
					--position;
					return(*this);
				}

				const_iterator() {}
				// Know of a better solution?
				const_iterator( _List_const_iterator<
						priority_container<T> > 
						initial) { position=initial; }

				// preinc and predec
				const_iterator & operator++() { return(next());}
				const_iterator & operator--() { return(prev());}

				// postinc and postdec
				const_iterator operator++(int p) {
					const_iterator a(position);
					return (a = next());
				}

				const_iterator operator--(int p) {
					const_iterator a(position);
					return(a = prev());
				}

				const priority_container<T> & operator*() {
					return (*position);
				}

				bool operator== (const const_iterator & other)
				const { return(position == other.position); }

				bool operator!= (const const_iterator & other)
				const { return(position != other.position); }

				const _List_const_iterator<
					priority_container<T> > & operator->() {
						return(position);
				}
		};

		// Doing this the usual way makes g++ complain
		const_iterator begin() const {
			return (const_iterator(values.begin()));
		}

		const_iterator end() const {
			return (const_iterator(values.end()));
		}

};

// since the map uses list iterators, we need a deep copy for this.
// PCTMapIter is map<string, list<priority_container<T> >::iterator>::
// const_iterator.
template<typename T> void priority_map<T>::deepcopy(const priority_map<T> & 
		source){
	// We cannot determine the ordering by priority directly. However,
	// since list iterators are not invalidated by shuffling, we can
	// add values by the source's lookup order, then sort the values by
	// priority afterwards.
	
	// First, set the constants and clear what we've already got
	last_priority = source.last_priority;
	null_value = source.null_value;

	values.clear();
	lookup.clear();

	// Then get the values, and add their respective iterators to the
	// lookup table
	for (typename map<string, _List_iterator<priority_container<T> > >::
			const_iterator src_lookup_pos = source.lookup.begin(); 
			src_lookup_pos != source.lookup.end(); 
			src_lookup_pos++) {
		values.push_back(*(src_lookup_pos->second));
		lookup[src_lookup_pos->first] = --values.end();
	}

	// Finally, sort by priority
	values.sort();
}

template<typename T> priority_map<T>::priority_map(T null_value_in) {
	last_priority = 0;
	null_value = null_value_in;
}

template<typename T> void priority_map<T>::set_null_value(T new_null_value) {
	null_value = new_null_value;
}

template<typename T> priority_map<T>::priority_map(
		const priority_map<T> & source) {
	deepcopy(source);
	//deepcopy(lookup.begin());
}

template<typename T> priority_map<T> & priority_map<T>::operator=(const 
		priority_map<T> & source) {
	if (this == &source) return(*this);

	deepcopy(source);
	return(*this);
}

template<typename T> bool priority_map<T>::append(
		string key, T input, int priority) {

	if (priority < last_priority) return(false);

	priority_container<T> candidate;
	candidate.content = input;
	candidate.priority = priority;

	// If we have the key, just change it, otherwise append
	if (has_key(key)) 
		update_value(key, input);
	else {
		values.push_back(candidate);
		lookup[key] = --values.end();
		last_priority = priority;
	}

	return(true);
}

// only
template<typename T> bool priority_map<T>::update_value(string key, T input) {
	if (!has_key(key)) return(false);
	lookup[key]->content = input;
	return(true);
}

template<typename T> bool priority_map<T>::has_key(
		string key) const {
	return(lookup.find(key) != lookup.end());
}

template<typename T> T priority_map<T>::get_by_key(
		const string key) const {
	if (!has_key(key)) return(null_value);
	
	return(lookup.find(key)->second->content);
}

template<typename T> T priority_map<T>::get_null_value() const {
	return(null_value);
}

template<typename T> list<string> priority_map<T>::get_keys() const {

	list<string> to_ret;

	for (typename map<string, _List_iterator<priority_container<T> > >::
			const_iterator pos = lookup.begin(); pos != 
			lookup.end(); pos++)
		to_ret.push_back(pos->first);

	return(to_ret);
}

template<typename T> int priority_map<T>::size() const {

	int sum = 0;

	for (_List_const_iterator<priority_container<T> > pos = values.begin();
			pos != values.end(); pos++)
		sum += pos->size();

	return(sum);
}

// Los testados de unidos
/*
main() {
	// Should be priority_map<int> but C++ won't let me
	priority_map<int> * q = new priority_map<int>(-1);
	if (q->append("First", 1, 0))
		cout << "Could append first" << endl;
	if (q->append("Second", 1, -1))
		cout << "Could append in violation of priority!" << endl;
	q->append("Third", 3, 2);

	// Lookup
	cout << "Third" << q->get_by_key("Third") << endl;
	cout << "Second" << q->get_by_key("Second") << endl;
	cout << "First" << q->get_by_key("First") << endl;

	// Copy and remove original
	priority_map<int> p = *q;
	delete(q);

	// Lookup II
	// Test that a deep copy really was done.
	cout << "Looking up from copy" << endl;
	cout << p.get_by_key("Third") << endl;

	cout << "Walking " << endl;
	priority_map<int>::const_iterator pos;
	for (pos = p.begin(); pos != p.end(); pos++) {
		cout << "PRI: " << pos->priority << "\tVAL:" <<
			pos->content << endl;
	}
}*/

#endif
