#include <vector>
#include "zip_specs.cc"
#include "tree.cc"
#include "equivalence.cc"
#include "schunk_op.cc"
#include "equiv_consistency.cc"
#include "zspecial_consistency.cc"
#include "ind_coalesc.cc"
#include "zip_enddir_coalesce.cc"
#include "zip_dumper.cc"
#include "reconst_info.cc"
#include "phantom.cc"
#include "rippers.cc"

using namespace std;

class zip_ripper : public ripper {

	private:
		//vector<const specification *> specs;
		equivalence all_equivs, necessary, footer_equiv;

		equivalence_hgen * ordinary_hypothesis;
		pk_file_footer_hgen * special_hypothesis;
		hypothesis_coalescer * normal_coalescer;
		tree<reconstructor_info> * coalescer_guide;
		tree<chunk_id> hierarchy_relation;
		map<chunk_id, coalesce_method> coalesces_specially;
		enddir_coalescer endd;

		single_child_pgen * dir_header_pgen, * file_header_pgen;

	public:
		zip_ripper();
		~zip_ripper();
		tree<reconstructor_info> * get_coalescer_guide();
		tree<chunk_id> * get_relation();

};

zip_ripper::zip_ripper() : necessary(true), all_equivs(true), 
	footer_equiv(false), hierarchy_relation(NO_TYPE) {

	format_name_short = "ZIP";
	format_name_long = "PKZIP archive";
	suggested_field = "PK_filename";
	// Set the required data structures.

	int inst = 0; // Big Ugly Kludge. It should just get the array offset.
	specs.push_back(new pk_file_spec(inst++)); // ordinary signature
	specs.push_back(new pk_file_spec(inst++, "PK00PK\3\4"));
	specs.push_back(new pk_file_footer_spec(inst++));
	specs.push_back(new pk_dir_spec(inst++));
	specs.push_back(new pk_end_dir_spec(inst++));

	unstructured_data_type = PK_UNSTRUCTURED;

	// TODO: Derive off reconstructor_info
	//tree<chunk_id> hierarchy_relation(NO_TYPE);
	//map<chunk_id, coalesce_method> coalesces_specially;

	// List of types that either require a special hypothesis generator
	// or match both with normal and special hypothesis generators
	coalesces_specially[PK_ENDDIR_HEADER] = CM_OUT_OF_BAND;
	coalesces_specially[PK_FILE_FOOTER] = CM_SPECIAL;

	// Order the chunks appear in a hierarchy. Note that this isn't the
	// physical ordering, but a combine-wise ordering where each member
	// only requires data from the subordinates in order to combine with
	// it.
	hierarchy_relation.subordinates.push_back(PK_ENDDIR_HEADER);
	hierarchy_relation.subordinates.front().subordinates.push_back(
			PK_DIR_ENTRY);
	hierarchy_relation.subordinates.front().subordinates.front().push_back(
			PK_FILE_HEADER);
	hierarchy_relation.subordinates.front().subordinates.front().
		subordinates.front().push_back(PK_FILE_FOOTER);

	// Symmetric equivalence mappings: these map values between different
	// chunk types, so that we can say if one chunk belongs to another.
	// The necessary mapping must all be satisfied, while the better a
	// chunk combination satisfy all_equivs, the more consistent it is
	// considered. So necessary are well, necessary, while all_equivs are
	// tiebreakers.
	// Note that the apparent relation between FILE_HEADER and FILE_FOOTER 
	// is not given, because when a FILE_FOOTER is present, the relevant
	// FILE_HEADER fields have been nulled out.
	//equivalence necessary(true), all_equivs(true);
	necessary.set_equivalence(PK_DIR_ENTRY, "PK_filename", PK_FILE_HEADER);
	necessary.set_equivalence(PK_DIR_ENTRY, "PK_fnlen", PK_FILE_HEADER);
	necessary.set_equivalence(PK_DIR_ENTRY, "PK_uncomp_size",
			PK_FILE_HEADER);
	necessary.set_equivalence(PK_DIR_ENTRY, "PK_comp_size", PK_FILE_HEADER);
	necessary.set_equivalence(PK_DIR_ENTRY, "PK_CRC32", PK_FILE_HEADER);
	necessary.set_equivalence(PK_DIR_ENTRY, "PK_CRC32", PK_FILE_FOOTER);
	necessary.set_equivalence(PK_DIR_ENTRY, "PK_uncomp_size",
			PK_FILE_FOOTER);
	necessary.set_equivalence(PK_DIR_ENTRY, "PK_comp_size", PK_FILE_FOOTER);

	// By definition, necessary is a subset of all_equivs
	all_equivs = necessary;
	all_equivs.set_equivalence(PK_DIR_ENTRY, "PK_compression_method",
			PK_FILE_HEADER);
	all_equivs.set_equivalence(PK_DIR_ENTRY, "PK_lastmod_time",
			PK_FILE_HEADER);
	all_equivs.set_equivalence(PK_DIR_ENTRY, "PK_lastmod_date",
			PK_FILE_HEADER);
	all_equivs.set_equivalence(PK_DIR_ENTRY, "PK_general_bitfield",
			PK_FILE_HEADER);
	all_equivs.set_equivalence(PK_DIR_ENTRY, "PK_extrafield",
			PK_FILE_HEADER);
	all_equivs.set_equivalence(PK_DIR_ENTRY, "PK_efield_len",
			PK_FILE_HEADER);

	// Asymmetric equivalence mappings; these are used for filling out
	// phantom chunks, and for extending the normal matching system to
	// handle indirect data. "Asymmetric" means that we can derive a 
	// reasonable guess for one's field based on the other, but that we 
	// can't do so in the other direction.
	// The syntax is set_equivalence(FROM, name, TO), which is to say, the
	// first type gives the chunk one is to pull the data from, and the
	// second, the one it's applied to.
	//equivalence footer_equiv(false);
	footer_equiv.set_equivalence(PK_FILE_FOOTER, "PK_uncomp_size", 
			PK_FILE_HEADER);
	footer_equiv.set_equivalence(PK_FILE_FOOTER, "PK_comp_size", 
			PK_FILE_HEADER);
	footer_equiv.set_equivalence(PK_FILE_FOOTER, "PK_CRC32", 
			PK_FILE_HEADER);
	footer_equiv.set_equivalence(PK_FILE_HEADER, "PK_ver_needed",
			PK_DIR_ENTRY, "PK_made_by");

	// TODO: Note that if A > B > C is a possible tree and Q > A > B > C
	// is another, then the phantom generator will always make Q > A > B > C
	// Not a problem yet (like the indirect unify problem), but might be
	// later [PROBNOTE]
	
	// Construct the normal and special hypothesis generators, which suggest
	// matching chunks for a given chunk as well as measure the consistency
	// of a tree of chunks according to its rules. Then combine these to a
	// hypothesis-based coalescer that does the actual combining, and also
	// define the enddir_coalescer. (All of these are archetypes, meaning
	// they get duplicated, one per chunk, in the actual coalescing 
	// process.)
	ordinary_hypothesis = new equivalence_hgen(necessary, all_equivs);
	special_hypothesis = new pk_file_footer_hgen;
	normal_coalescer = new hypothesis_coalescer(hierarchy_relation,
			coalesces_specially, *ordinary_hypothesis,
			*special_hypothesis, all_equivs, footer_equiv, 
			specs);

	// Construct the phantom generators. These work by taking the 
	// specification, making a default (blank) chunk, and then dumping all
	// unified information into it.
	// Note that the indirect unification problem will prevent it from being
	// optimal, because A:X may reduce to B:Y and then while C has an
	// equivalence to A:X, it may not have one to B:Y. [PROBNOTE]
	dir_header_pgen = new single_child_pgen(specs[3], &all_equivs, 
			&footer_equiv);
	file_header_pgen = new single_child_pgen(specs[0], &all_equivs, 
			&footer_equiv);

	// Reconstructor goes here
	// Input is first the chunk type expected at this point, then a
	// pointer to the relevant coalescer, then one to the relevant
	// phantom generator. If either is NULL, it is assumed that the
	// node can't coalesce or have phantoms generated (respectively).
	
	coalescer_guide = new tree<reconstructor_info>(
			reconstructor_info(PK_ENDDIR_HEADER, &endd, NULL));
	coalescer_guide->subordinates.push_back(
			reconstructor_info(PK_DIR_ENTRY, normal_coalescer,
				dir_header_pgen));
	coalescer_guide->subordinates.front().subordinates.push_back(
			reconstructor_info(PK_FILE_HEADER, normal_coalescer,
				file_header_pgen));
	coalescer_guide->subordinates.front().subordinates.front().subordinates.
		push_back(reconstructor_info(PK_FILE_FOOTER, normal_coalescer,
					NULL));

	file_extractor = auto_ptr<dumper>(new zip_dumper);

	has_naive_extractor = false;
}

tree<reconstructor_info> * zip_ripper::get_coalescer_guide() {
	return(coalescer_guide);
}

tree<chunk_id> * zip_ripper::get_relation() {
	return(&hierarchy_relation);
}

zip_ripper::~zip_ripper() {
	delete ordinary_hypothesis;
	delete special_hypothesis;
	delete normal_coalescer;
	delete coalescer_guide;

	delete file_header_pgen;
	delete dir_header_pgen;

	for (int counter = 0; counter < specs.size(); counter++)
		delete specs[counter];
};
