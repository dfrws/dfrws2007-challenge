#include <map>
#include <list>
#include <assert.h>
#include <math.h>

#include "tree.cc"
#include "chunk.cc"
#include "map_utils.cc"
#include "equivalence.cc"
#include "consistency.h"
#include "cmeth.h"
#include "spec.cc"

using namespace std;

#ifndef __SCHUNK_OP
#define __SCHUNK_OP

// Structured tree: a tree of structured_chunks (headers or footers) with 
// functions specific to the structured chunks, such as prevailing_method, which
// finds out if there are any chunks that require special consistency checks,
// and print hierarchy, which prints a structured chunk hierarchy. 

// Re join:
// Also fix the subordinate-superordinate inversion problem as occurs in
// // file_ext.zip (when the superordinate tree contains A and B, and the
// // subordinate tree contains C and A < C < B (< being closer to the root)
// // This happens at the first join, so it's not something wrong with detecting
// // the position..
//

class structured_tree_op {

	private:
		void print_information(const structured_chunk & input,
				string key) const;

		void collapse(const structured_chunk & to_get_from, 
				structured_chunk & to_expand, 
				const list<const equivalence *> & mappings, 
				bool emphasis_destination, 
				bool force_nonequivalent_join) const;

		void synchronize_trees(const tree<structured_chunk> & metric,
				tree<structured_chunk> & to_synchronize,
				vector<const specification *> & specs) const;

		bool is_valid_tree(vector<chunk_id> & this_branch,
				const tree<structured_chunk> & to_check,
				const tree<chunk_id> & relation) const;

	public:
		coalesce_method prevailing_method_for_hierarchy(const 
				map<chunk_id, coalesce_method> & 
				which_coalesce_specially, const 
				tree<structured_chunk> & input) const;

		void print_hierarchy(string prefix, string tabulation,
				string identifier_key, const 
				tree<structured_chunk> & input) const;

		void print_hierarchies(string prefix, string tabulation, 
				string identifier_key, const list<tree<
				structured_chunk> > & input) const;

		bool join(tree<chunk_id> & relation, const 
				tree<structured_chunk> & to_add, 
				tree<structured_chunk> & to_add_to, 
				bool append_if_empty) const;

		bool join(tree<chunk_id> & relation, const 
				tree<structured_chunk> & to_add,
				tree<structured_chunk> & to_add_to) const;

		void unify(tree<structured_chunk> & in, list<const 
				equivalence * > & mappings, bool 
				emphasize_this) const;

		void unify(tree<structured_chunk> & in, 
				const equivalence & symmetric_field_mapping,
				const equivalence & asymmetric_field_mapping, 
				bool emphasize_this) const;

		void update_size_information(tree<structured_chunk> & to_update,
				const equivalence & symmetric_field_mapping,
				const equivalence & asymmetric_field_mapping,
				vector<const specification *> & specs) const;

		double get_tree_consistency(tree<structured_chunk> & to_check,
				map<chunk_id, coalesce_method> & special_cases,
				bool hyperbolic, hypothesis_generator * 
				normal_check, hypothesis_generator * 
				special_check);

};

void structured_tree_op::print_information(const structured_chunk & input,
		string key) const {

	// Here we print input's field corresponding to the index "key". Because
	// a key may index to fields of different types, we first find out
	// which type we're dealing with, and then we print as appropriate.
	// Also, since data most of the time is unprintable, we simply print a
	// placeholder note in the case that we're ordered to print data.

	switch(input.get_field_type(key)) {
		case SC_FT_INTEGER:
			cout << input.get_integer(key);
			return;
		case SC_FT_STRING:
			cout << input.get_string(key);
			return;
		case SC_FT_DATA:
			cout << "(data, length " << input.get_data_length(key)
				<< ")";
			return;
		case SC_FT_NONE:
			cout << "[could not retrieve field]";
			return;
	}
}

void structured_tree_op::collapse(const structured_chunk & to_get_from, 
		structured_chunk & to_expand, const list<const equivalence *> & 
		mappings, bool emphasis_destination, bool 
		force_nonequivalent_join) const {

	// This function collapses chunks, which is to say that it updates
	// to_expand by setting fields that exist in to_get_from but whose
	// equivalent for the type of to_expand doesn't exist. If
	// emphasis_destination is false, it'll overwrite fields that already
	// have some value set in to_expand, and if force_nonequivalent_join is
	// true, it'll directly copy fields that have no equivalents in
	// to_expand.
	
	// The purpose of this is to let the standard matching system based
	// on equivalents handle indirect information. If a chunk is subordinate
	// to another, and the superordinate chunk is to be joined with some
	// other chunk based on the information on the subordinate, collapsing
	// lets us move the information (field data) from the subordinate to
	// the superordinate and then compare directly.
	
	// Note that symmetric mappings must precede asymmetric mappings, since
	// the asymmetric mappings are "last resort" clues. The function will
	// not fail if you don't, but it'll give suboptimal results.

	list<string> source_names = to_get_from.get_field_names();

	for (list<string>::const_iterator pos = source_names.begin(); pos !=
			source_names.end(); ++pos) {
		string dest_name = "";

		// Try to find an equivalent name for the field in question
		// within to_expand's chunk type.

		for (list<const equivalence *>::const_iterator lookup_pos = 
				mappings.begin(); lookup_pos != mappings.end() 
				&& dest_name == "";  ++lookup_pos)
			if ((*lookup_pos)->has_equivalence(to_get_from.
						get_type(), *pos, to_expand.
						get_type()))
				dest_name = (*lookup_pos)->get_equivalent_field(
						to_get_from.get_type(), *pos,
						to_expand.get_type());

		if (dest_name == "") {
			if (force_nonequivalent_join)
				dest_name = *pos;
			else	continue;
		}

		// If there's an emphasis on the destination, don't copy if the
		// field already exists.
		if (emphasis_destination && to_expand.has_defined_field
				(dest_name))
			continue;

		to_expand.copy_key(*pos, to_get_from, dest_name);
	}
}

void structured_tree_op::synchronize_trees(const tree<structured_chunk> & 
		unified_metric, tree<structured_chunk> & to_synchronize, 
		vector<const specification *> & specs) const {

	// This function uses the specification for each node in to_synchronize
	// to move indirect information over from the unified tree referred
	// by unified_metric to to_synchronize.
	
	// The purpose of this is to handle headers where the value of some 
	// field, usually the size, depends on the value of some subordinate,
	// and we don't output the value itself (again, size is a good 
	// example). If we were to output the value itself, it wouldn't be
	// portable, because then the rendered version of the chunk wouldn't be
	// equal to what we acquired.
	
	// So, in short, this updates metadata in to_synchronize according to
	// the unified data from metric.
	
	// Possible TODO: Replace vector of specs pointers with something less
	// ugly. Determining which specs to use will become difficult when we're
	// dealing with multiple file types.

	structured_chunk isolated = to_synchronize.get_value();

	assert (isolated.get_inst_code() >= 0 && (unsigned int) isolated.
			get_inst_code() < specs.size());

	// Propagate the information for this node
	specs[isolated.get_inst_code()]->synchronize_chunk(isolated, 
			unified_metric.get_value());

	to_synchronize.set_value(isolated);

	// Then advance both iterators so that each child of to_synchronize is
	// matched up with its corresponding child from unified_metric.
	
	list<tree<structured_chunk> >::iterator dest_pos = to_synchronize.
		subordinates.begin();
	list<tree<structured_chunk> >::const_iterator src_pos = unified_metric.
		subordinates.begin();

	// And update all of them
	while (src_pos != unified_metric.subordinates.end() && dest_pos !=
			to_synchronize.subordinates.end())
		synchronize_trees(*src_pos++, *dest_pos++, specs);
}

bool structured_tree_op::is_valid_tree(vector<chunk_id> & this_branch, 
		const tree<structured_chunk> & to_check, const 
		tree<chunk_id> & relation) const {

	// This function checks a tree against a hierarchy relation to figure
	// out if a complex join invalidated the tree's correctness. Since
	// the join function itself only looks at parent nodes, this is
	// required to prevent incorrect joins in some complex cases.
	
	this_branch.push_back(to_check.get_value().get_type());

	// If it's a leaf, see if the current trace exists in the hierarchy
	// relation.
	
	if (to_check.subordinates.empty()) {
		cout << "The final countdown" << endl;
		copy (this_branch.begin(), this_branch.end(), ostream_iterator<int>(cout, " "));
		cout << endl;
		bool checkout = relation.has_subordinates(this_branch, 0,
					this_branch.size(), true);
		if (checkout) cout << "Checks out OK" << endl;
		return(checkout);
	}

	// Otherwise, recurse down and return false if we get any falses.

	for (list<tree<structured_chunk> >::const_iterator pos = to_check.
			subordinates.begin(); pos != to_check.subordinates.
			end(); ++pos) {
		// Functions further down will be adding to this_branch, so
		// we know what to remove when we're done recursing down
		// one branch.

		int sizebefore = this_branch.size();

		bool valid = is_valid_tree(this_branch, *pos, relation);

		// May need to just be pop_back.
		this_branch.resize(sizebefore);

		if (!valid) return(false);
	}

	return(true);
}
	


coalesce_method structured_tree_op::prevailing_method_for_hierarchy(const 
		map<chunk_id, coalesce_method> & which_coalesce_specially,
		const tree<structured_chunk> & input) const {
	// The purpose of this function is to figure out if the hierarchy
	// contains members that have their own consistency checks, and thus
	// cannot be coalesced in the simple "equivalence matching" fashion.
	// There are three values, CM_ORDINARY for those that only have 
	// equivalence matching, CM_SPECIAL for those that have other checks,
	// and CM_BOTH that might be involved with both, depending on the other
	// chunk.
	// Thus CM_BOTH overrules CM_SPECIAL which overrules CM_ORDINARY. If
	// the map does not contain an entry for the type in question, we
	// assume it is CM_ORDINARY.
	
	coalesce_method so_far = lookup_default(input.get_value().get_type(),
			which_coalesce_specially, CM_ORDINARY);

	for (list<tree<structured_chunk> >::const_iterator pos = input.
			subordinates.begin(); pos != input.subordinates.end()
			&& so_far != CM_MAXIMUM; ++pos)
		so_far = max(so_far, prevailing_method_for_hierarchy(
					which_coalesce_specially, *pos));

	return(so_far);
}

// TODO: Somehow look up a human-readable version of type. Do that after all
// of this has been handled.

void structured_tree_op::print_hierarchy(string prefix, string tabulation, 
		string identifier_key, const tree<structured_chunk> & 
		input) const {

	// This function renders the hierarchy in a readable format, letting us
	// see how it is structured as well as what members are encompassed
	// in a particular hiearchy. The way the function works is rather
	// straightforward: first, it prints the chunk information for the
	// current node, then it recurses into all children of that node.

	cout << prefix << " ";
	print_information(input.get_value(), identifier_key);
	cout << "\tType: " << input.get_value().get_type() << "\tSize: " << 
		input.get_value().size();

	cout << "\tID:" << input.get_value().get_unique_id() << " at " << input.get_value().get_location();
	if (input.is_redundant() || input.was_recently_combined()) {
		cout << " ";
		if (input.is_redundant()) cout << "R";
		if (input.was_recently_combined()) cout << "C";
	}

	/*list<string> fn = input.get_value().get_field_names();
	while (!fn.empty()) {
		cout << prefix << "tag: " << fn.front() << "\t" << input.get_value().get_field_length(fn.front()) << ": " << input.get_value().get_integer(fn.front()) << endl;
		fn.pop_front();
	}*/

	cout << endl;
	
	for (list<tree<structured_chunk> >::const_iterator pos = input.
			subordinates.begin(); pos != input.subordinates.end();
			++pos)
		print_hierarchy(prefix + tabulation, tabulation, identifier_key,
				*pos);
}

void structured_tree_op::print_hierarchies(string prefix, string tabulation, 
		string identifier_key, const list<tree<structured_chunk> > & 
		input) const {

	for(list<tree<structured_chunk> >::const_iterator pos = input.begin(); 
			pos != input.end(); ++pos) {
		print_hierarchy(prefix, tabulation, identifier_key, *pos);
		cout << "----" << endl;
	}
}

bool structured_tree_op::join(tree<chunk_id> & relation, const 
		tree<structured_chunk> & to_add, tree<structured_chunk> & 
		to_add_to, bool append_if_empty) const {

	// TODO: Document

	vector<chunk_id> sequence(3);
	sequence[0] = to_add_to.get_value().get_type();
	sequence[1] = to_add.get_value().get_type();

	// for all
	if (append_if_empty && to_add_to.subordinates.empty())
		if (relation.has_subordinates(sequence, 0, 2, true)) {
			cout << "Sequence: " << sequence[0] << " and " << sequence[1] << endl;
			to_add_to.subordinates.push_back(to_add);
			return(true);
		}

	for (list<tree<structured_chunk> >::iterator pos = to_add_to.
			subordinates.begin(); pos != to_add_to.subordinates.
			end(); ++pos) {
		sequence[2] = pos->get_value().get_type();
		// Recurse. If this returns true, we've already modified the
		// results, so there's no reason trying at this level.
		// This is first to save cycles. (Breaks ties closer to leaf
		// as a side effect.)
		if (join(relation, to_add, *pos, append_if_empty))
			return(true);

		// If this statement returns true, it means that to_add's
		// parent node is in between to_add_to's node and its child
		// pointed at by pos. Because the function is a simple
		// approximation, it only checks single node pairs, not
		// children.
		if (relation.has_subordinates(sequence, 0, sequence.size(),
					true)) {
			tree<structured_chunk> prior_subordinates = *pos;
			*pos = to_add;
			pos->append_to_end(prior_subordinates);
			return(true);
		}
	}

	// Alas, we didn't find anything.
	return(false);
}

bool structured_tree_op::join(tree<chunk_id> & relation, const 
		tree<structured_chunk> & to_add, tree<structured_chunk> & 
		to_add_to) const {

	// First try to join without appending anything. If that fails, try
	// to append. If neither works, return false.
	
	// Now checks more thoroughly.

	tree<structured_chunk> candidate = to_add_to;

	bool ultimate_success = false;
	
	ultimate_success = join(relation, to_add, candidate, false);
	if (!ultimate_success)
		ultimate_success = join(relation, to_add, candidate, true);

	if (!ultimate_success) return(false);

	// Okay, so the simple join worked. Now check if it holds up to
	// greater scrutiny.
	
	vector<chunk_id> sb;
	if (is_valid_tree(sb, candidate, relation)) {
		to_add_to = candidate;
		return(true);
	}

	return(false);
}

void structured_tree_op::unify(tree<structured_chunk> & in, list<const 
		equivalence *> & mappings, bool emphasize_this) const {

	// TODO: "Skip a node" solution by storing all fields by their
	// first equivalents. Then just do a reverse lookup at each step.
	// However, this could lead to superordinates coloring subordinates,
	// which is undesirable. Bah. Later.
	// The problem is that if A < B < C, B inherits a field from C, and 
	// A also could have inherited a field from C, this will not happen
	// unless B inherits the field that A can inherit, because B will 
	// "filter" nonequivalent fields, even those that are equivalent between
	// A and C. The naive solution is to try all below and break ties
	// by proximity, but that's n^2.

	// Here we unify, starting from the leaves towards the root. The idea
	// is to, at each point, have all the leaves that are children of the
	// node unified, and then to collapse them onto the current node,
	// bringing the information ever closer to the root. The unified tree
	// can then be used to look up any indirect information through the
	// equivalence system, as mentioned in the comment for collapse.

	if (in.subordinates.empty()) return;

	// Get the chunk we're going to collapse onto.
	structured_chunk merged = in.get_value();

	// For each of our children...
	for (list<tree<structured_chunk> >::iterator pos = in.subordinates.
			begin(); pos != in.subordinates.end(); ++pos) {
		// Unify those too,
		unify (*pos, mappings, false);

		// .. and collapse the results onto our node.
		collapse(pos->get_value(), merged, mappings, emphasize_this,
				false);
	}

	// Finally set the collapsed chunk.
	in.set_value(merged);

}

void structured_tree_op::unify(tree<structured_chunk> & in, const equivalence & 
		symmetric_field_mapping, const equivalence & 
		asymmetric_field_mapping, bool emphasize_this) const {

	list<const equivalence *> lookups;
	lookups.push_back(&symmetric_field_mapping);
	lookups.push_back(&asymmetric_field_mapping);

	unify(in, lookups, emphasize_this);
}

void structured_tree_op::update_size_information(tree<structured_chunk> & 
		to_update, const equivalence & symmetric_field_mapping,
		const equivalence & asymmetric_field_mapping, vector<const 
		specification *> & specs) const {

	// Here we just generate a unified tree from to_update, and then run
	// synchronize_trees, which expects such a unified tree. See the comment
	// on synchronize_trees to get what it does.
	
	// First generate the unified version
	tree<structured_chunk> unified(to_update);
	unify(unified, symmetric_field_mapping, asymmetric_field_mapping, 
			false);

	// Then adjust
	synchronize_trees(unified, to_update, specs);
}

double structured_tree_op::get_tree_consistency(tree<structured_chunk> & 
		to_check, map<chunk_id, coalesce_method> & special_cases,
		bool hyperbolic, hypothesis_generator * normal_check, 
		hypothesis_generator * special_check) {

	// This function checks the consistency of an entire tree. It returns
	// the sum of the consistency metrisc of each of the node's 
	// subordinates. 
	
	// The function returns a score, which is NAN if the tree is 
	// inconsistent, otherwise a positive value giving the extent to which
	// the various nodes' data match each other.
	
	// To_check is the tree to check, special cases is a map that notifies
	// of whether we should use normal_check or special_check based on the
	// node's type, hyperbolic determines the interval assigned to the part
	// of the score from the leaves (either a simple sum or a mapping to 
	// score from this node + [0..1], depending on whether it's false or
	// true), and normal_check and special_check are hypothesis generators
	// (individual consistency checks).
	
	double from_leaves_total = 0;

	for (list<tree<structured_chunk> > :: iterator pos = to_check.
			subordinates.begin(); pos != to_check.subordinates.
			end(); ++pos) {

		double from_this_leaf = get_tree_consistency(*pos, 
				special_cases, hyperbolic, normal_check,
				special_check);

		if (isnan(from_this_leaf))
			return(NAN);

		from_leaves_total += from_this_leaf;
	}

	double for_this_node = 0;

	coalesce_method prevailing_method = prevailing_method_for_hierarchy(
			special_cases, to_check);

	// HACK HACK!
	if (prevailing_method == CM_OUT_OF_BAND) return(NAN);

	// If it's not CM_ORDINARY, consult the special check. If it's not
	// CM_SPECIAL, consult the normal check.
	if (prevailing_method == CM_BOTH || prevailing_method == CM_SPECIAL)
		for_this_node += special_check->get_consistency_measure(
				to_check);

	if (isnan(for_this_node)) return(NAN);

	if (prevailing_method == CM_ORDINARY || prevailing_method == CM_BOTH) {
		double potential = normal_check->get_consistency_measure(
				to_check);
		if (prevailing_method != CM_BOTH || !isnan(potential))
			for_this_node += potential;
	}

	if (isnan(for_this_node)) return(NAN);

	// Now return the value. If hyperbolic, we map the total value to
	// (value from this point.. value_from_this_point+1)
	if (hyperbolic)
		return (for_this_node + 1 - 1.0/(1 + from_leaves_total));
	else	return (for_this_node + from_leaves_total);
}

#endif

/*
main() {
	structured_chunk x, y;
	structured_tree p(x);
	p.push_back(y);
	cout << p.subordinates.size() << endl;
}*/
