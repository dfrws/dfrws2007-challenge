#include "dump.h"

class zip_dumper : public dumper {

	// BLUE TODO: Should be replaced with some form of consistency check.
	
	chunk_id handles_this_hierarchy() { return(PK_ENDDIR_HEADER); }

	ostream_iterator<char> dump_to_file(const tree<structured_chunk> &
			to_dump, ostream_iterator<char> start_here);
};

ostream_iterator<char> zip_dumper::dump_to_file(const tree<structured_chunk> &
		to_dump, ostream_iterator<char> start_here) {

	// The zip files are dumped in this order: FILE_HEADERs (and 
	// subordinates) first, then DIR_ENTRIES and finally PK_ENDDIR_HEADERs.
	
	// To do this easily, we get a breadth-first unwrapping of the tree in
	// order, then for each FILE_HEADER pointer, we first dump the
	// corresponding chunk and then any subordinates (FILE_FOOTERs). 
	
	// When that's done, we go through the breadth first list to find
	// DIR_ENTRY instances and dump them. Finally, we dump the 
	// PK_ENDDIR_HEADER.
	
	// Note that the function assumes the hierarchies are well-constructed.
	// Lone DIR_ENTRIES or FILE_HEADERS will desynchronize and mess it up.
	// Fix that later by multiple queues (search for DIR_ENTRIES and dump
	// their pointers to a separate queue as we list their FILE_HEADERs) or
	// by stringent recognition.
	
	// BLUE TODO: Have general methods "dump without subordinates" and
	// "dump with subordinates" in the dumper (can't have it in the tree
	// as tree<int> would fail, for instance).
	
	// TODO: Fix problem where the headers are output in the wrong order.
	// (Back to front instead of front to back)

	list<tree<structured_chunk> const * > bfs = to_dump.
		get_immutable_breadth_first_pointer_list();

	list<tree<structured_chunk> const * >::iterator pos;
	ostream_iterator<char> current = start_here;

	// FILE_HEADERs
	for (pos = bfs.begin(); pos != bfs.end(); ++pos)
		if ((*pos)->get_value().get_type() == PK_FILE_HEADER) {
			//cout << "ENCOUNTER: " << (*pos)->get_value().get_string("PK_filename") << endl;
			// TODO: Handle case where there is more than one
			// subordinate. That doesn't happen in ZIP, but
			// better safe etc..
			current = (*pos)->get_value().dump_to_stream(current);
			if (!(*pos)->subordinates.empty())
				current = (*pos)->subordinates.back().
					get_value().dump_to_stream(current);
		}

	// DIR_ENTRY blocks
	for (pos = bfs.begin(); pos != bfs.end(); ++pos)
		if ((*pos)->get_value().get_type() == PK_DIR_ENTRY)
			current = (*pos)->get_value().dump_to_stream(current);

	// ENDDIR
	current = to_dump.get_value().dump_to_stream(current);

	return(current);
}
