// Specification for unstructured data chunks -- those that are gathered by
// brute-forcing a whole-file verifier from a promising initial point. Since
// we'll be using them for all files with appropriate whole-file verifier
// types, it's better to have one specification for them than to duplicate the
// code n times.

// They always return sane, and having only a single data chunk and no
// string/int chunks, they don't collapse well.

// TODO: Turn structured chunks into these instead of into files? Hmm. May
// require obscene amounts of memory (for AVI, for instance), but it's 
// tempting. Hm, could work since we're dealing with iterators...

class unstruct_spec : public specification {
	private:
		void initialize(chunk_id our_type_in, string key_name,
				string terse, string verbose, int inst_in);

	public:
		unstruct_spec(chunk_id our_type_in, string key_name, string
				terse, string verbose, int inst_in);
		// TODO: If data field > max_size, return false?
		bool is_sane(const structured_chunk & to_check,
				const gi_val max_size) const { return(true); }
		// Since it's unstructured, it could contain many data types.
		transform_method identify_data_type(const structured_chunk &
				to_check, string data_key_name) const {
			return(TM_UNKNOWN); }
		structured_chunk generate_unstructured_chunk(data_iterator
				begin, int length);
};

void unstruct_spec::initialize(chunk_id our_type_in, string key_name,
		string terse, string verbose, int inst_in) {
	set_type(our_type_in);
	set_terse(terse);
	set_verbose(verbose);
	set_inst_code(inst_in);

	string real_key = "UNSTRUCT_" + key_name;
	string real_size_field = real_key + "_size";

	add_spec_entry(specification_entry(real_size_field, 4, SPC_INTEGER, "",
				true, "", 0));
	add_spec_entry(specification_entry(real_key, real_size_field,
				SPC_DATA, "", true, "", 0));
}
