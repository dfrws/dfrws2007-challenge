#ifndef __DATA_VERIFIER
#define __DATA_VERIFIER

#include <ext/rope>
#include <math.h>

namespace SGI = ::__gnu_cxx;
typedef SGI::crope data_type;
typedef data_type::const_iterator data_iterator;

using namespace std;

// not exactly "transform" anymore, is it?
// TODO bluesky: list of mutually exclusive transform methods, e.g
// TM_DEFLATE excludes TM_EXT_PRINTABLE, while TM_EXTP_MAIL is a subset of 
// TM_EXT_PRINTABLE.
typedef enum transform_method { TM_USED_ELSEWHERE = -2, TM_UNKNOWN = -1, 
	TM_RAW_DEFLATE = 0, TM_GZIP_DEFLATE = 1, TM_EXT_PRINTABLE = 2, 
	TM_EXTP_MAIL = 3, TM_EXTP_PDF = 4, TM_EXTP_MAIL_HEADER = 5, 
	TM_EXTP_MAIL_BODY = 6, TM_COMPLETE_FILE = 7, TM_SEVEN_BITS = 8 };
typedef enum verifier_outcome { VO_FAIL, VO_SUCCESS, VO_PSUC_HALTED_EARLY, 
	VO_INIT_ERROR, VO_PROCESSING_ERROR, VO_NOT_APPLICABLE };

typedef struct data_certificate {
	verifier_outcome outcome;
	double score;
	int break_location;
};

// IDEA: Given a chunk of data (and is-of information? Nah, outside of here),
// tell us whether it makes sense.
// Maybe better to tell which method we handle rather than have a bool
// "does it handle this"?.

// Some rules: A positive result should always return a score > 0; a negative
// result should always return a score <= 0. To get current scores based on
// ancestral scores (for passthrough and reweighing), take the product of the
// absolute values, multiplied by -1 if either or both factors are < 0,
// otherwise 1. That way -1 * -1 won't oscillate back to score = 1.
// This is done in compound_score.

class data_verifier {

	protected:
		double compound_score(double score_a, double score_b) const;

	public:
		virtual transform_method get_method_handled() const = 0;
		bool handles_this_method(const transform_method
				check) const { return(check == 
					get_method_handled());}
		virtual bool sufficient_prerequisite(const transform_method 
				prerequisite) const = 0;
		virtual data_certificate verify_data(data_iterator
				beginning, data_iterator pos, data_iterator 
				end, int max_length, double
				ancestral_score) const = 0;
};

double data_verifier::compound_score(double score_a, double score_b) const {
	bool a_neg = (score_a < 0);
	bool b_neg = (score_b < 0);
	double multiplier = 1;
	if (a_neg || b_neg) multiplier = -1;

	return(fabs(score_a) * fabs(score_b) * multiplier);
}

class passthrough_verifier : public data_verifier {
	private:
		transform_method inlet, outlet;

	public:
		passthrough_verifier(transform_method passes_from,
				transform_method passes_to);
		transform_method get_method_handled() const { return(outlet); }
		bool sufficient_prerequisite(const transform_method
				prerequisite) const { return(prerequisite == 
					inlet);}
		data_certificate verify_data(data_iterator beginning, 
				data_iterator pos, data_iterator end, 
				int max_length, double ancestral_score) const;
};

passthrough_verifier::passthrough_verifier(transform_method passes_from,
		transform_method passes_to) {
	inlet = passes_from;
	outlet = passes_to;
}

data_certificate passthrough_verifier::verify_data(data_iterator beginning,
		data_iterator pos, data_iterator end, int max_length,
		double ancestral_score) const {
	data_certificate okay;
	okay.outcome = VO_SUCCESS;
	okay.score = ancestral_score;
	okay.break_location = -1;
	return(okay);
}

#endif
