// Build n-gram models

#include <deque>
#include <vector>
#include <fstream>
#include <iterator>
#include <iostream>

using namespace std;

unsigned int string_to_int(deque<unsigned char> & in, int size) {
	unsigned int toRet = 0;

	for (int p = 0; p < size; p++) 
		toRet = (toRet << 8) + (unsigned char)in[p];

	return(toRet);
}

int main(int argc, char * * argv) {

	if (argc < 4) {
		cerr << "Usage: " << argv[0] << " [sequence number] [file to count] [output code]" << endl;
		return(-1);
	}

	unsigned int sequence = atoi(argv[1]);
	unsigned int maxval = 1 << (sequence * 8);
	string fn = argv[2];
	string outcode = argv[3];
	ifstream checkfile(fn.c_str());
	deque<unsigned char> curstring;

	unsigned int * counts = new unsigned int[maxval];
	for (unsigned int clear = 0; clear < maxval; clear++)
		counts[clear] = 0;

	cout << "Reading data.." << endl;

	unsigned long long cpos = 0;

	istreambuf_iterator<char> rpos(checkfile);

	while (rpos != istreambuf_iterator<char>()) {
		// Give a rudimentary status report
		if ((cpos & 262143) == 262143)
			cout << cpos << "      \r" << flush;

		// Push the next character on the queue, and remove the one
		// at the other end if the queue is now too large.
		curstring.push_back(*rpos);
		if (curstring.size() > sequence)
			curstring.pop_front();

		// If we have enough bytes, increment the statistic for
		// that n-gram.
		if (curstring.size() == sequence)
			counts[string_to_int(curstring, sequence)]++;

		// And advance.
		cpos++;
		rpos++;
	}

	cout << "Writing n-gram summary..." << endl;

	string outstub_read, outstub_machine;
	outstub_read = "stats." + outcode + ".txt";
	outstub_machine = "stats." + outcode + ".dat";

	ofstream out_b(outstub_machine.c_str());

	// Output format is:
	// 	1 byte: sequence (the n in n-gram)
	// 	sizeof(int) bytes: The total count
	// 	then maxval * sizeof(int) bytes: the counts themselves

	char seq = sequence;
	out_b.write(&seq, 1);
	out_b.write((char *)&cpos, sizeof(cpos));
	out_b.write((char *)counts, maxval * sizeof(int));

	out_b.close();
}
