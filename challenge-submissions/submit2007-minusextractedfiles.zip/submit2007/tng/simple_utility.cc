// Utility class: simple.
// This takes a list of pointers as well as an equivalence class and constructs
// a series of maps so that we can efficiently find the groups of chunks that
// are equivalent wrt the equivalence class.
// Discovered we need a multiset because "equal" is defined by the chunk_sorter.

// TODO: Check if there's a bug with type values < 0. Main.cc suggests it,
// where changing one entry to type < 0 alters another entry's intersect set.
// If not, then it's some pointer monkey business.
// Unit test now have both types < 0 with no change in behavior, so it must
// be the pointers.

#ifndef __SIMPLE_UTIL
#define __SIMPLE_UTIL

#include <map>
#include <set>

#include "tristate.h"

#include "tree.cc"
#include "chunk.cc"
#include "equivalence.cc"

using namespace std;

typedef list<tree<structured_chunk> > sc_container;
typedef sc_container::iterator sc_pointer;

// Very quick sorting function for returning a multiset of sc_pointers where
// we don't care in what order the sc_pointers are. This just takes the memory
// location and says a is less than b if its root node is closer to 0 in memory
// space.
class sort_by_location : public binary_function<sc_pointer, sc_pointer, bool> {
	public:
		bool operator()(const sc_pointer a, const sc_pointer b) const {
			return (&(a->get_value()) < &(b->get_value()));
		}
};

class chunk_sorter : public binary_function<sc_pointer, sc_pointer, bool> {
	private:
		chunk_id first_equivalent;
		string first_equivalent_key;
		const equivalence * equiv_reference;

	public:
		chunk_sorter(const equivalence & equivalent, 
				string input_key_name, chunk_id input_chunk);

		comp_dir compare(const structured_chunk & a, 
				const structured_chunk & b) const;
		// straight reference
		bool operator()(const structured_chunk & a, 
				const structured_chunk & b) const;
		bool operator()(const sc_pointer a, const sc_pointer b) const;

};

chunk_sorter::chunk_sorter(const equivalence & equivalent, string 
		input_key_name, chunk_id input_chunk) {

	// TODO: if not symmetric, abort abort

	equiv_reference = &equivalent;
	if (!equiv_reference->get_first_equivalence(input_chunk, 
				input_key_name, first_equivalent, 
				first_equivalent_key)) {
		cerr << "Error in assigning equivalence!" << endl;
		exit(1);
	}
}

comp_dir chunk_sorter::compare(const structured_chunk & a, 
		const structured_chunk & b) const {
	// Our strategy is to first do a "reverse lookup" from the first
	// equivalence to A's equivalent key name, then do a lookup from that
	// name to B's, and finally comparing the two. To uphold transitivity,
	// we default to LESS if A doesn't have a key for the equivalent in
	// question, or GREATER if B doesn't.
	
	string a_res_keyname, b_res_keyname;

	a_res_keyname = equiv_reference->get_equivalent_field(first_equivalent,
			first_equivalent_key, a.get_type());
	if (a_res_keyname == "") return(TC_LESS); // there was no equivalent for
				// a; default to LESS

	if (b.get_type() == a.get_type())
		b_res_keyname = a_res_keyname;
	else
		b_res_keyname = equiv_reference->get_equivalent_field(
				first_equivalent, first_equivalent_key,
				b.get_type());

	if (b_res_keyname == "") return(TC_GREATER); // there was no equivalent
				// for b; default to GREATER.

	return(a.matches_int(b, a_res_keyname, b_res_keyname));
}

/*bool chunk_sorter::operator()(const structured_chunk & a, const 
		structured_chunk & b) {
	return(compare(a, b) == TC_LESS);
}*/

// Any sort of iterator to a tree of structured chunks
// XXX: Only checks the root. Use unified trees to get the leaves too.
bool chunk_sorter::operator()(const sc_pointer a, const sc_pointer b) const {
	return(compare(a->get_value(), b->get_value()) == TC_LESS);
}

// TODO, make sc_pointer a template.

class simple_utility {

	private:
		map<unique_field_address, multiset<sc_pointer, chunk_sorter, 
			allocator<sc_pointer> > > reduction_table;
		equivalence equiv_reference;

		// This plays the same role as insertion sort does in stl sort;
		// while having atrocious asymptotic performance, it some times
		// is quicker than completing the procedure the "ordinary way".
		bool is_equivalent_on_all(tree<structured_chunk> & comparand,
				tree<structured_chunk> & b, const list<string> 
				& comparand_keys_to_check) const;

		template<typename A, typename B, typename setIter> 
			void brute_reduce(tree<structured_chunk>
				& comparand, multiset<sc_pointer, A, B> & 
				to_reduce, const list<string> & 
				comparand_keys_left, setIter start) const;

		bool insert_chunk(sc_pointer to_insert, string key_name);
		int erase_chunk(sc_pointer to_remove, string key_name);

	public:
		simple_utility(equivalence & over) : equiv_reference(over) {}
		void insert_chunk(sc_pointer to_insert);
		void insert_chunks(sc_container & to_insert, 
				bool include_redundant);
		void erase_chunk(sc_pointer to_remove);
		multiset<sc_pointer, sort_by_location> get_equivalent_chunks(
				sc_pointer comparand) const; 
		// includes self. NOTE: This is *not* reflexive.
};

bool simple_utility::is_equivalent_on_all(tree<structured_chunk> & comparand,
		tree<structured_chunk> & b, const list<string> & 
		comparand_keys_to_check) const {

	// This function acts as a brute-force equivalence check. We use it
	// if the set of equivalent chunks is small yet there are many fields
	// left to check; in that case, going through every field for every
	// chunk is less expensive than looking up the index (log n) for all
	// the remaining fields.
	
	// XXX: Also does not care about children.

	unique_field_address translated;

	for (list<string>::const_iterator pos = comparand_keys_to_check.begin();
			pos != comparand_keys_to_check.end(); ++pos) {
		if (!equiv_reference.has_any_equivalence(comparand.
					get_value().get_type(), *pos))
			continue;

		chunk_sorter current_key(equiv_reference, *pos, comparand.
				get_value().get_type());
		if (current_key.compare(comparand.get_value(), b.get_value()) 
				!= TC_EQUAL)
			return(false);
	}

	return(true);
}


template<typename A, typename B, typename setIter> 
void simple_utility::brute_reduce(tree<structured_chunk> & comparand, 
		multiset<sc_pointer, A, B> &to_reduce, const list<string> & 
		comparand_keys_left, setIter start) const {

	// This brute force procedure goes through every set member and removes
	// those that aren't equal on the keys left.
	
	setIter pos = start;

	// A bit complex because we have to be careful not to saw off the
	// branch we're sitting on.
	while(pos != to_reduce.end())
		if (!is_equivalent_on_all(comparand, **pos, 
					comparand_keys_left)) {
			setIter oldpos = pos;
			++pos;
			to_reduce.erase(oldpos);
		} else
			++pos;
}

// Insert the chunk into the map according to the unique_field_address as_what.
// We translate the key name into a first_equivalent key/chunk_id combination
// and index it based on that. If there is no set already, we create it using
// the appropriate chunk_sorter.
bool simple_utility::insert_chunk(sc_pointer to_insert, string key_name) {

	unique_field_address translated;

	//cout << "\t\t\tInsert_chunk called with key name " << key_name << endl;

	// If there's no equivalence for this field, there's nothing we can do,
	// so get outta here.
	if (!equiv_reference.get_first_equivalence(to_insert->get_value().
				get_type(), key_name, translated.type,
				translated.key_name))
		return(false);

	//cout << "\t\t\tHad equivalence for this field: " << translated.type << ", " << translated.key_name << endl;

	// Add a new set if required
	if (reduction_table.find(translated) == reduction_table.end()) {
		chunk_sorter compare_on_this(equiv_reference, translated.
				key_name, translated.type);
		pair<const unique_field_address, multiset<sc_pointer, 
			chunk_sorter, allocator<sc_pointer> > > 
				mapping(translated, multiset<sc_pointer, 
						chunk_sorter, 
						allocator<sc_pointer> > (
						compare_on_this));
		reduction_table.insert(mapping); 
	//	cout << "\t\t\tConstructed new set" << endl;
		// using [] doesn't work because of nondefault constructor
	}

	// Then add the chunk
	reduction_table.find(translated)->second.insert(to_insert);
	//cout << "\t\t\tAdded chunk, now size is " << reduction_table.find(translated)->second.size() << endl;
	return(true);
}

void simple_utility::insert_chunk(sc_pointer to_insert) {
	// First get all the field names for to_insert
	// Then insert for each of them.

	list<string> field_names = to_insert->get_value().get_field_names();
	//cout << "\tNumber of fns " << field_names.size() << endl;

	while (!field_names.empty()) {
		string cur = field_names.back();
		field_names.pop_back();
	//	cout << "\t\tInsert with field name " << cur << endl;

		insert_chunk(to_insert, cur);
	}
}

void simple_utility::insert_chunks(sc_container & to_insert, 
		bool include_redundant) {

	for (sc_pointer pos = to_insert.begin(); pos != to_insert.end(); ++pos)
		if (!include_redundant || !pos->is_redundant())
			insert_chunk(pos);
}

int simple_utility::erase_chunk(sc_pointer to_remove, string key_name) {

	// Destructive mirror of insert_chunk. As with insert_chunk, we first
	// look up the equivalent name, then find the correct set and erase from
	// there.
	
	unique_field_address translated;
	if (!equiv_reference.get_first_equivalence(to_remove->get_value().
				get_type(), key_name, translated.type,
				translated.key_name))
		return(-2); // No equivalence

	if (reduction_table.find(translated) == reduction_table.end())
		return(-1);  // to_remove was never inserted in the first 
				// place
	
	// Now get the entire range with equivalent keys and find out the
	// one that really matches. We have to do it this way because
	// built-in functions use the chunk_sorter we defined, so using
	// straightforward erase would delete all with the same values for
	// translated.
	
	pair<multiset<sc_pointer>::iterator, multiset<sc_pointer>::iterator>
		locations = reduction_table.find(translated)->second.
		equal_range(to_remove);

	int removed = 0;

	for (multiset<sc_pointer>::iterator p = locations.first; p !=
			locations.second;)
		if (*p == to_remove) {
			multiset<sc_pointer>::iterator oldp = p;
			++p;
			reduction_table.find(translated)->second.erase(oldp);
			removed++;
		}
		else	++p;

	return(removed);
}

void simple_utility::erase_chunk(sc_pointer to_erase) {

	list<string> field_names = to_erase->get_value().get_field_names();

	// TODO: Make more rigorous
	// Reasoning: Field_names contain all fields in to_erase. If we stumble
	// upon a location corresponding to one of the field_names and to_erase
	// isn't there, then to_erase could not have been inserted in the first
	// place, as insertion would have inserted it on all field_names that
	// are in the equivalence table.
	for (list<string>::const_iterator pos = field_names.begin(); pos !=
			field_names.end(); ++pos) {
		int erased = erase_chunk(to_erase, *pos);

		if (erased <= 0 && erased != -2)
			return;
	}
}


// XXX: using const makes c++ whine. Don't know why though.
multiset<sc_pointer, sort_by_location> simple_utility::get_equivalent_chunks(
		sc_pointer comparand) const {
	// Return all chunks (or chunk pointers in this case) where, for all 
	// fields in the comparand where there's some other chunk's field 
	// equivalent to it, the chunks returned have the equivalent value in
	// question.
	
	// NOTE that this is unintuitive. If you have a chunk A that defines
	// an equivalent for field x to B's x_s and an equivalent for field y
	// to C's y_s, then neither B nor C will appear in the list when you use
	// A as comparand. However, A will appear when you use B or C as a
	// comparand. This is really a misfeature, so we should fix it later,
	// but it's sufficient for our purposes so far.
	
	// Doing it the right way would be very complex, so we'll hold off
	// on it for now. It is technically, however, a bug, as the equivalence
	// graph has a loop, then there's no minimal node and so some that are
	// equivalent might be missed.
	
	// STRATEGY: For all field names in comparand, if that name has an
	// equivalent, merge (intersect) current set with the set of those
	// that have the same value for that field as comparand has. For the
	// first field, don't merge, just include (because the intersection
	// with an empty set would be empty and thus we'd get no results).
	
	list<string> field_names = comparand->get_value().get_field_names();
	multiset<sc_pointer, sort_by_location> to_ret;
	bool first = true;

	//cout << "Starting SUT" << endl;

	while (!field_names.empty()) {
		string cur = field_names.back();
	//	cout << "SUT: to_ret.size() " << to_ret.size() << " starting on " << cur << endl;
		field_names.pop_back();

		unique_field_address translated;

		if (!equiv_reference.get_first_equivalence(comparand->
					get_value().get_type(), cur, 
					translated.type, translated.key_name)) 
			continue;

	//	cout << "First equivalence: " << translated.type << ", " << translated.key_name << " for lookup " << cur << endl;

		// This shouldn't happen, but better safe than sorry
		// (It can also happen in some rare situations.)
		if (reduction_table.find(translated) == reduction_table.end())
			continue;
	
		// Allocate a local set onto which we will dump the intersection
		// later.
		multiset<sc_pointer, sort_by_location> intersection(to_ret.key_comp());

		// Then find out what part of the potential set that has the
		// same value for the chunk we're dealing with. Only intersect
		// with these, because the others aren't going to be equivalent.
		pair<multiset<sc_pointer>::const_iterator, multiset<sc_pointer>
			::const_iterator> equals = reduction_table.
				find(translated)->second.equal_range
				(comparand);

		// PROBLEM: to_ret and addendsize don't have the same
		// comparators, so the merge fails. Handle it somehow.
		// If the set ops are stable, it should work (the way radix
		// sort does).

		if (first) {
			to_ret = multiset<sc_pointer, sort_by_location>(equals.
					first, equals.second);
			first = false;
		} else {
			// Copy the range that [has keys with equal value to
			// the comparand] to a set that's got the same
			// comparison function as to_ret. n log n. We can make
			// this linear at the expense of lots of code 
			// complexity.
			multiset<sc_pointer, sort_by_location> addendsize(
					to_ret.key_comp());
			copy(equals.first, equals.second, inserter(addendsize,
						addendsize.begin()));

			// Then intersect what we already have with those that
			// are equal for this particular key. Linear time.
			// We can't just use equals.first,equals.second directly
			// because set_intersection only works when both sets
			// use the same comparison function!

			set_intersection(to_ret.begin(), to_ret.end(),
					addendsize.begin(), addendsize.end(),
					inserter(intersection, intersection.
						end()), sort_by_location());

			to_ret = intersection;
		}

		if (to_ret.empty()) break;
		// XXX: Most sets are small, so maybe we should break to a
		// simple necessary check when the set is small enough?
		// Sketch: if there are k categories left and each have n 
		// entries, then each call will be log n for a total of k log
		// n. Checking the current set exhaustively requires rk ops
		// where r is the number of members. So we should break when
		// r < log n (for the worst case). Doing this robustly means
		// we have to look up all the members and sum up the size of
		// each container first.
		/*	if (*to_ret.begin() == &comparand)
				return(to_ret);*/
		// Or maybe just if to_ret.size() > log (members in current 
		// solution) then brute reduce by this field alone
		if (to_ret.size() < 4) {
			brute_reduce(*comparand, to_ret, field_names,
					to_ret.begin());
			break;
		}

	//	cout << "Final toret size for this round: " << to_ret.size() << endl;
	}

	// Always include self because a == a.
	
	if (to_ret.lower_bound(comparand) == to_ret.upper_bound(comparand))
		to_ret.insert(comparand);

	return(to_ret);
}

#endif

// Unit test later!
//
// tree<structured chunk> a with fields x and y.
// tree<structured chunk> b with fields x and y not equal to a
// tree<structured chunk> c with field z equal to a:x
// equivalence with A:X = C:Z, A:Y = B:Y
// get equivalent chunks for a should return itself (break on y), for b should 
// return itself, for c should return a and c.

/*
main() {
	structured_chunk a_cont(-1, -1, NEGATIVE_TEST_ONE);
	a_cont.set_string("Identifier", "A");
	a_cont.set_string("X", "002");
	a_cont.set_string("Y", "003");
	structured_chunk ac_cont = a_cont; 
	ac_cont.set_string("Identifier", "ACopy");
	tree<structured_chunk> a(a_cont), acopy(ac_cont);
	structured_chunk b_cont(-1, -1, PK_DIR_ENTRY);
	b_cont.set_string("Identifier", "B");
	b_cont.set_string("X", "001");
	b_cont.set_string("Y", "004");
	tree<structured_chunk> b(b_cont);
	structured_chunk c_cont(-1, -1, NEGATIVE_TEST_TWO);
	c_cont.set_string("Identifier", "C");
	c_cont.set_string("Z", "002");
	tree<structured_chunk> c(c_cont);

	equivalence a_to_c(true);
	a_to_c.set_equivalence(a_cont.get_type(), "X", c_cont.get_type(), "Z");
	a_to_c.set_equivalence(a_cont.get_type(), "Y", b_cont.get_type(), "Y");

	simple_utility sifter(a_to_c);
	cout << "Inserting a" << endl;
	list<tree<structured_chunk> > acont; acont.push_back(a);
	sifter.insert_chunks(acont, false);
	cout << "Inserting acopy" << endl;
	list<tree<structured_chunk> > acopycont; acopycont.push_back(acopy);
	sifter.insert_chunk(acopycont.begin());
	cout << "Checking identity - both should return 2: ";
	cout << sifter.get_equivalent_chunks(acopycont.begin()).size() << ", ";
	cout << sifter.get_equivalent_chunks(acont.begin()).size() << endl;

	simple_utility sift_two(a_to_c);
	list<tree<structured_chunk> > bcont, ccont; bcont.push_back(b);
	ccont.push_back(c);
	sift_two.insert_chunk(acont.begin());
	sift_two.insert_chunk(bcont.begin());
	sift_two.insert_chunk(ccont.begin());

	cout << "Set sizes (should be 1 1 2):\t";
	cout << sift_two.get_equivalent_chunks(acont.begin()).size() << ", ";
	cout << sift_two.get_equivalent_chunks(bcont.begin()).size() << ", ";
	cout << sift_two.get_equivalent_chunks(ccont.begin()).size() << endl;
}*/
