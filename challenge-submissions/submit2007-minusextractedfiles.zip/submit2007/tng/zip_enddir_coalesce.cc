#ifndef __ZIP_ENDDIR_COALESCE
#define __ZIP_ENDDIR_COALESCE

#include <deque>
#include "slptr.h"
#include "chunk.cc"
#include "tree.cc"
#include "ind_coalesc.cc"

using namespace std;

typedef enum running_advance_status { RAS_OK, RAS_INCONSISTENCY, RAS_HIT_END,
	RAS_ROOT_CORRUPT};

template<typename Iter> class running_enddir_list {

	private:
		deque<int> stored_ints;
		deque<bool> suited;
		int suitable_members_included;
		int size_gathered;

		bool suitable(Iter & probe);

		Iter leading_edge, trailing_edge, barrier, root;

	public:
		running_enddir_list(Iter root_in, Iter leading_edge_in, 
				Iter trailing_edge_in, Iter end);
		running_advance_status advance_backwards(int desired_count, 
				int desired_size);

		int get_count() { return(suitable_members_included); }
		int get_size_count() { return(size_gathered); }

		tree<structured_chunk> combine(const tree<structured_chunk> & 
				tree_root, bool 
				set_source_children_as_redundant, bool 
				should_reverse);

		tree<structured_chunk> combine(bool 
				set_source_children_as_redundant, bool 
				should_reverse);
};

template<typename Iter> bool running_enddir_list<Iter>::suitable(Iter & probe) {

	return (probe->get_value().get_type() == PK_DIR_ENTRY && 
			!probe->is_redundant() && !probe->subordinates.empty());
}

template<typename Iter> running_enddir_list<Iter>::running_enddir_list(
		Iter root_in, Iter leading_edge_in, Iter trailing_edge_in, 
		Iter end) {

	leading_edge = leading_edge_in;
	trailing_edge = trailing_edge_in;
	barrier = end;
	root = root_in;

	stored_ints.resize(0);
	suited.resize(0);
	suitable_members_included = 0;
	size_gathered = 0;
}

template<typename Iter> running_advance_status running_enddir_list<Iter>::
		advance_backwards(int desired_count, int desired_size) {

	// This function advances the list of chunks to add to the ENDDIR.
	// If the count (of admitted chunks) is below or equal to the desired
	// 	count, add one from the leading edge and decrement that edge. If
	// 	that chunk is suitable, set suited to true and add the size
	// 	to the stored ints, so we have reference information in case
	// 	it changes later.
	// If the count is above the desired count, remove a member off the
	//	trailing edge. If that member was suitable when we added it,
	//	(that is, suited is true for that position), subtract its
	//	size too, so we get the correct result.
	
	// The front of the deques are closer to the edge, the back closer to
	// the beginning.
	
	// Do a few sanity checks
	// NOTE that this precludes using a partially filled ENDDIR_HEADER.
	// Doing that would be too much of a hassle.
	if (!root->subordinates.empty() || root->get_value().get_type() !=
			PK_ENDDIR_HEADER)
		return (RAS_ROOT_CORRUPT);

	if (suitable_members_included <= desired_count) {
		if (leading_edge == barrier)
			return(RAS_HIT_END);

		if (suitable(leading_edge)) {
			suitable_members_included++;
			stored_ints.push_front(leading_edge->subordinates.
					front().size());
			size_gathered += stored_ints.front();
			suited.push_front(true);
		} else {
			stored_ints.push_front(-1);
			suited.push_front(false);
		}

		--leading_edge;
	}

	// then advance (recede) the trailing edge, excluding as necessary,
	// and alerting the user if an inconsistency has been found.
	if (suitable_members_included > desired_count) {
		if (suited.back() ^ suitable(trailing_edge))
			return(RAS_INCONSISTENCY); // inconsistency detected

		if (trailing_edge == barrier)
			return(RAS_HIT_END);
		
		if (suited.back()) {
			--suitable_members_included;
			size_gathered -= stored_ints.back();
		}
		stored_ints.pop_back();
		suited.pop_back();

		--trailing_edge;
	}

	return(RAS_OK);
}

template<class Iter> tree<structured_chunk> running_enddir_list<Iter>::combine(
		const tree<structured_chunk> & tree_root,
		bool set_source_children_as_redundant, bool should_reverse) {

	tree<structured_chunk> toRet(tree_root);

	// Sweep from the leading edge to the trailing edge, i.e from the
	// periphery inwards.
	
	Iter current_position = leading_edge, max_pos = trailing_edge;
	// Off by one
	current_position++; max_pos++;
	deque<bool>::iterator point_suitable = suited.begin();

	int toret_directory_size = 0; // HACK HACK! Should definitely be in
	// a separate "repair" function!

	while (current_position != max_pos) {
		if (*point_suitable) {
			toRet.subordinates.push_back(*current_position);
			toret_directory_size += current_position->get_value().
				size();
			if (set_source_children_as_redundant)
				current_position->set_redundancy(true);
		}

		point_suitable++;
		current_position++;
	}

	// XXX: If there's already something in toRet before we added anything,
	// that'll be reversed too. But that shouldn't happen.
	if (should_reverse)
		reverse(toRet.subordinates.begin(), toRet.subordinates.end());

	structured_chunk mod = toRet.get_value();
	generic_int prev_val = mod.get_gen_integer("PK_size_of_directory");
	prev_val.set_integer(toret_directory_size);
	mod.set_gen_integer("PK_size_of_directory", prev_val);
	toRet.set_value(mod);

	toRet.set_as_combined();

	return(toRet);
}

template<class Iter> tree<structured_chunk> running_enddir_list<Iter>::combine(
		bool set_source_children_as_redundant, bool should_reverse) {
	return(combine(*root, set_source_children_as_redundant, 
				should_reverse));
}

// See how much easier it is now?
// These shouldn't be called haystacks though.
// TODO: Clean up const iterators, and drop the pretense that needle not in 
// haystack (or somehow allow for the possibility). FIXED.
class enddir_coalescer : public individual_coalescer {

	private:
		running_enddir_list<structured_list_ptr> * backwards_checker;
		running_enddir_list<structured_list_rev_ptr>* forwards_checker;

		structured_list_ptr needle_max;
		structured_list_rev_ptr needle_rev_max, rev_needle;

		bool forwards_working, backwards_working;

		int entries, desired_sum;

		template<typename T> strategy_response
			try_single_direction(running_enddir_list<T> & checker, 
					T & parent_pos, T & end_pos,
					const bool & still_works);

		template<typename T> strategy_response try_single_direction(
				running_enddir_list<T> & checker);

	public:
		enddir_coalescer();
		~enddir_coalescer();
		// TODO: Custom copy constructor that doesn't copy backwards/
		// forwards_checkers.

		//enddir_coalescer(structured_list_ptr & forw_max,
		//		structured_list_rev_ptr & rev_max);

		void start_combining(list<tree<structured_chunk> > & 
				to_coalesce, structured_list_ptr candidate);

		strategy_response try_next_strategy();

		//individual_coalescer * make_new() { return(new 
		//		enddir_coalescer(needle_max, needle_rev_max)); }
		individual_coalescer * make_new() const { 
			return(new enddir_coalescer()); }
};

enddir_coalescer::enddir_coalescer(/*list<tree<structured_chunk> > &
		to_steal_from*/) {
	/*needle_max = to_steal_from.end();
	needle_rev_max = to_steal_from.rend();*/
	// XXX: Copy constructor troubles.
	forwards_working = true;
	backwards_working = true;
	has_needle = false;
}

enddir_coalescer::~enddir_coalescer() {
	if (has_needle) {
		delete backwards_checker;
		delete forwards_checker;
	}
}

/*enddir_coalescer::enddir_coalescer(structured_list_ptr & forw_max,
		structured_list_rev_ptr & rev_max) {
	needle_max = forw_max;
	needle_rev_max = rev_max;
	forwards_working = true;
	backwards_working = true;
}*/

void enddir_coalescer::start_combining(list<tree<structured_chunk> > & 
		to_coalesce, structured_list_ptr candidate) {

	cur_needle = candidate;
	// We have to do this because reversing an iterator changes it so
	// that its insertion operator would point at the right place. However,
	// that means that *reversed_iterator != *iterator, so we move it to
	// make it so.
	rev_needle = (structured_list_rev_ptr)candidate;
	rev_needle--;

	needle_max = to_coalesce.end();
	needle_rev_max = to_coalesce.rend();
	forwards_checker = new running_enddir_list<structured_list_rev_ptr>(
			rev_needle, rev_needle, rev_needle, needle_rev_max);
	backwards_checker = new running_enddir_list<structured_list_ptr>(
			cur_needle, cur_needle, cur_needle, needle_max);

	if (!candidate->get_value().get_integer("PK_entries_in_directory") ||
			!candidate->get_value().get_integer
			("PK_offset_of_directory"))
		return; // Not the correct needle

	entries = candidate->get_value().get_integer("PK_entries_in_directory");
	desired_sum = candidate->get_value().get_integer
		("PK_offset_of_directory");

	has_needle = true;
}

template<typename T> strategy_response enddir_coalescer::try_single_direction(
		running_enddir_list<T> & checker, T & parent_pos, T & end_pos,
		const bool & still_works) {

	// Note that we never use the haystack.

	if (!still_works)
		return(STRAT_FAILURE);

	running_advance_status status = checker.advance_backwards(entries, 
			desired_sum);

	cout << "Checker: " << checker.get_count() << "(want: " <<
		entries << "), " << checker.get_size_count() << 
		"(want: " << desired_sum << ")" << "\t";

	switch(status) {
		case RAS_OK: cout << "OK"; break;
		case RAS_INCONSISTENCY: cout << "INCONS"; break;
		case RAS_ROOT_CORRUPT: cout << "ROOT CORRUPT"; break;
		case RAS_HIT_END: cout << "HIT END"; break;
	};
	cout << endl;

	// If we either detected an inconsistency or the results seem to
	// indicate that we've got a solution, rerun to get on track or
	// confirm, respectively.
	if (status == RAS_INCONSISTENCY || (checker.get_count() == entries && 
				checker.get_size_count() == desired_sum)) {

		running_enddir_list<T> reset(parent_pos, parent_pos, parent_pos,
				end_pos);

		status = RAS_OK;

		// Redo
		while ((reset.get_count() != entries || reset.get_size_count()
					!= desired_sum) && status == RAS_OK)
			status = reset.advance_backwards(entries, desired_sum);

		checker = reset;
	}

	if ((checker.get_size_count() != desired_sum || checker.get_count() 
				!= entries)) {
		if (status != RAS_OK)
			return(STRAT_FAILURE);
	} else 
		// Found something
		// *cur_needle = forwards_checker->combine(*cur_needle, true);
		return(STRAT_SUCCESS);

	return (STRAT_UNCERTAIN);
}

strategy_response enddir_coalescer::try_next_strategy() {

	// Note: may not be entirely fair (to have it completely fair would
	// require a loop of the sort while(got unsuitable stuff) continue..
	// Fix that later if required.

	strategy_response backwards_response, forwards_response;

	// Break ties in favor of backwards, because that's the way a ZIP is
	// supposed to be.

	if (backwards_working)
		backwards_response = try_single_direction(*backwards_checker,
			cur_needle, needle_max, backwards_working);
	else	backwards_response = STRAT_FAILURE;

	switch(backwards_response) {
		case STRAT_SUCCESS:
			*cur_needle = backwards_checker->combine(/**cur_needle,*/ 
					true, false);
			return(STRAT_SUCCESS);
		case STRAT_FAILURE:
			backwards_working = false;
	}

	if (forwards_working)
		forwards_response = try_single_direction(*forwards_checker, 
				rev_needle, needle_rev_max, forwards_working);
	else	forwards_response = STRAT_FAILURE;

	switch(forwards_response) {
		case STRAT_SUCCESS:
			// Because we dealth with reverse iterators, the list is
			// the wrong way around, so fix that.
			*cur_needle = forwards_checker->combine(/**cur_needle,*/
					true, true);
			return(STRAT_SUCCESS);
		case STRAT_FAILURE:
			forwards_working = false;
	}

	if (!forwards_working && !backwards_working) return(STRAT_FAILURE);

	return(STRAT_UNCERTAIN);
}

#endif
