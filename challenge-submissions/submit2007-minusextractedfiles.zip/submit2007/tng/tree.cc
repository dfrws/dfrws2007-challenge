#ifndef __TREE
#define __TREE

#include <vector>
#include <list>
#include <iostream>
#include <iterator>

#include "detected_headers.h"

using namespace std;

// I don't really know how complex we need it, so start fast and loose

template<typename T> class tree {
	private:
		T value;
		bool visited;
		bool redundant;	// What an ugly kludge. We should really
				// extend the base class instead.
		bool just_combined;

	public:
		list<tree<T> > subordinates; // Iterators later

		size_t size(); // includes subordinates
		size_t get_num_children() const { return(subordinates.size()); }
		const T & get_value() const { return(value); }
		void set_value(T input) { value = input; }
		tree(T in_value) : value(in_value) { visited=false; redundant = false; just_combined = false; }

		void push_back(tree<T> to_insert);
		void push_back(T to_insert);
		_List_iterator<tree<T> > find_subordinate(const T & x, 
				_List_iterator<tree<T> > start_pos);
		_List_iterator<tree<T> > find_subordinate(const T & x);
		// !ignore_visited is required to enumerate all possible
		// conditions where the subordinates may exist. It's a bit
		// wasteful, but I'm really getting entangled so oh well..
		_List_const_iterator<tree<T> > get_subordinate_pos(const vector<T> & 
				x, int verify_pos, int maxpos, bool 
				ignore_visited) const;
		bool has_subordinates(const vector<T> & x, int verify_pos,
				int maxpos, bool ignore_visited) const;
		int get_subtree_direction(const T & a, const T & b, 
				bool ignore_visited);
		// is there a subtree that starts with either a or b and
		// includes the other?
		void set_visited() { visited = true; }
		void clear_visited(bool recurse);
		// Kludge! Get rigorous algorithm from DN?
		bool append_to_end(const tree<T> & source);

		bool is_redundant() const { return(redundant); }
		void set_redundancy(bool red_in) { redundant = red_in; }
		void set_as_combined() { just_combined = true; }
		void clear_as_combined() { just_combined = false; }
		bool was_recently_combined() const { return(just_combined); }

		// Perhaps T separator?
		list<T> get_breadth_first_traversal();
		list<tree<T> *> get_breadth_first_pointer_list();
		list<tree<T> const *> get_immutable_breadth_first_pointer_list() const;
		list<int> get_breadth_first_depths ();

		// Metafunctions
		template<typename C> bool one_triggers(const C & function) 
			const;

};

template<typename T> size_t tree<T>::size() {
	size_t toRet = value.size();
	for (_List_iterator<tree<T> > pos = subordinates.begin();
			pos != subordinates.end(); pos++)
		toRet += pos->size();

	return(toRet);
}

template<typename T> void tree<T>::push_back(tree<T> to_insert) {
	subordinates.push_back(to_insert);
}

template<typename T> void tree<T>::push_back(T to_insert) {
	tree<T> cons(to_insert);
	push_back(cons);
}

// TODO: Add check on value itself
// TODO: Const iterator
template<typename T> _List_iterator<tree<T> > tree<T>::find_subordinate(const 
		T & x, _List_iterator<tree<T> > start_pos) {

	for (_List_iterator<tree<T> > pos = start_pos; pos !=
			subordinates.end(); pos++) {
		if (pos->value == x) return(pos);

		_List_iterator<tree<T> > possible_location =
			pos->find_subordinate(x);
		if (possible_location != pos->subordinates.end()) 
			return(possible_location);
	}
	return(subordinates.end());
}

// Possibly exptime.
// Like find_subordinates, return .end() if nothing was found, otherwise
// the location of the last match.

template<typename T> _List_const_iterator<tree<T> > tree<T>::get_subordinate_pos(
		const vector<T> & x, int verify_pos, int maxpos, 
		bool ignore_visited) const {

	for (_List_const_iterator<tree<T> > pos = subordinates.begin(); pos !=
			subordinates.end(); pos++) {
		if (pos->value == x[verify_pos] && (!visited || 
					!ignore_visited)) {
			// The intuitive gives an off-by-one.
			if (verify_pos == maxpos-1)
				return(pos);

			_List_const_iterator<tree<T> > candidate = pos->
				get_subordinate_pos(x, verify_pos+1,
						maxpos, ignore_visited);

			if (candidate != pos->subordinates.end()) 
				return(candidate);
		}

		_List_const_iterator<tree<T> > candidate = pos->
			get_subordinate_pos(x, verify_pos, maxpos, 
					ignore_visited);

		if (candidate != pos->subordinates.end()) return(candidate);
	}

	return(subordinates.end());
}

template<typename T> bool tree<T>::has_subordinates(const vector<T> & x, 
		int verify_pos, int maxpos, bool ignore_visited) const {
	return(get_subordinate_pos(x, verify_pos, maxpos, ignore_visited) !=
			subordinates.end());
}


template<typename T> _List_iterator<tree<T> > tree<T>::find_subordinate(const 
		T & x) {
	return(find_subordinate(x, subordinates.begin()));
}

// Check if there's a subtree that includes both a and b. This is used for
// coalescing to check if we can include one hierarchy part into another.
// Returns -1 if there's nothing, 0 if a is first, and 1 if b is first.
template<typename T> int tree<T>::get_subtree_direction(const T & a, const
		T & b, bool ignore_visited) {

	// First find the upper; check against both a and b at each step. 
	// Use recursion.
	// Then once that's done, run find_subordinate on whatever's left.
	if (value == a && (!visited || !ignore_visited))
		if (find_subordinate(b, subordinates.begin()) !=
				subordinates.end()) 
			return(0);
		
	if (value == b && (!visited || !ignore_visited))
		if (find_subordinate(a, subordinates.begin()) !=
				subordinates.end()) 
			return(1);
		

	for (_List_iterator<tree<T> > pos = subordinates.begin(); pos !=
			subordinates.end(); pos++) {
		int this_branch = pos->get_subtree_direction(a, b, 
				ignore_visited);
		if (this_branch != -1) return(this_branch);
	}

	return(-1);
}

template<typename T> void tree<T>::clear_visited(bool recurse) {
	visited = false;
	if (recurse) 
		for_each(subordinates.begin(), subordinates.end(), 
				clear_visited());
}

template<typename T> bool tree<T>::append_to_end(const tree<T> & source) {
	if (subordinates.empty()) {
		subordinates.push_back(source);
		return(true);
	} else {
		for (_List_iterator<tree<T> > pos = subordinates.begin(); 
				pos != subordinates.end(); pos++)
			if (pos->append_to_end(source)) return(true);
	}

	return(false); // shouldn't happen
}

template<typename T> list<tree<T> *> tree<T>::get_breadth_first_pointer_list() {
	// Gets a list of all the children of this node, in breadth first order.
	
	// Queue all children onto the list, then for each of the remaining
	// members of the list, until we're at the end, copy those's children
	// onto the list.
	
	list<tree<T> * > bfs_queue;
	bfs_queue.push_back(this);

	typename list<tree<T> *>::iterator queue_pos = bfs_queue.begin();

	while (queue_pos != bfs_queue.end()) {

		for (typename list<tree<T> >::iterator leaves = 
				(*queue_pos)->subordinates.begin(); leaves != 
				(*queue_pos)->subordinates.end(); ++leaves) 
			bfs_queue.push_back(&(*leaves));
		
		++queue_pos;
	}

	return(bfs_queue);
}

template<typename T> list<tree<T> const *> tree<T>::get_immutable_breadth_first_pointer_list() const {
	// Code duplication!
	
	list<tree<T> const *> bfs_queue;
	bfs_queue.push_back(this);

	typename list<tree<T> const*>::const_iterator queue_pos =
		bfs_queue.begin();

	while (queue_pos != bfs_queue.end()) {
		for (typename list<tree<T> >::const_iterator leaves =
				(*queue_pos)->subordinates.begin(); leaves !=
				(*queue_pos)->subordinates.end(); ++leaves)
			bfs_queue.push_back(&(*leaves));

		++queue_pos;
	}

	return(bfs_queue);
}
template<typename T> list<T> tree<T>::get_breadth_first_traversal() {

	// First get our pointers
	list<tree<T> * > bfs_queue = get_breadth_first_pointer_list();

	// then get the values of those entries
	list<T> to_return;
	for (typename list<T>::iterator queue_pos = bfs_queue.begin(); 
			queue_pos != bfs_queue.end(); ++queue_pos)
		to_return.push_back((*queue_pos)->get_value());

	return(to_return);
}

template<typename T> list<int> tree<T>::get_breadth_first_depths() {
	// As above, but we get the depth of a node by its referent + 1.
	
	list<tree<T> * > bfs_queue;
	list<int> depths;
	bfs_queue.push_back(this);
	depths.push_back(0);

	typename list<tree<T> *>::iterator queue_pos = bfs_queue.begin();
	list<int>::iterator depth_queue_pos = depths.begin();

	while (queue_pos != bfs_queue.end()) {

		for (typename list<tree<T> >::iterator leaves =
				(*queue_pos)->subordinates.begin(); leaves !=
				(*queue_pos)->subordinates.end(); ++leaves) {
			bfs_queue.push_back(&(*leaves));
			depths.push_back(*depth_queue_pos+1);
		}

		++queue_pos;
		++depth_queue_pos;
	}

	return(depths);
}
template<typename T> template<typename C> bool tree<T>::one_triggers(const C & 
		function) const {

	if (function(get_value()))
		return(true);

	for (_List_iterator<tree<T> > pos = subordinates.begin();
			pos != subordinates.end(); pos++)
		if (pos->one_triggers(function)) return(true);

	return(false);
}

template<typename T> void splice(_List_iterator<tree<T> > parent, 
		tree<T> to_add) {
	list<tree<T> > children = parent->children;
	parent->children.clear();
	to_add.children = children;
	parent->children.push_back(to_add);
}


// TODO: Put these in a utility class

typedef class hierarchy_info {
	public:
		bool only_one_child;
		chunk_id type;

		hierarchy_info(bool only_one, chunk_id name);
		hierarchy_info();
		bool operator==(const hierarchy_info & other) const;
};

hierarchy_info::hierarchy_info(bool only_one, chunk_id name) {
	only_one_child = only_one;
	type = name;
}

hierarchy_info::hierarchy_info() {
	only_one_child = false;
	type = NO_TYPE;
}

bool hierarchy_info::operator==(const hierarchy_info & other) const {
	return (type == other.type);
}


// TEST
/*
main() {
	tree<string> ultima("ABC");
	ultima.push_back("CDE");
	ultima.push_back("DEF");
	ultima.find_subordinate("DEF")->push_back("EFG");
	ultima.push_back("HIJ");

	if (ultima.get_subtree_direction("DEF", "EFG", false) != -1)
		cout << "Subordinate works" << endl;
	if (ultima.get_subtree_direction("EFG", "DEF", false) != -1)
		cout << "False positive" << endl;

	list<string> bfs = ultima.get_breadth_first_traversal();
	list<int> depths = ultima.get_breadth_first_depths();
	
	// should be ABC CDE DEF HIJ EFG.
	copy(bfs.begin(), bfs.end(), ostream_iterator<string>(cout, "\t"));
	cout << endl;
	// should be 0 1 1 1 2.
	copy(depths.begin(), depths.end(), ostream_iterator<int>(cout, 
				"\t"));
	cout << endl;
}
*/
#endif
