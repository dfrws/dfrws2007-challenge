#include <list>
#include <vector>
#include "slptr.h"
#include "spec.cc"
#include "chunk.cc"
#include "schunk_op.cc"
#include "equivalence.cc"

using namespace std;

#ifndef __PHANTOM_GEN
#define __PHANTOM_GEN

// No need for parallelism here.

class phantom_generator {

	public:
		// This function alters the chunk pointed at by to_complete 
		// so that it contains a parent "phantom" chunk which is
		// set to default and then have as much information as possible
		// filled in.
		virtual structured_chunk generate_phantom(
				list<tree<structured_chunk> > &	source, 
				structured_list_ptr to_complete, int uid_in)
			= 0;
		virtual chunk_id get_phantom_chunk_id() = 0;
		virtual ~phantom_generator() {}

};

class single_child_pgen : public phantom_generator {

	private:
		const specification * type_spec;
		const equivalence * all_equivalences, * asymmetric_replacements;

	public:
		single_child_pgen(const specification * type_spec_in, 
				const equivalence * all_in, const equivalence *
				asymmetry);
		chunk_id get_phantom_chunk_id();
		structured_chunk generate_phantom(list<tree<structured_chunk> >
				& source, structured_list_ptr to_complete,
				int uid_in);
};

single_child_pgen::single_child_pgen(const specification * type_spec_in, 
		const equivalence * all_in, const equivalence * asymmetry) {
	type_spec = type_spec_in;
	all_equivalences = all_in;
	asymmetric_replacements = asymmetry;
}

chunk_id single_child_pgen::get_phantom_chunk_id() {
	return(type_spec->get_type());
}

structured_chunk single_child_pgen::generate_phantom(
		list<tree<structured_chunk> > & source, 
		structured_list_ptr to_complete, int uid_in) {

	// The strategy for dealing with single generation equivalence based
	// trees is easy. We just make a default chunk of the type requested,
	// then we add the unified fields of the tree to complete over the
	// symmetric and asymmetric equivalences, breaking ties towards 
	// symmetric.
	
	// Note that the limitations on unify will become significant here.
	
	structured_chunk replace_with = type_spec->generate_blank_chunk(uid_in);
	tree<structured_chunk> artificial(replace_with);
	structured_tree_op combiner;

	artificial.subordinates.push_back(*to_complete);

	// Unify artificial, then copy the information back to replace_with.
	combiner.unify(artificial, *all_equivalences, *asymmetric_replacements,
			false);

	structured_chunk phantom = artificial.get_value();
	type_spec->synchronize_chunk(phantom);

	return(phantom);
}

#endif
