#ifndef __RIPPER
#define __RIPPER

#include <vector>
#include "tree.cc"
#include "reconst_info.cc"
#include "detected_headers.h"
#include "naive_extractor.cc"
#include "whole_verifier.cc"
#include "occupancy.cc"
#include "dump.h"

using namespace std;

class ripper {

	private:
		tree<chunk_id> derive_relation(const 
				tree<reconstructor_info> & source);

	protected:
		chunk_id unstructured_data_type;
		string format_name_short, format_name_long;
		string suggested_field;
		vector<const specification *> specs;
		auto_ptr<dumper> file_extractor;
		auto_ptr<naive_extractor> simple_extract;
		bool has_naive_extractor;

		int max_data_size, average_data_size;

	public:
		virtual ~ripper() {}
		string get_identifier() const { return(format_name_short); }
		string get_long_identifier() const { return(format_name_long); }
		string get_suggested_printable() const { return(suggested_field); }

		vector<string> get_search_strings(char wildcard);
		virtual tree<reconstructor_info> * get_coalescer_guide() = 0;
		virtual tree<chunk_id> * get_relation() = 0;

		chunk_id get_chunk_type(int string_index) const;
		template<typename inIter> structured_chunk 
			acquire_chunk(int string_index, inIter beginning, 
				inIter source, inIter end, const gi_val
				max_size, int uid) const;
		template<typename inIter> structured_chunk
			generate_unstructured_chunk(inIter beginning,
					inIter source, inIter end, const gi_val
					length, const gi_val max_size, int uid)
			const;
		bool is_chunk_sane(int string_index, const structured_chunk & 
				to_check, const gi_val max_size) const;
		bool can_dump_this(const tree<structured_chunk> & to_check)
			const;
		template<typename inIter> int get_naive_extraction_offset(
				chunk_id evidence_chunk_type, inIter beginning,
				inIter source, inIter end, 
				const file_occupancy & data_map, 
				int our_type) const;
		ostream_iterator<char> dump_tree(const tree<structured_chunk> &
				to_dump, ostream_iterator<char> 
				start_here) const;
}; 

tree<chunk_id> ripper::derive_relation(const tree<reconstructor_info> & source){
	// This turns a tree of reconstructor info classes into a tree of
	// chunk_ids. It is quite easy; we just take the "this_chunk_id" field
	// of each and generate the relation tree recursively.
	
	// current node
	tree<chunk_id> toRet(source.get_value().this_chunk_id);

	for (list<tree<reconstructor_info> >::const_iterator pos =
			source.subordinates.begin(); pos != source.subordinates.
			end(); ++pos)
		toRet.push_back(derive_relation(*pos));

	return(toRet);
}

vector<string> ripper::get_search_strings(char wildcard) {

	vector<string> footprints;

	for (int counter = 0; counter < specs.size(); counter++)
		footprints.push_back(specs[counter]->generate_search_string(
					wildcard));

	return(footprints);
}

chunk_id ripper::get_chunk_type(int string_index) const {
	if (string_index >= specs.size() || string_index < 0) return(NO_TYPE);

	return(specs[string_index]->get_type());
}

template<typename inIter> structured_chunk ripper::acquire_chunk(
		int string_index, inIter beginning, inIter source, inIter
		end, const gi_val max_size, int uid) const {

	if (string_index < 0 || string_index >= specs.size())
		return(structured_chunk(NO_TYPE));

	return(specs[string_index]->acquire_chunk(beginning, source, end,
				max_size, uid));
}

// Beware streamlike formats, because this approach doesn't lend well to it;
// if the frames are out of order, it'll happily combine them. That's what
// structured chunk and tree etc are for, but not being greedy hasn't been
// added yet.
template<typename inIter> structured_chunk ripper::generate_unstructured_chunk(
		inIter beginning, inIter source, inIter end, const gi_val 
		length, const gi_val max_size, int uid) const {

	data_container<inIter> chunk_data_struct;
	chunk_data_struct.start = source;
	chunk_data_struct.container_end = end;
	chunk_data_struct.length = min((gi_val)(end-source), min(length,
				max_size));
	chunk_data_struct.data_type = TM_COMPLETE_FILE;

	structured_chunk toRet(uid, -1, source-beginning, 
			unstructured_data_type);
	toRet.set_data("UNSTRUCT_" + get_identifier() + "_data", 
			chunk_data_struct);
	toRet.set_inst_code(-1);
	
	return(toRet);
}


bool ripper::is_chunk_sane(int string_index, const structured_chunk & 
		to_check, const gi_val max_size) const {

	if (string_index < 0 || string_index >= specs.size())
		return(false);

	return(specs[string_index]->is_sane(to_check, max_size));
}

bool ripper::can_dump_this(const tree<structured_chunk> & to_check) const {
	if (to_check.get_value().get_type() == unstructured_data_type)
		return(true);

	return (file_extractor->handles_this_hierarchy() == to_check.
			get_value().get_type());
}

template<typename inIter> int ripper::get_naive_extraction_offset(chunk_id
		evidence_chunk_type, inIter beginning, inIter source, 
		inIter end, const file_occupancy & data_map, 
		int our_uid) const {

	if (!has_naive_extractor) return(-1);
	// TODO bluesky: simple extractor that uses a range based binary
	// search to find the start and end from any chunk. However, if we don't
	// trigger on the beginning chunk, it's likely that the file is damaged
	// and thus we won't gain much. (Only if the beginning can't be 
	// detected.)
	
	if (!simple_extract->handles_this_chunk(evidence_chunk_type)) 
		return(-1);

	return(simple_extract->get_offset(beginning, source, end, data_map,
				our_uid, average_data_size, max_data_size));
}

ostream_iterator<char> ripper::dump_tree(const tree<structured_chunk> & 
		to_dump, ostream_iterator<char> start_here) const {

	if (!can_dump_this(to_dump)) return(start_here);

	// If it's unstructured, just do a straight dump
	if (to_dump.get_value().get_type() == unstructured_data_type)
		return (to_dump.get_value().dump_to_stream(start_here));

	return(file_extractor->dump_to_file(to_dump, start_here));
}

#endif
