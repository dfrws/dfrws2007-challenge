#ifndef __MAIL_HDR_VERIFY
#define __MAIL_HDR_VERIFY

#include "data_verifier.cc"
#include <vector>

using namespace std;

// For this to trigger, the chunk must start with one of "Return-path",
// "Reply-To", "Received", "Sender", "From", "Resent-Date", "Resent-Sender",
// "Resent-From", "cc", "bcc", "Message-ID", "MsgId", "Resent-Message-ID",
// "In-Reply-To", "References", "Keywords", "Subject", "Comments",
// "Encrypted", "Delivered-To", "Return-Path", "Message-Recipient", "To", or
// "Date". Brittle but should work for now.

// Note that it only checks the very beginning. This is by intent: headers
// starting at the beginning of a sector very likely constitute a new file,
// while headers inside the sector somewhere is more likely to be just another
// entry in an mbox file.

class mailhdr_verifier : public data_verifier {
	private:
		bool matches(string match_against, data_iterator pos,
				data_iterator end) const;
	public:
		transform_method get_method_handled() const { 
			return(TM_EXTP_MAIL_HEADER); }

		bool sufficient_prerequisite(const transform_method
				prerequisite) const;

		data_certificate verify_data(data_iterator beginning,
				data_iterator pos, data_iterator end,
				int max_length, double ancestral_score) const;
};

bool mailhdr_verifier::matches(string match_against, data_iterator pos,
		data_iterator end) const {
	// Just simple brute-force. Since the fields-to-match are of variable
	// length, using rkarp would be too much a bother.
	
	int counter = 0;
	data_iterator curpos;

	for (curpos = pos; curpos != end && counter < match_against.size(); 
			++curpos)
		if (match_against[counter++] != *curpos) return(false);

	return(true);
}

bool mailhdr_verifier::sufficient_prerequisite(const transform_method
		prerequisite) const {
	return (prerequisite == TM_EXTP_MAIL);
}

data_certificate mailhdr_verifier::verify_data(data_iterator beginning, 
		data_iterator pos, data_iterator end, int max_length, 
		double ancestral_score) const {
	// NOTE: Doesn't make use of max_length.
	
	// "Return-path", "Reply-To", "Received", "Sender", "From", 
	// "Resent-Date", "Resent-Sender", "Resent-From", "cc", "bcc", 
	// "Message-ID", "MsgId", "Resent-Message-ID", "In-Reply-To", 
	// "References", "Keywords", "Subject", "Comments",
	// "Encrypted", "Delivered-To", "Return-Path", "Message-Recipient", 
	// "To", or "Date".
	
	// Now commented out everything but "From" (without :) and Return-Path,
	// to dampen false positives.

	data_certificate toRet;
	toRet.outcome = VO_FAIL;
	toRet.score = compound_score(-1, ancestral_score);
	toRet.break_location = -1;

	vector<string> check_against;
	check_against.push_back("Return-path");
	check_against.push_back("From ");
	check_against.push_back("Return-Path");

	/*check_against.push_back("Reply-To");
	check_against.push_back("Received");
	check_against.push_back("Sender");
	check_against.push_back("From");
	check_against.push_back("Resent-Date");
	check_against.push_back("Resent-Sender");
	check_against.push_back("Resent-From");
	check_against.push_back("cc");
	check_against.push_back("bcc");
	check_against.push_back("Message-ID");
	check_against.push_back("MsgId");
	check_against.push_back("Resent-Message-ID");
	check_against.push_back("In-Reply-To");
	check_against.push_back("References");
	check_against.push_back("Keywords");
	check_against.push_back("Subject");
	check_against.push_back("Comments");
	check_against.push_back("Encrypted");
	check_against.push_back("Delivered-To");
	check_against.push_back("Message-Recipient");
	check_against.push_back("To");
	check_against.push_back("Date");*/

	for (int counter = 0; counter < check_against.size(); counter++)
		if (matches(check_against[counter], pos, end)) {
			toRet.score = compound_score(1, ancestral_score);
			toRet.outcome = VO_SUCCESS;
			return(toRet);
		}

	// false
	return(toRet);
}

#endif
