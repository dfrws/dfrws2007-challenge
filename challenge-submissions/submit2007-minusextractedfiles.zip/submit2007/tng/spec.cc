// Header specs. Includes functions to get from file and dump to file.
// Phantoms come later.

// Should length be long long? (For data..) Or just size_t?
// Does not support variable length knowns. (Maybe later)

// BLUESKY: Probabilistic field matching with probabilities given in
// specification_entry. But the only way we're going to get those is by
// trying over all possible headers to tweak to only getting the right ones.
// So not now.

#ifndef __SPEC
#define __SPEC

#include "detected_headers.h"
#include "data_verifier.cc"

#include "chunk.cc"
#include <vector>
#include <list>

using namespace std;

typedef enum spec_type { SPC_STRING, SPC_INTEGER, SPC_DATA };

const int SPC_REFERRED = -10;

// TODO, make string and int specific constructors so we don't have to fill
// in all the redundant pieces of info

class specification_entry {
	private:
		string keyname;		// Name of this field
		size_t length;		// Length of contents, or REFERRED if
					// given by another key
		string length_reference;// in which case this is the key
		int length_ref_offset;	// If the length field includes itself
					// or somesuch
		spec_type type;		// type of data at this position
					// string, integer, or unstructured
		vector<string> knowns;	// known values (for strings, i.e
					// signatures to look for)
		bool is_integer_lsb;	// if an integer, is it MSB?
		string default_string;
		gi_val default_integer;
					// default data is to the end of file,
					// with len 0

		void set_all(string kn_in, size_t len_in, string lref_in,
				int lrefoff_in,	spec_type type_in, 
				string known, bool is_lsb_in, 
				string default_str, gi_val default_int);
	public:
		/*specification_entry(string kn_in, size_t len_in, string lref_in,
				spec_type type_in, string known, bool
				is_lsb_in);*/
		specification_entry(string kn_in, string lref_in, 
				int lrefoff_in, spec_type type_in, 
				string known, bool is_lsb_in, 
				string default_str, gi_val 
				default_int);
		specification_entry(string kn_in, size_t len_in, spec_type 
				type_in, string known, bool is_lsb_in, string
				default_str, gi_val default_int);
		specification_entry(string kn_in, string known, 
				string default_str);

		string get_keyname() const { return(keyname); }
		int get_length() const { return(length); }
		string get_length_reference() const { return(length_reference);}
		int get_length_ref_offset() const { return(length_ref_offset); }
		spec_type get_type() const { return(type); }
		string get_known(int number) const;
		int get_num_knowns() const { return(knowns.size()); }
		bool is_lsb() const { return(is_integer_lsb); }
		string get_default_string() const { return(default_string); }
		gi_val get_default_integer() const { return(default_integer);}

		void set_keyname(string kn_in) { keyname = kn_in; }
		void set_length(size_t length_in) { length = length_in; }
		void set_length_reference(string rin) { length_reference=rin; }
		void set_length_ref_offset(int in) { length_ref_offset = in; }
		void set_type(spec_type type_in) { type = type_in; }
		void set_bit_significance(bool lsb) { is_integer_lsb = lsb; }
		void set_default_integer(gi_val in) { default_integer = in; }
		void set_default_string(string in) { default_string = in; }
		void set_known(string known_in);
		bool add_known(string known_in);

};

string specification_entry::get_known(int number) const {
	if (number >= get_num_knowns()) return("");
	else return(knowns[number]);
}

void specification_entry::set_known(string known_in) {
	if (known_in == "" || known_in.size() != length) return;
	knowns = vector<string>(1, known_in);
}

bool specification_entry::add_known(string known_in) {
	if (knowns.empty()) {
		set_known(known_in);
		return(true);
	}

	if (known_in.size() == knowns[0].size()) {
		knowns.push_back(known_in);
		return(true);
	}

	return(false);
}

void specification_entry::set_all(string kn_in, size_t len_in, 
		string lref_in, int lrefoff_in, spec_type type_in, 
		string known, bool is_lsb_in, string default_str, 
		gi_val default_int) {
	set_keyname(kn_in);
	set_length(len_in);
	set_length_ref_offset(lrefoff_in);
	set_length_reference(lref_in);
	set_type(type_in);
	add_known(known);
	set_bit_significance(is_lsb_in);
	set_default_string(default_str);
	set_default_integer(default_int);
}

// For those with length references
specification_entry::specification_entry(string kn_in, string lref_in,
		int lrefoff_in, spec_type type_in, string known, 
		bool is_lsb_in, string default_str, gi_val default_int) {
	set_all (kn_in, SPC_REFERRED, lref_in, lrefoff_in, type_in, known, 
			is_lsb_in, default_str, default_int);
}

// And for those with explicit lengths
specification_entry::specification_entry(string kn_in, size_t len_in, spec_type
		type_in, string known, bool is_lsb_in, string default_str,
		gi_val default_int) {
	set_all (kn_in, len_in, "", 0, type_in, known, is_lsb_in, default_str,
			default_int);
}

// Explicit strings with knowns
specification_entry::specification_entry(string kn_in, string known,
		string default_str) {
	set_all (kn_in, known.size(), "", 0, SPC_STRING, known, false, 
			default_str, 0);
}

// ------------------------------ //


// ABC?
// Perhaps use something different from int for chunk_type.
// TODO: Move set_type and set_inst_code into constructor, then use : for
// inherited constructors.
class specification {
	private:
		chunk_id chunk_type;
		string terse_name;	// Machine readable name
		string verbose_name;	// Human readable name
		list<specification_entry> fields;
		int inst_code; // Instantiation code

	protected:
		void set_type(chunk_id type_in) { chunk_type = type_in; }
		void set_terse(string name_in) { terse_name = name_in; }
		void set_verbose(string name_in) { verbose_name = name_in; }
		void set_inst_code(int inst_in) { inst_code = inst_in; }
		specification() {}

	public:
		bool matches_knowns(const structured_chunk & to_check) const;
		bool matches_size(const structured_chunk & to_check, const
				gi_val max_size) const;
		// max_size gives the length of the file we're ripping from
		// (times any leeway). If a size field designates a size
		// greater than this, we should consider it a false positive
		// or damaged.

		virtual bool is_sane(const structured_chunk & to_check,
				const gi_val max_length) const;
		// Crude, but should hold for now; note that we can't just
		// specify the field to look from, because that would hurt
		// GIF/JPG/whatever that has only one type of data.
		virtual transform_method identify_data_type(const 
				structured_chunk & to_check, const string 
				data_field_name) const;
		specification(chunk_id chunk_type_in, string terse_chunk_name,
				string verbose_chunk_name);
		// specification() sets UNKNOWN_TYPE
		void add_spec_entry(specification_entry to_add);

		string get_terse_name() const { return(terse_name); }
		string get_verbose_name() const { return(verbose_name); }
		int get_inst_code() const { return(inst_code); }

		string generate_search_string(char wildcard) const;
		structured_chunk generate_blank_chunk(int uid_in) const;

		// This updates data length to reflect the value of its
		// referred header. NOTE, this'll potentially capture data
		// from parts of the file not related to the chunk. If the
		// data is null, we set an unknown instead.
		bool synchronize_chunk(structured_chunk & to_change, const
				structured_chunk & referent) const;
		bool synchronize_chunk(structured_chunk & to_change) const;

		chunk_id get_type() const { return(chunk_type); }
		template<typename inIter> structured_chunk acquire_chunk(inIter
				beginning, inIter source, inIter end, const
				gi_val max_length, int uid_to_assign) const;

		virtual ~specification () {}
};

bool specification::matches_knowns(const structured_chunk & to_check) const {
	// For all strings
	//  For all knowns
	//   If the string matches the known, we're OK, continue
	//  If none do, we're not, return false

	for (list<specification_entry>::const_iterator pos = fields.begin();
			pos!= fields.end(); pos++) {

		if (pos->get_type() == SPC_STRING) {
			bool matches = false;

			// if there are no knowns, there is nothing to match
			// against, so OK
			if (pos->get_num_knowns() == 0) continue;

			for (int counter = 0; counter < pos->get_num_knowns()
					&& !matches; counter++)
				if (to_check.get_string(pos->get_keyname()) ==
						pos->get_known(counter))
					matches = true;

			if (!matches) return(false);
		}
	}

	return(true);
}

bool specification::matches_size(const structured_chunk & to_check, const
		gi_val max_size) const {

	// First check whether the chunk is too large plain and simple
	// (Warning, could take some time)
	if (to_check.size() > max_size) return(false);

	// Then check that none of the fields used for size references (later)
	// are out of bounds
	for (list<specification_entry>::const_iterator pos = fields.begin();
			pos!= fields.end(); pos++)
		if (pos->get_length() == SPC_REFERRED)
			if (to_check.has_integer(pos->get_length_reference()))
				if (to_check.get_integer(pos->
							get_length_reference())
							- pos->get_length_ref_offset()
						> max_size) return(false);

	return(true);
}

// default: always report true if the knowns are correct, otherwise false. 
// Probably change this to pure virtual later
bool specification::is_sane(const structured_chunk & to_check, const gi_val
		max_length) const {
	return(matches_knowns(to_check) && matches_size(to_check, max_length));
	//return(true);
}

transform_method specification::identify_data_type(const structured_chunk & 
		to_check, string data_field_name) const {
	cout << "Called IDD native" << endl;
	return(TM_UNKNOWN);
}

specification::specification(chunk_id chunk_type_in, string terse_in,
		string verbose_in) {
	chunk_type = chunk_type_in;
	set_terse(terse_in);
	set_verbose(verbose_in);
}

void specification::add_spec_entry(specification_entry to_add) {
	fields.push_back(to_add);
}

// Handle cases with multiple defaults later
// Also handle case sensitive etc later (though case insensitive headers aren't
// really the right way to do it)
// BLUESKY: Make this bitwise.
string specification::generate_search_string(char wildcard) const {
	// For each entry:
	// 	get length of field
	// 		If the length is specified by an earlier number,
	// 		return the search string we've got, since we can't
	// 		deduce at what location something appears afterwards
	// 		anyway
	// 	If there's a known, add that known to the string
	// 	else add as many wildcards as required to fit length
	
	// Also cut the string to the end of the last known so that long
	// strings with lots of unknowns at the end gets chopped to a
	// managable size.

	string toRet = "";
	int last_known_end_pos = 0;

	for (list<specification_entry>::const_iterator pos = fields.begin();
			pos != fields.end(); pos++) {
		if (pos->get_length() == SPC_REFERRED) {
			return(string(toRet, 0, last_known_end_pos));
		}
		if (pos->get_num_knowns() > 0) {
			toRet += pos->get_known(0);
			last_known_end_pos = toRet.size();
		}
		else	toRet += string(pos->get_length(), wildcard);
			//pos->get_known(0);
	}

	return(string(toRet, 0, last_known_end_pos));
}


// Generate a chunk with all default values.
// For phantom header generation, etc.
structured_chunk specification::generate_blank_chunk(int uid_in) const {

	structured_chunk toRet(uid_in, chunk_type);

	// For each specification field entry
	//	 check what data type it is, then pick the right default and
	//	 set.

	for (list<specification_entry>::const_iterator pos = fields.begin();
			pos!= fields.end(); pos++) {

		switch (pos->get_type()) {
			case SPC_STRING:
				toRet.set_string(pos->get_keyname(), 
						pos->get_default_string());
				break;
			case SPC_INTEGER:
				toRet.set_integer(pos->get_keyname(),
						pos->get_default_integer(),
						pos->is_lsb(), pos->
						get_length());
				break;
			case SPC_DATA:
				// What's the point of this, you may ask.
				// While the data resolves to the same as a key
				// that doesn't exist at all (null value), it
				// keeps the relative location of the data in
				// the header, so that adding data will
				// preserve the ordering of the header/chunk.
				toRet.set_undiscovered_data(pos->get_keyname(),
						0);
				break;
		}
	}

	// Alter the length of any indirect fields
	synchronize_chunk(toRet);

	return(toRet);
}

// TODO, use equivalent
bool specification::synchronize_chunk(structured_chunk & to_change,
		const structured_chunk & from) const {

	// For each entry of the spec,
	// if that entry is a referred field
	// 	get the value of its referent
	// 	and set the size appropriately.

	 for (list<specification_entry>::const_iterator pos = fields.begin();
			   pos!= fields.end(); pos++) {

		 int len = pos->get_length();
		 if (len != SPC_REFERRED) continue;

		 if (from.has_integer(pos->get_length_reference()))
			  len = from.get_integer(pos->get_length_reference()) -
				  pos->get_length_ref_offset();

		 string key = pos->get_keyname();
		 if (!to_change.has_defined_field(key)) continue;

		 // Probably IAGNI, but wth.
		 switch(pos->get_type()) {
			 case SPC_STRING:
				 to_change.set_string(key, to_change.get_string(
							 key));
				 break;
			 case SPC_INTEGER: {
				 generic_int p = to_change.get_gen_integer(key);
				 p.set_size(len);
				 to_change.set_gen_integer(key, p);
				 break; }
			 case SPC_DATA:
				to_change.set_data(key, to_change.
						get_data_location(key), 
						to_change.
						get_data_container_end(key), 
						len, 
						to_change.get_data_type(key));
				break;
                }
	 }

	 return(true);
}

bool specification::synchronize_chunk(structured_chunk & to_change) const {
	cout << "Call synch chunk" << endl;

	return(synchronize_chunk(to_change, to_change));
}

// Returns an empty chunk if sanity check failed
template<typename inIter> structured_chunk specification::acquire_chunk(inIter
		beginning, inIter source, inIter end, const gi_val
		max_length, int uid_to_assign) const {

	inIter cur = source;
	structured_chunk toRet(uid_to_assign, inst_code, source-beginning, 
			chunk_type);
	structured_chunk empty_chunk(uid_to_assign);

	if (source < beginning || source > end) return(empty_chunk);

	list<string> data_strings;

	for (list<specification_entry>::const_iterator pos = fields.begin();
			pos!= fields.end() && cur < end; pos++) {
		// If it's referential then get length from the key, otherwise
		// get length directly
		int len = pos->get_length();
		if (len == SPC_REFERRED) {
			// Sanity check goes here
			if (toRet.has_integer(pos->get_length_reference()))
				if (is_sane(toRet, max_length))
					len = toRet.get_integer(pos->
						get_length_reference()) -
						pos->get_length_ref_offset();

			// Go here if we don't pass the sanity check.
			if (len == SPC_REFERRED) len = 0;
		}

		switch(pos->get_type()) {
			case SPC_STRING:
	/*			cout << "String " << pos->get_keyname() << " len " << len << endl;*/
				cur = toRet.set_string(pos->get_keyname(),
						cur, end, len);
				break;
			case SPC_INTEGER:
	/*			cout << "Integer " << pos->get_keyname() << " len " << len << endl;*/
				cur = toRet.set_integer(pos->get_keyname(), cur,
						end, pos->is_lsb(), len);
	/*			cout << "\tvalue " << toRet.get_integer(pos->get_keyname()) << endl;*/
				break;
			case SPC_DATA:
				if (toRet.set_data(pos->get_keyname(), cur, end,
							len, TM_UNKNOWN)) {
					data_strings.push_back(pos->
							get_keyname());
					// was pos->get_length() which of course
					// went boom if SPC_REFERRED
					cur += len;
				}
				break;
		}
	}

	//cout << "Number One" << endl;
	if (!is_sane(toRet, max_length)) {
	//	cout << "Acquire: Error in final sanity check" << endl;
		return(empty_chunk);
	}
	//else	return(toRet);

	// Finally, set the data, now that we have all the other chunks in 
	// place. TODO: Extend this so we can get the data type from unification
	// or whatever. Maybe move the query into chunk..
	
	for (list<string>::const_iterator dname_pos = data_strings.begin();
			dname_pos != data_strings.end(); ++dname_pos) {
		toRet.set_data(*dname_pos, toRet.get_data_location(*dname_pos),
				toRet.get_data_container_end(*dname_pos),
				toRet.get_data_length(*dname_pos), 
				identify_data_type(toRet, *dname_pos));
	}

	return(toRet);
}

#endif

// More testing
/*
main() {
	specification file_hdr(PK_FILE_HEADER);
	file_hdr.add_spec_entry(specification_entry("PK_signature", 4, 
				SPC_STRING, "PK\3\4", true, "PK\3\4", 0));
	file_hdr.add_spec_entry(specification_entry("PK_ver_needed", 2, 
				SPC_INTEGER, "", true, "", 20)); // zip 2.0
	file_hdr.add_spec_entry(specification_entry("PK_general_bitfield", 2,
				SPC_INTEGER, "", true, "", 0));
	file_hdr.add_spec_entry(specification_entry("PK_compression_method", 2,
				SPC_INTEGER, "", true, "", 8)); // deflate
	file_hdr.add_spec_entry(specification_entry("PK_lastmod_time", 2, 
				SPC_INTEGER, "", true, "", 0)); // MSDOS format
	file_hdr.add_spec_entry(specification_entry("PK_lastmod_date", 2,
				SPC_INTEGER, "", true, "", 0));
	file_hdr.add_spec_entry(specification_entry("PK_CRC32", 4,
				SPC_INTEGER, "", true, "", 0));
	file_hdr.add_spec_entry(specification_entry("PK_comp_size", 4,
				SPC_INTEGER, "", true, "", 0));
	file_hdr.add_spec_entry(specification_entry("PK_uncomp_size", 4,
				SPC_INTEGER, "", true, "", 0));
	file_hdr.add_spec_entry(specification_entry("PK_fnlen", 2, 
				SPC_INTEGER, "", true, "", 7));
	file_hdr.add_spec_entry(specification_entry("PK_efield_len", 2,
				SPC_INTEGER, "", true, "", 0));
	file_hdr.add_spec_entry(specification_entry("PK_filename", "PK_fnlen",
				SPC_STRING, "", true, "DEFAULT", 0));
	file_hdr.add_spec_entry(specification_entry("PK_extrafield", 
				"PK_efield_len", SPC_STRING, "", true, "", 0));

	cout << "Search string: " << file_hdr.generate_search_string('?') <<
		endl;

	file_char_prod * fcp = new file_char_prod("hah.zip");
	SGI::crope file_access(fcp, fcp->len(), true);

	structured_chunk ffh = file_hdr.acquire_chunk(file_access.begin(), file_access.begin(), file_access.end());

	// Out
	ofstream recover("out.hzip");
	ffh.dump_to_stream(ostream_iterator<char>(recover));
}*/
