// Quick and dirty PNG coalescer.
// The strategy is as follows: Find an empty IHDR. If we find one, go downwards
// to find an empty IEND. If neither are found, we can't coalesce the chunk.
// Otherwise, add everything in between in this order:
// 	IHDR first, then (if any) {cHRM, gAMA, sBIT, PLTE, oFFS, pHYs, sCAL}, 
// 	then (if any) {bKGD, hIST, tRNS}, then IDATs, then IEND.
// The following chunks are permitted anywhere:
// 	tIME, tEXt, zTXt, fRAc, gIFg, gIFt, gIFx.

// The resulting chunk has IHDR first and then the first level as subordinates,
// the second level as subordinate to the last of the first, and the third
// level as subordinate to the last of the second, to make output easy.

#ifndef __IMPROV_PNG_COALESCE
#define __IMPROV_PNG_COALESCE

#include <deque>
#include "slptr.h"
#include "chunk.cc"
#include "tree.cc"
#include "ind_coalesc.cc"
#include "map_utils.cc"

class qnd_png_coalescer : public individual_coalescer {

	private:
		structured_list_ptr needle_max, endwise_closer;
		int gap;
		list<structured_list_ptr> viables (map<chunk_id, bool> &
				admitted_types, structured_list_ptr begin,
				structured_list_ptr end);
		void mark_level(const list<structured_list_ptr> & positions,
				list<int> & to_mark, int level_number, 
				structured_list_ptr begin, 
				structured_list_ptr end);

	public:
		void start_combining(list<tree<structured_chunk> > &
				to_coalesce, structured_list_ptr candidate);

		strategy_response try_next_strategy();

		individual_coalescer * make_new() const {
			return (new qnd_png_coalescer()); }

};

list<structured_list_ptr> qnd_png_coalescer::viables (map<chunk_id, bool> &
		admitted_types, structured_list_ptr begin,
		structured_list_ptr end) {

	// From begin to end, if the current position is one in admitted_types,
	// add that position to the return list.
	
	list<structured_list_ptr> toret;

	for (structured_list_ptr current = begin; current != end; ++current)
		if (lookup_default(current->get_value().get_type(),
					admitted_types, false))
			toret.push_back(current);

	return(toret);
}

// This marks the hierarchy level in a list of integers. The assumptions are
// that positions are drawn from the same list that beginning and end are, and
// that positions is in sorted position order (i.e if a is closer to begin than
// b, then a shows up before b).
void qnd_png_coalescer::mark_level(const list<structured_list_ptr> & positions,
		list<int> & to_mark, int level_number, structured_list_ptr
		begin, structured_list_ptr end) {

	// Will this work?

	list<int>::iterator cur_mark_pos = to_mark.begin();
	list<structured_list_ptr>::const_iterator pointer_pos = 
		positions.begin();
	structured_list_ptr outer_loop = begin;
	while (outer_loop != end && pointer_pos != positions.end()) {
		while (outer_loop != *pointer_pos) {
			outer_loop++;
			cur_mark_pos++;
		}
		*cur_mark_pos = level_number;
		++pointer_pos;
	}
}

void qnd_png_coalescer::start_combining(list<tree<structured_chunk> > &
		to_coalesce, structured_list_ptr candidate) {
	cur_needle = candidate;
	endwise_closer = cur_needle;
	needle_max = to_coalesce.end();
	has_needle = true;
	gap = 0;
}

strategy_response qnd_png_coalescer::try_next_strategy() {

	// If we don't have a candidate or the candidate isn't an IHDR,
	// forget about it.

	if (!has_needle) return(STRAT_NO_NEEDLE);
	if (cur_needle->get_value().get_type() != PNG_INIT_HEADER) 
		return(STRAT_FAILURE);

	// Now check if the endwise closer pointer (which we're incrementing to
	// find an IEND) is at the end. If so, we didn't find any IEND and so
	// we fail. (QND!)
	
	if (endwise_closer == needle_max) return(STRAT_FAILURE);
	// If it's not a PNG trailer, go closer to the end and return
	// uncertainty.
	if (endwise_closer->get_value().get_type() != PNG_TRAILER) {
		endwise_closer++;
		++gap;
		return(STRAT_UNCERTAIN);
	}

	// If we get here, it's an IEND.
	// Now check if the chunks we need are in here. We need (at minimum)
	// IHDR, PLTE (if indexed), IDAT, and IEND.
	
	int color_type = cur_needle->get_value().get_integer("PNG_colortype");
	bool indexed = (color_type == 3);

	// The following chunks are permitted anywhere:
	// tIME, tEXt, zTXt, fRAc, gIFg, gIFt, gIFx.
	// Handling the optionals in an order-preserving manner will be hard.
	// To do it, we'll make a list of the correct hierarchy position and
	// then travel from the top down, adding the optionals to the last
	// level we saw (before adding the subtrees).
	// NOTE that if the chunks are dispersed between say, different IDAT
	// chunks, then this will coalesce them all at the beginning. Doing it
	// otherwise is too costly.
	list<int> level_markers(gap, -1);

	map<chunk_id, bool> first_req, second_req, third_req, fourth_req;
	first_req[PNG_INIT_HEADER] = true;
	second_req[PNG_PALETTE] = true;
	third_req[PNG_IMAGE_DATA] = true;
	fourth_req[PNG_TRAILER] = true;

	// first and fourth aren't strictly necessary since we already checked
	// for PNG_INIT_HEADER and PNG_TRAILER, but they're here for 
	// completeness purposes.
	structured_list_ptr after_last = endwise_closer;
	++after_last;

	if (viables(first_req, cur_needle, after_last).empty())
		return(STRAT_FAILURE);
	if (indexed)
		if (viables(second_req, cur_needle, after_last).empty())
			return(STRAT_FAILURE);
	if (viables(third_req, cur_needle, after_last).empty())
		return(STRAT_FAILURE);
	if (viables(fourth_req, cur_needle, after_last).empty())
		return(STRAT_FAILURE);

	// IHDR first, then (if any) {cHRM, gAMA, sBIT, PLTE, oFFS, pHYs, sCAL},
	// then (if any) {bKGD, hIST, tRNS}, then IDATs, then IEND.

	vector<map<chunk_id, bool> > levels(5);
	levels[0][PNG_INIT_HEADER] = true;
	levels[1][PNG_CHROMA] = true;
	levels[1][PNG_GAMMA] = true;
	levels[1][PNG_SBIT] = true;
	levels[1][PNG_PALETTE] = true;
	levels[1][PNG_OFFSET] = true;
	levels[1][PNG_PHYS] = true;
	levels[1][PNG_SCALE] = true;
	levels[2][PNG_BACKGROUND] = true;
	levels[2][PNG_HISTORY] = true;
	levels[2][PNG_TRANS] = true;
	levels[3][PNG_IMAGE_DATA] = true;
	levels[4][PNG_TRAILER] = true;

	vector<list<structured_list_ptr> > level_resolution(levels.size());
	for (int counter = 0; counter < level_resolution.size(); ++counter) {
		level_resolution[counter] = viables (levels[counter], 
				cur_needle, after_last);
		mark_level(level_resolution[counter], level_markers, counter, 
				cur_needle, after_last);
	}

	// Okay, we've made the pointers for the level-set chunks. Now figure
	// out where the optionals (those that can be at any level) go.
	// tIME, tEXt, zTXt, fRAc, gIFg, gIFt, gIFx.
	map<chunk_id, bool> optionals;
	//vector<list<structured_list_ptr> > level_optionals(levels.size());

	vector<list<tree<structured_chunk> > > tree_for_this_level(levels.
			size());
	optionals[PNG_TIME] = true;
	optionals[PNG_COMMENT] = true;
	optionals[PNG_COMP_COMMENT] = true;
	optionals[PNG_FRACTION] = true;
	optionals[PNG_GIFG] = true;
	optionals[PNG_GIFT] = true;
	optionals[PNG_GIFX] = true;
	list<int>::const_iterator cur_level_mark = level_markers.begin();
	structured_list_ptr cur_lp = cur_needle;
	int last_level_mark = -1;
	
	// If it's an optional, it'll have a cur level mark of -1, in which
	// case we should assign it to the level we last saw. Otherwise, assign
	// it to the level it says!
	while (cur_lp != after_last) {
		cout << last_level_mark << "\t" << *cur_level_mark << "\t" << cur_lp->get_value().get_type() << endl;
		if (*cur_level_mark != -1) {
			last_level_mark = *cur_level_mark;
			cout << "Adding TFT " << last_level_mark << " of " << tree_for_this_level.size() << endl;
			tree_for_this_level[last_level_mark].push_back(*cur_lp);
			// Don't pull the rug off our feet!
			// TODO: Handle this better (the real cause is that
			// we're treating the IHDR as level 0 while it shouldn't
			// be subject to this process.
			if (cur_lp != cur_needle)
				cur_lp->set_redundancy(true);
		} else {
			if (lookup_default(cur_lp->get_value().get_type(),
						optionals, false)) {
				cout << "Adding TFT " << last_level_mark << " of " << tree_for_this_level.size() << endl;
				tree_for_this_level[last_level_mark].
					push_back(*cur_lp);
				cur_lp->set_redundancy(true);
			}
		}

		++cur_lp;
		++cur_level_mark;
	}

	// Now assign all of level two's stuff onto level one. Then assign all
	// of level three's stuff onto level two, and so on.
	
	list<tree<structured_chunk> >::const_iterator to_add_pos;
	tree<structured_chunk> * to_add_to = &*cur_needle;

	for (int cur_level = 1; cur_level < tree_for_this_level.size();
			cur_level++) {

		for(to_add_pos = tree_for_this_level[cur_level].begin(); 
				to_add_pos != tree_for_this_level[cur_level].
				end(); ++to_add_pos) {
			cout << "Tapping" << endl;
			to_add_to->subordinates.push_back(*to_add_pos);
		}
		
		if (!to_add_to->subordinates.empty()) {
			cout << "Switching at level " << cur_level << endl;
			cout << "The count is " << to_add_to->subordinates.size() << endl;
			cout << "And the count for cur needle is " << cur_needle->subordinates.size() << endl;
			to_add_to = &(to_add_to->subordinates.back());
		}
	}

	// PHEW! Done. Just mark the composite as something we coalesced..
	cur_needle->set_as_combined();

	return(STRAT_SUCCESS);
}

#endif
