#include <iostream>
#include <fstream>
#include <ext/rope>
#include <errno.h>
#include <exception>

namespace SGI = ::__gnu_cxx;		// GCC 3.1 and later
using namespace std;

void fail(string s) {
	cerr << "File access error: " << s << " errno " << errno << endl;
	exit(1);
}

class file_char_prod : public SGI::char_producer<char> {
	private:
		fstream file_handle;

		void open_file(string filename, std::_Ios_Openmode settings) {
			file_handle.open(filename.c_str(), settings);
			if (!file_handle)
				fail("Could not open file '" + filename + "'!");
		}

		/*file_char_prod(string filename, std::_Ios_Openmode settings) {
			open_file(filename, settings);
		}*/

	public:

		// Default settings for input
		file_char_prod(string filename) {
			open_file(filename, ios::in | ios::binary);
		}

		virtual void operator() (size_t start_pos, size_t length,
				char * output_buffer) {
			try { file_handle.seekg(start_pos, ios::beg); }
			catch(ios_base::failure) {
				fail("Could not seek in file"); 
			}
			try { file_handle.read(output_buffer, length); }
			catch(ios_base::failure) {
				fail("Could not read from file");
			}
		}

		// unfortunately, rope forces this to size_t.
		uint64_t len() {
			// This is the only way you can do it in C++
			// Seek to the end, then note the position and seek
			// back (latter not required in the rope)
			try { file_handle.seekg(0, ios::end); }
			catch(ios_base::failure) { 
				fail("Could not seek in file"); 
			}
			return(file_handle.tellg());
		}
};

//Na na na na na na na UNIT-TEST!

/*
main() {
	file_char_prod * fcp = new file_char_prod("check");
	SGI::rope<char> file_access(fcp, fcp->len(), true);

	size_t len = file_access.size();
	SGI::crope middle = file_access.substr(len/2 - 100, 200) + "\n";
	cout << middle.c_str() << endl;
} */
