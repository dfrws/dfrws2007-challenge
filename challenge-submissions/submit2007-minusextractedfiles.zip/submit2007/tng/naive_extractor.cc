// This class finds an offset for a naive extraction, given a file_verifier
// that supports it. A naive extraction is basically just a binary search
// fed into some file verifier (not data verifier); if we find a chunk so that 
// it passes the verifier, then presumably that's a valid file and we don't
// need to build the structure from the bottom up.

#ifndef __NAIVE_EXTR
#define __NAIVE_EXTR

#include "whole_verifier.cc"
#include <assert.h>
#include <iostream>

using namespace std;

class naive_extractor {

	private:
		whole_verifier * to_check_against;
		chunk_id handles_this;

	public:
		naive_extractor(whole_verifier * to_check_against_in, chunk_id
				based_off_this);
		chunk_id chunk_handled() { return(handles_this); }
		bool handles_this_chunk(chunk_id test) { return(test==handles_this); }
		int get_offset(data_iterator beginning, data_iterator pos,
				data_iterator end, const file_occupancy &
				data_map, int our_type, int average_length,
				int maximum_length);
};

naive_extractor::naive_extractor(whole_verifier * to_check_against_in,
		chunk_id based_off_this) {
	assert(to_check_against_in != NULL);
	to_check_against = to_check_against_in;
	handles_this = based_off_this;
}

// or -1 if none
// Now uses a more reasonable initial guess since the evaluation is so slow.
int naive_extractor::get_offset(data_iterator beginning, data_iterator pos, 
		data_iterator end, const file_occupancy & data_map, 
		int our_type, int average_length, int maximum_length) {

	if (maximum_length == -1) maximum_length = end - pos;
	if (maximum_length > end - pos) maximum_length = end - pos;

	// Now do an iterative binary search to figure out the offset. Check
	// if the CONSTRAINT mentioned in file_verifier holds first.
	
	if (!to_check_against->can_narrow_down()) return(-1);

	int low_in = 0, high_in = maximum_length;

	// First check if we get an error at maximum length. If we do, there's
	// no point in narrowing down.

	cout << "Checking at max size of " << maximum_length << endl;
	if (to_check_against->verify_entirety(beginning, pos, end, 
				data_map, our_type, maximum_length) != 
			WV_SUCCESS) {
		cout << "Naive extractor failed even at max size." << endl;
		return(-1);
	}

	// These boundary cases are used to see if we didn't find anything.
	int low = low_in - 1;
	int high = high_in + 1;

	cout << "Binary search: " << flush;

	bool first = true;

	while (high - low > 1) {
		unsigned int mid;
		if (first) {
			mid = min(average_length, maximum_length);
			first = false;
		} else
			mid = (unsigned)(low + high) >> 1;

		cout << low << ", " << mid << ", " << high << "\t" << flush;

		whole_verifier_outcome round_outcome = to_check_against->
			verify_entirety(beginning, pos, end, data_map,
					our_type, mid);

		if (round_outcome == WV_ALLOC_ERROR) {
			cout << endl;
			return(-1);
		}

		// If it wasn't a success, we're using a too short length, so
		// move low higher to increase it. Otherwise, decrease.
		if (round_outcome != WV_SUCCESS)
			low = mid;
		else	high = mid;
	}
	cout << endl;

	if (high == low_in - 1 || high == high_in + 1) {
		// Couldn't find anything
		return(-1);
	}

	return(high);
}

#endif
