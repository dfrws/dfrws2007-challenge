// YIKES: 23 secs on pii250out. Used to be 14 before the restructuring.
// Expensive collapses.
// (You thought that was bad? Now it's 30 seconds on pii250out. I don't care,
//  because I'm not rated on time.)

// Fix problem where ENDDIR coalesces with a DIR_ENTRY/FILE_HEADER/FILE_FOOTER.
// Symptomatic of that I don't have verifiers *outside* of the operation, and
// that we don't have any reasoning of the sort "hey, if this uses a different
// coalescer, stay away from it!"
// Oh well, kludge it by adding a third CM_* type, CM_NONE, which means "you
// can't combine with this".

// And fix the problem with phantoms in chkphantom.zip (5KB? Isn't it 
// supposed to be 2.4?) DONE - it was 5K.

// TODO: mark print_sectors with I or something if it starts inside the sector.

// Problems with principle of exclusion ripper wrt test/roar and doc files.

#include "zip_specs.cc"
#include "rkarp.cc"
#include "unique_substrings.cc"
#include "tree.cc"
#include "equivalence.cc"
#include "simple_utility.cc"
#include "schunk_op.cc"
#include "equiv_consistency.cc"
#include "zspecial_consistency.cc"
#include "ind_coalesc.cc"
#include "zip_enddir_coalesce.cc"
#include "phantom.cc"
#include "reconst_info.cc"
#include "rippers.cc"
#include "zip_ripper.cc"
#include "informal_png.cc"
#include "informal_jpeg.cc"
#include "informal_pdf.cc"
#include "informal_doc.cc"
#include "occupancy.cc"
#include "deflate_verifier.cc"
#include "text_verifier.cc"
#include "logcompare_verifier.cc"
#include "mail_header_verifier.cc"
#include "data_ripper.cc"
#include "bmp_ripper.cc"

#include <iostream>
#include <sstream>
#include <vector>
#include <map>

#include <time.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <assert.h>
#include "src_md5/md5.cc"

using namespace std;

string rand_string(int len) {

	string p;

	for (int counter = 0; counter < len; counter++)
		if (random()%2 == 0)
			p += random()%26 + 'a';
		else	p += random()%26 + 'A';
	return(p);
}

// time
double get_time() {
	timeval tv;
	if (gettimeofday(&tv, NULL) == 0)
		return (tv.tv_sec + tv.tv_usec/1e6);
	else	return (0);
}

string itos(long long number) {
	ostringstream xav;
	xav << number;
	return(xav.str());
}

string itos(int number, size_t padding) {
	string retval = itos(number);
	while (retval.size() < padding) retval = "0" + retval;
	return(retval);
}

string itohexs(long long number) {
	ostringstream xav;
	xav << hex << number;
	return(xav.str());
}

string hhmmss(unsigned int timeval) {
	unsigned int seconds = timeval % 60;
	timeval = (timeval - seconds)/60;
	unsigned int minutes = timeval % 60;
	timeval = (timeval - minutes)/60;
	unsigned int hours = timeval;

	return (itos(hours, 2) + ":" + itos(minutes, 2) + ":" + 
			itos(seconds, 2));
}

double remaining_time(double started_at, double now, 
		double fraction_done) {
	return(( (now-started_at) /fraction_done ) * (1-fraction_done));
}

string eta(double started_at, double now, double fraction_done) {
	/*unsigned int remaining = (unsigned int) round(( (now-started_at) / 
				fraction_done ) * (1-fraction_done));*/

	return (hhmmss((unsigned int)round(remaining_time(started_at, now, 
						fraction_done))));
}

string get_filename(string path) {
	// First seek from the end to the beginning.
	// Then copy everything from (but not including) the last backslash
	// to the end, copying the entire path string if there are none.
	
	int counter;
	for (counter = path.size()-1; counter >= 0; counter--)
		if (path[counter] == '/') break;

	string filename;
	copy (path.begin() + counter + 1, path.end(), inserter(filename, 
				filename.end()));

	return(filename);
}

template<typename T> void deallocate_vector(vector<T *> & in) {

	while (!in.empty()) {
		delete in.back();
		in.pop_back();
	}
}

template<typename T> void deallocate_tree(tree<T *> & in) {

	if (in.get_value() != NULL)
		delete in.get_value();

	for (typename list<tree<T *> >::iterator p = in.subordinates.begin();
			p != in.subordinates.end(); ++p)
		deallocate_tree(*p);
}

string md5(istream & stream) {
	string to_ret;

	char * digest_ascii;
	MD5 check_util(stream);
	digest_ascii = check_util.hex_digest();
	for (int counter = 0; counter < 32; ++counter)
		to_ret.push_back(digest_ascii[counter]);

	return(to_ret);
}

// DEBUG
string chunk_name(const structured_chunk & p) {
	string to_ret = "[" + itos(p.get_type()) + ", " + p.get_string("PK_filename") + ", " + itohexs(p.get_integer("PK_CRC32")) + "]";

	return(to_ret);
}

// Multiple coalescing function: given an originator and a group (set) of
// pointers to trees that may fit, check each and add them. If there are more
// than one, the one with the highest equivalence score wins; that is, the one
// that has most matching fields wrt the originator.
// After we've found the record (candidate), join them and replace the parent
// (the one with a member closest to the root) with the joined structure and
// mark the other component for deletion.
// NOTE: We work on pointers once and twice removed, so any intricate copy
// constructors on the trees themselves lead to a lot of subtle bugs. Just
// don't do it, folks. (TODO: Disentangle the pointer madness.)
// HINT: If there's only one alternative and we know that the chunk has
// passed equivalence check, then we don't need to actually calculate how many
// fields of all_equiv the candidate matches.

// Consistency rules: Minimum of the consistency of children unless special
// requirements are needed (such as with FILE_FOOTER).
// Consistency rule for a simple tree: the tree is consistent if there are
// no collisions in equivalent space, i.e all equivalent fields have the same
// value.
// TODO: Add hints to only check merged parts for consistency.
// Returns -1 if inconsistent, otherwise 0 or greater.
// TODO: Fix fast and loose handling of recursed values. Possibly use min(x,y),
// but that doesn't handle situations with normal where we're trying to find
// a record match because the record may be obscured by other parts of the
// hierarchy. But neither does using max; the only solution is to have an
// auxiliary tree mark what chunks we're going to look at.
// Theoretical optimum (local optimum): for all the chunk relations whose
// consistency number changed after the join, return the sum of those, so that
// the maximum wins. (Multidimensional version: if A pareto-dominates B, A
// wins. Probably not needed)
// If joining small chunks should afford no greater benefit than joining large
// chunks, set hyperbolic to true.

list<individual_coalescer *>::iterator erase_coalescer(
		list<individual_coalescer *>::iterator position, 
		list<individual_coalescer *> & remove_from) {
	delete *position;
	return (remove_from.erase(position));
}

void coalesce_single_round(list<tree<structured_chunk> > & to_coalesce,
		list<individual_coalescer *> & our_coalescers,
		list<tree<structured_chunk> * > & success) {

	for (list<individual_coalescer *>::iterator cpos = our_coalescers.
			begin(); cpos != our_coalescers.end(); ++cpos) {

		structured_list_ptr needle = (*cpos)->get_needle();

		if (needle->was_recently_combined() || needle->
				is_redundant()) {
			cout << "Redundancy detected." << endl;
			cpos = --erase_coalescer(cpos, our_coalescers);
			continue;
		}

		strategy_response result = (*cpos)->try_next_strategy();

		switch(result) {
			case STRAT_SUCCESS:
				cout << "VII: Success" << endl;
				success.push_back(&*needle);
			case STRAT_FAILURE:
				// We either failed or succeeded; in either
				// case, there's no need for the coalescer
				// anymore.
				cpos = --erase_coalescer(cpos, our_coalescers);
				continue;
			case STRAT_NO_NEEDLE:
				cerr << "Coalescer failure: needle expected "<<
					"but not found!" << endl;
				exit(1);
			default:
				break;
		}

		if (needle->was_recently_combined() || needle->
				is_redundant()) {
			cout << "Strategy changed needle. Erasing." << endl;
			cpos = --erase_coalescer(cpos, our_coalescers);
			continue;
		}
	}
}
	
// PLAN: Coalesce takes an individual_coalescer * (fully constructed) as input.
// It copies it so to have one for each entry (all, not just the right types).
// Then it executes, assuming that the individual coalescers will know if 
// they're staring at the wrong type. The problem is that the individual
// coalescers don't necessarily know this, and may apply the wrong combination.
// (E.g if ENDDIR_HEADER is superordinate to DIR_HEADER and there are no
// equivalents, the hypothesis coalescer might think it's okay to stick the
// EDH on top of the DIR_HEADER.. or would it?) No, because otherwise we'd seen
// that problem already. But in general, there must be error checking on the
// individual coalescer end.
// So go ahead with this plan. And start documenting the code before I forget
// what the functions actually do.
// TODO: Make archetype const? It's the right thing to do. 
// (Future planning: Once done, check failed for the rightmost (leafmost)
//  chunk. This'll let us skip up the tree if a lower coalescer handled all
//  of the higher type. Or just do that O(nm) by checking, for each type,
//  if that type exists in the failed list. (can't be all list because
//  FILE_HEADER leafwards closer than DIR_HEADER yet DIR_HEADER would pick up
//  on the already-coalesced ones.)
// (Future planning, II: If no phantoms were generated, there's no need to run
//  coalesce again, so skip to the next type -- if the coalescer for the type
//  we were to run is equal to the last one.)
int coalesce_generic(const individual_coalescer * archetype, 
		list<tree<structured_chunk> > & to_coalesce,
		set<tree<structured_chunk> * > & success) {

	// Beware, O(n)
	int distinct_hierarchies_before = to_coalesce.size();

	list<individual_coalescer *> coalescers_for_this;
	list<tree<structured_chunk> >::iterator tc_pos;

	// First generate our coalescers

	for (tc_pos = to_coalesce.begin();tc_pos != to_coalesce.end();++tc_pos){
		individual_coalescer * new_coalescer = archetype->make_new();
		new_coalescer->start_combining(to_coalesce, tc_pos);
		coalescers_for_this.push_back(new_coalescer);
	}

	// Then while there are any left that haven't succeeded or failed,
	// keep on trying.
	
	list<tree<structured_chunk>* > succeeded_here;

	while (!coalescers_for_this.empty())
		coalesce_single_round(to_coalesce, coalescers_for_this,
				succeeded_here);

	cout << "Successes at exit: " << success.size() << endl;

	// Finally, remove redundant chunks and clear combined status.
	// We have to first do that with failed because if we removed the
	// chunks from to_coalesce first, failed, as iterators, would lose
	// their footing and we'd no way of seeing which ones were redundant.
	
	for (list<tree<structured_chunk> * >::iterator tcc_pos = 
			succeeded_here.begin(); tcc_pos != succeeded_here.end();
			++tcc_pos)
		if (!(*tcc_pos)->is_redundant())
			success.insert(*tcc_pos);

	for (tc_pos = to_coalesce.begin();tc_pos != to_coalesce.end();++tc_pos)
		if (tc_pos->is_redundant())
			tc_pos = --to_coalesce.erase(tc_pos); 
		else
			if (tc_pos->was_recently_combined())
				tc_pos->clear_as_combined();

	int distinct_hierarchies_after = to_coalesce.size();

	return(distinct_hierarchies_before - distinct_hierarchies_after);
}

// This generates phantoms of a particular type (according to the spec)
int generate_phantoms(chunk_id limiter, phantom_generator & generator, 
		list<tree<structured_chunk> > & to_augment, 
		set<tree<structured_chunk> * > & to_ignore, 
		tree<chunk_id> & relation, int & unique_id_count) {

	structured_tree_op combiner;

	int augmented = 0;

	cout << "entered gp" << endl;
	cout << "Generator's id is " << generator.get_phantom_chunk_id() << endl;
	cout << "limiter is " << limiter << endl;
	if (generator.get_phantom_chunk_id() != limiter) return(0);
	cout << "passed hurdle" << endl;

	for (list<tree<structured_chunk> >::iterator pos = to_augment.begin();
			pos != to_augment.end(); ++pos) {

		if (to_ignore.find(&*pos) != to_ignore.end())
			continue;

		int subtree_direction = relation.get_subtree_direction(pos->
				get_value().get_type(), generator.
				get_phantom_chunk_id(), true);

		cout << "Handling " << pos->get_value().get_string("PK_filename") << endl;

		if (subtree_direction != -1) {

	/*		if (pos->get_value().get_type() != limiter)
				continue;*/

			tree<structured_chunk> phantom = generator.
				generate_phantom(to_augment, pos,
						unique_id_count); 
			// Consistency check goes here when we have one for
			// all.

			// phantom is subordinate
			if (subtree_direction == 0) {
				if (combiner.join(relation, phantom, *pos)) {
					augmented++;
					unique_id_count++;
				}
			} else 
				if (combiner.join(relation, *pos, phantom)) {
					augmented++;
					unique_id_count++;
					*pos = phantom;
				}
		}
	}

	return(augmented);
}

// Generate phantoms for all the children of this node. Used after we've 
// coalesced all we could from those nodes.
// TODO: Only deal with the relation that's more leafwards than the limiter
// so that we don't go joining stuff to ENDDIR_HEADERs before the ENDDIR_HEADER
// coalesce has a chance of being called.
int generate_all_lower_phantoms(tree<reconstructor_info> & start_here,
		list<tree<structured_chunk> > & to_augment,
		set<tree<structured_chunk> * > & to_ignore, tree<chunk_id> &
		relation, int & uid_count) {

	// May count multiple times, fix later.
	int so_far = 0;

	const reconstructor_info information = start_here.get_value();

	if (start_here.get_value().can_generate_phantom)
		so_far += generate_phantoms(information.this_chunk_id, 
				*(information.generator), to_augment,
				to_ignore, relation, uid_count);

	// Recurse!
	for (list<tree<reconstructor_info> >::iterator pos = start_here.
			subordinates.begin(); pos != start_here.subordinates.
			end(); ++pos)
		so_far += generate_all_lower_phantoms(*pos, to_augment,
				to_ignore, relation, uid_count);

	return(so_far);
}

void rebuild_hierarchy(ripper & our_ripper, list<tree<structured_chunk> > &
		chunks_found, bool print_after_each_stage, int & uid_count) {
	// Here we rebuild a hierarchy from a disorganized grouping of
	// chunks. What we do is that we get the coalesce ordering from the
	// ripper class, break it down into a breadth first list, and apply
	// coalescing and phantom generation from the end towards the beginning.
	// This means that when we get to a chunk at a certain level of the
	// hierarchy, we've already done what we could have with all the
	// chunks that could become potential children; so if we have to make
	// a greedy strategy, that makes most sense.
	
	// At each level, we coalesce (bring together chunks) and generate
	// phantoms (for those we couldn't bring together, where that is
	// appropriate).
	
	// This function is very slow, for multiple reasons. First is that we
	// have no way of seeing whether a coalesced chunk ("hierarchylet") is
	// completely done or can be joined with something else downstream,
	// which means that the hierarchylets linger on for longer than they
	// should. Second, we also have no way of knowing whether the last
	// round's coalescing opened up the possibility for generating more
	// phantoms, so we have to run phantoms on the child chunks of a given
	// position over and over again. Third, we can't know if we coalesced
	// all there is without running the coalescer at each level *at least
	// twice*. With expensive initialization functions (like the equivalence
	// sorter "simple_utility" for normal chunks), this gets real slow
	// real quick (heh!).
	
	// Ideally we should be able to say 'these can't coalesce with any
	// below whatever's its most superordinate chunk because the tree below
	// is unbroken, so lay off'. Since coalescing is two-way, that means
	// they don't have to be included into the initialization process 
	// either. Oh well, if wishes were horses..
	
	// Set up the lists.
	list<tree<chunk_id> * > relation_limit = our_ripper.get_relation()->
		get_breadth_first_pointer_list();
	list<tree<reconstructor_info> * > unfurled_tree = our_ripper.
		get_coalescer_guide()->get_breadth_first_pointer_list();
	list<int> unfurled_tree_levels = our_ripper.get_coalescer_guide()->
		get_breadth_first_depths();

	// .. and their iterators
	list<tree<reconstructor_info> * >::reverse_iterator cur_hierarchylet;
	list<tree<chunk_id> *>::reverse_iterator hierarchy_relation_cutoff=
		relation_limit.rbegin();
	list<int>::reverse_iterator cur_level = unfurled_tree_levels.rbegin();

	// NAIVE STRATEGY: For each node in the coalescer (reconstructor_info)
	// tree, run coalesce until there are no more to coalesce. When there's
	// a level shift, run generate phantoms on all of the lower levels,
	// before the coalescing.
	// ADVANCED: If the node has the same coalescer as the previous and we
	// didn't generate any phantoms, skip since there's no reason to run 
	// coalesce again (is this true for normals since it's not reflexive?
	// don't know so let's hold that for now). Run generate phantoms only
	// on the lower levels connected to the current upper level (done),
	// and mark a subtree as having all its phantoms generated when we're
	// done (not implemented yet).
	
	// Set up the success sets which tell the phantom generator which
	// chunks to keep away from (since they coalesced successfully, we
	// wouldn't want it to prematurely stick a phantom on it, hindering
	// future coalescing).
	set<tree<structured_chunk> * > old_successes, successes;

	int old_level = -1, chunks_coalesced = 0;
	int round = 0;
	structured_tree_op printer;
	for (cur_hierarchylet = unfurled_tree.rbegin(); cur_hierarchylet !=
			unfurled_tree.rend(); ++cur_hierarchylet) {
		cout << "[" << our_ripper.get_identifier() << 
			"] We're at level " << *cur_level << endl;

		if (*cur_level != old_level) {
			old_successes = successes;
			old_level = *cur_level;
		}

		if (print_after_each_stage) 
			printer.print_hierarchies("Round " + itos(round) +
					":\t", "\t", our_ripper.
					get_suggested_printable(),
					chunks_found);

		cout << "Generating phantoms for all uncoalesced children" << 
			endl;

		for (list<tree<reconstructor_info> >::iterator immed_chld_pos =
				(*cur_hierarchylet)->subordinates.begin();
				immed_chld_pos != (*cur_hierarchylet)->
				subordinates.end(); ++immed_chld_pos)
			generate_all_lower_phantoms(*immed_chld_pos, 
					chunks_found, old_successes,
					**hierarchy_relation_cutoff,
					uid_count);

		if (print_after_each_stage)
			printer.print_hierarchies("Round " + itos(round) +
					".25:\t", "\t", our_ripper.
					get_suggested_printable(),
					chunks_found);

		// TODO: Only if the coalescer type changes and there were
		// no phantoms.
		chunks_coalesced = -1;

		reconstructor_info this_position = (*cur_hierarchylet)->
			get_value();
		successes.clear();

		if (this_position.can_coalesce)
			while (chunks_coalesced != 0) {
				cout << "------------------ Coalescing" << endl;
				chunks_coalesced = coalesce_generic(
						this_position.coalescer,
						chunks_found, successes);
				printer.print_hierarchies("Round " +
						itos(round) + ".375:\t", "\t", 
						our_ripper.
						get_suggested_printable(),
						chunks_found);
			}

		++round;
		++cur_level;
		++hierarchy_relation_cutoff;
	}
}

typedef struct {
	int index_into_chunk_listing;
	ripper * corresponding_ripper;
	int index_into_spec;
} ripper_lookup;

// Returns a tree of ints where -1 means the chunk didn't check out, 0 means
// we're unsure, and 1 means it does.
template<typename inIter> tree<int> tree_checks_out(inIter beginning, inIter 
		end, const tree<structured_chunk> & to_check, ripper & 
		header_verify, const map<transform_method, data_verifier *> &
		scrutinizers) { 

	// Viva la recursion!
	// TODO later: put a "consistency check" here to check that the
	// hierarchy is put together right, not just that each chunk is
	// correct.
	// TODO: Return a tree for the benefit of set_as_gathered. That still
	// just skirts the real problem, which is one of indirect pointers.
	
	// Still doesn't differentiate data and header, so if the header's OK
	// but the data is not, it'll all get marked as "not OK". The problem
	// is that we don't have any finer granularity than "one chunk".

	tree<int> this_level(0);

	if (!header_verify.is_chunk_sane(to_check.get_value().get_inst_code(),
				to_check.get_value(), end-beginning))
		this_level.set_value(-1);

	// Handle the children first
	for (list<tree<structured_chunk> >::const_iterator pos = to_check.
			subordinates.begin(); pos != to_check.subordinates.
			end(); ++pos)
		this_level.push_back(tree_checks_out(beginning, end, *pos,
					header_verify, scrutinizers));

	// If this chunk isn't any good, there's nothing more to do.
	if (this_level.get_value() == -1) return(this_level);

	// Otherwise check whether it's verified as good, the data's bad, or we
	// just don't know.

	// (Can be very slow)
	list<string> fields = to_check.get_value().get_field_names();

	data_certificate data_results;
	data_results.outcome = VO_NOT_APPLICABLE;
	bool has_data = false;

	for (list<string>::const_iterator pos = fields.begin(); pos !=
			fields.end(); ++pos) {
		
		if (!to_check.get_value().has_data(*pos)) continue;
		// If there is no data, continue (so we don't set no_data
		// to false.)
		bool this_has_data = to_check.get_value().get_data_length(*pos)
			!= 0;
				
		cout << "Passed one" << endl;
		cout << "Value type: " << to_check.get_value().
			get_type() << endl;
		transform_method curtm = to_check.get_value().get_data_type(
				*pos);

		if (curtm == TM_UNKNOWN) {
			cout << "That was unknown" << endl;
			has_data = this_has_data;
			continue;
		}
		if (scrutinizers.find(curtm) == scrutinizers.end()) {
			cout << "Did not have a data verifier for this type"
				<< endl;
			has_data = this_has_data;
			continue;
		}
		data_verifier * verifier = scrutinizers.find(curtm)->second;

		// If this triggers, something's wrong with scrutinizers.
		assert(verifier->handles_this_method(curtm));
		
		cout << "Passed two" << endl;

		// Will perhaps cause problems with padding if it's not
		// counted...
		data_results = verifier->verify_data(beginning, to_check.
				get_value().get_data_location(*pos), end,
				to_check.get_value().get_data_length(*pos), 1);

		// If the data is empty and the verifier doesn't explicitly
		// fail them, then don't set no_data to false if it's already
		// true.
		if (!(!this_has_data && data_results.outcome != VO_FAIL)) 
			has_data = true;

		switch(data_results.outcome) {
			case VO_INIT_ERROR: cout << "INIT_ERROR" << endl; break;
			case VO_FAIL: cout << "VO_FAIL" << endl; break;
			case VO_SUCCESS: cout << "VO_SUCCESS" << endl; break;
			case VO_PROCESSING_ERROR: cout << "VO_PROCESSING_ERROR" << endl; break;
			}
	}

	bool succeeded = false;

	if (data_results.outcome == VO_SUCCESS || !has_data) 
		succeeded = true;
	
	else
		if (data_results.outcome != VO_NOT_APPLICABLE) {
			this_level.set_value(-1);
			return(this_level);
		}

	if (succeeded) this_level.set_value(1); // Success!
	else this_level.set_value(0);		// Don't know.
}

// HACK
void mark_as_used(const tree<structured_chunk> & mark_source, 
		file_occupancy & to_exclude_from, const tree<int> & guide) {

	// If it's not a phantom, and all the data checks out, then
	// exclude it (mark as used).
	if (mark_source.get_value().get_location() != -1 && guide.get_value()
			== 1) {
		// XXX: Beware overflow for very large file sizes
		to_exclude_from.mark_as_used(mark_source.get_value().
				get_location(), mark_source.get_value().
				get_location() + mark_source.get_value().
				size(), mark_source.get_value().
				get_unique_id());
	}

	list<tree<int> >::const_iterator guide_pos = guide.subordinates.begin();

	for (list<tree<structured_chunk> >::const_iterator pos = mark_source.
			subordinates.begin(); pos != mark_source.subordinates.
			end(); ++pos) {
		 mark_as_used(*pos, to_exclude_from, *guide_pos);
		 ++guide_pos;
	}
}

void add_data_verifier(map<transform_method, data_verifier *> & scrutinizers,
		data_verifier * to_add) {
	scrutinizers[to_add->get_method_handled()] = to_add;
}

// This function implements the reasoning that if a already exists and we're
// evaluating a potential candidate b; then if a is of the same type as b,
// a is sane, and they have the same data, then we break the tie towards the
// larger. We don't actually need to check if the data is valid, because if it
// is invalid, both a and b are (since they have the same data), and thus we
// lose nothing by choosing the larger, and if either are valid, both are, and
// so we don't lose anything there either.
// Properly, this should be done in the restructure hierarchies phase so that
// if some chunk c depends on the size of (either a and b), and it actually
// wants the smaller one, we aren't stuck. But this is rare and we can mop up
// later. NOTE.
bool is_sane_and_equal_data(const structured_chunk & a, 
		const structured_chunk & b) {

	// TODO, sanity check
	if (a.get_type() != b.get_type()) return(false);
	
	// Since they're the same type, we know they have the same data fields;
	// or in any case, if they don't, then they don't match and we'll be
	// right to drop them anyway.
	// Doesn't handle case where there are many data fields with different
	// names for a and b (since only the *location* should matter). Later.
	
	// NOTE: This is theoretically inconsistent because data is just another
	// field. So if you have two DIR_HEADERs and call this, it would say
	// both were equal just because it only checks the data alone, which
	// obviously isn't what we'd want to happen. But we can't check all
	// the fields either because the signature differs for the kind of
	// chunks we want to exclude.
	// We kludge it here by saying that if there's no data, then this
	// returns false, but it's not a good thing! [PROBNOTE]

	list<string> fields = a.get_field_names(SC_FT_DATA);

	if (fields.empty()) return(false); // KLUDGE

	for (list<string>::const_iterator pos = fields.begin(); pos !=
			fields.end(); ++pos) {

		if (a.get_data_location(*pos) != b.get_data_location(*pos))
			return(false);
		if (a.get_data_length(*pos) != b.get_data_length(*pos))
			return(false);
	}

	return(true);
}

typedef struct {
	string path_name;
	bool successful;
} file_dump_result;

template<class genRipper> list<file_dump_result> dump_structured_files(
		list<tree<structured_chunk> > & hierarchies, string dirname, 
		string prefix, int & count, genRipper & format_info, 
		bool dry_run) {

	// For all trees in the list
	// 	If the dumper for the ripper we have says it can handle that
	// 	tree
	// 		Dump it to a file and increment starting_number.
	
	list<file_dump_result> dump_results;

	// Suffix is the identifier turned to lowercase (nobody likes SHOUTING.)
	string suffix = format_info.get_identifier();
	for (string::iterator pos = suffix.begin(); pos != suffix.end(); ++pos)
		*pos = tolower(*pos);

	for (list<tree<structured_chunk> >::iterator pos = hierarchies.begin();
			pos != hierarchies.end(); ++pos) {
		file_dump_result to_add;
		if (!dirname.empty())
			to_add.path_name = dirname + "/";
		else	to_add.path_name = "";

		to_add.path_name = to_add.path_name + prefix + itos(count++) + 
			"." + suffix;
		to_add.successful = false;

		if (format_info.can_dump_this(*pos)) {

			cout << "Dumping [" << format_info.
				get_long_identifier() << "] to " << 
				to_add.path_name << endl;

			if (dry_run) {
				// Everything is bright and happy in the dry
				// run.
				to_add.successful = true;
				continue;
			}

			ofstream out_file(to_add.path_name.c_str());
			if (!out_file) {
				cerr << "Could not open file " << to_add.
					path_name << " for writing." << endl;
				dump_results.push_back(to_add);
				continue;
			}

			ostream_iterator<char> output(out_file);
			ostream_iterator<char> after = format_info.dump_tree(
					*pos, output);

			// If we dumped nothing, consider it a failure.
			to_add.successful = ((int)out_file.tellp() != 0);

			out_file.close();

		} 

		dump_results.push_back(to_add);
	}

	return(dump_results);
}

// as with generate_unstructured_chunk, only coalescing runs of multiple data 
// chunks of the same type. TODO later: break up on more advanced criteria.
// Not exactly my greatest piece of code. (May interact with advance in non-
// obvious ways, especially with regards to considering unclaimed (-1) parts 
// part of its own makeup)

bool generate_data_only_chunk(structured_chunk & destination, 
		data_iterator beginning, data_iterator end, 
		const file_occupancy & data_map,
		const vector<transform_method> &  identified_sectors,
		int start_check_at, int & last_checked, int uid,
		int sector_size) {

	int num_sectors = identified_sectors.size();

	// If the starting sector is either occupied or doesn't have any
	// prediction assigned to it, return false as we can't do anything.

	if (identified_sectors[start_check_at] == TM_USED_ELSEWHERE ||
			identified_sectors[start_check_at] == TM_UNKNOWN)
		return(false);

	// Okay, the initial value is of interest. Now walk forwards until we
	// get to an unknown or something of another type.

	int current_pos = start_check_at;
	while ((identified_sectors[current_pos] == 
			identified_sectors[start_check_at] || 
			identified_sectors[current_pos] == TM_USED_ELSEWHERE)
			&& current_pos < num_sectors)
		current_pos++;

	// We hit an unsuitable sector, either by difference or by running out
	// of sectors. So now we have our range; make like a structured chunk
	// and leave!

	// TODO: have real types here. And have a real length variable.
	// What a hack.
	chunk_id unstructured_data_type = UNKNOWN_TYPE;
	switch(identified_sectors[start_check_at]) {
		default: cerr << "Warning: unknown unstruct_data_type\n"; break;
		case TM_GZIP_DEFLATE:
		case TM_RAW_DEFLATE: unstructured_data_type = DATA_ONLY_DEFLATE;
				     break;
		case TM_EXT_PRINTABLE: unstructured_data_type = DATA_ONLY_TEXT;
				       break;
		case TM_EXTP_PDF: unstructured_data_type = DATA_ONLY_PDF_TEXT;
				  break;
		case TM_EXTP_MAIL_HEADER: unstructured_data_type = 
					  DATA_ONLY_MAIL_HDR;
					  break;
		case TM_EXTP_MAIL_BODY: unstructured_data_type = 
					DATA_ONLY_MAIL_BODY;
					break;
	}
	structured_chunk toRet(uid, -1, start_check_at * sector_size, 
			unstructured_data_type);

	data_container<data_iterator> chunk_data_struct;
	chunk_data_struct.start = beginning + (start_check_at * sector_size);
	chunk_data_struct.container_end = end;
	chunk_data_struct.length = data_map.count_between(start_check_at *
			sector_size, current_pos * sector_size, uid);
	chunk_data_struct.data_type = identified_sectors[start_check_at];
	toRet.set_data("DONLY_data", chunk_data_struct);
	toRet.set_inst_code(-1);

	destination = toRet;

	last_checked = current_pos - 1;

	return(true);
}

// STATS
list<string> get_md5s(const list<file_dump_result> & dump_results) {

	list<string> digests;

	for (list<file_dump_result>::const_iterator pos = dump_results.begin();
			pos != dump_results.end(); ++pos) {
		string MD5_val = "---NOT-SUCCESSFUL--";
		// If extracting this particular file wasn't successful, we
		// can't figure out its MD5 either. But if it was, try!
		if (pos->successful) {

			ifstream in_file(pos->path_name.c_str());

			if (!in_file)
				MD5_val = "---NOT-ACCESSIBLE--";
			else	MD5_val = md5(in_file);

		}

		digests.push_back(MD5_val);
	}

	return(digests);
}

// When we get file_occupancy changed, this will be unnecessary; we just have
// to start at the location and then walk forwards along the occupied bytes.

list<int> get_tree_location(data_iterator beginning, data_iterator end,
		const tree<structured_chunk> & from_where,
		const file_occupancy & data_map) {

	// Naive strategy (will become really ugly for AVIs):
	// 	Assume headers are contiguous
	// 	Output, for every byte, an int giving the location.
	// 	Use advance for data.
	//
	// Horrible space complexity, but fiix laater!
	// (No fix now by only adding a new value if the iterator skips
	//  more than one byte ahead. Still horrible complexity on 
	//  maximally entangled files (every other byte belongs to each other),
	//  but it'll hold for now.)
	
	// Implicit merge sort? Nah, use separate function, it's more elegant
	// that way. (Also whether to sort depends on whether or not you want
	// the sectors sorted or in the way they correspond to the file. The
	// latter isn't supported here though because this traverses it in
	// hierarchy order.)
	list<int> our_share;

	// header
	// NOTE: If we altered some of the header values, this still counts
	// the entire length of the header, as we don't have a way to show that
	// an individual field was altered. It also doesn't handle chunks
	// with [fields][data][fields] (like PNG) quite properly; it doesn't
	// add the stuff afterwards.
	if (from_where.get_value().get_location() >= 0) {
		int startloc = from_where.get_value().get_location();
	//	cout << "STARTLOC: " << startloc << endl;
	//	cout << "Size: " << from_where.get_value().size(false) << endl;

		for (int headerbytes = startloc; headerbytes < startloc + 
				from_where.get_value().size(false) &&
				headerbytes < end-beginning; 
				++headerbytes)
			our_share.push_back(headerbytes);
	}

	// data
	list<string> data_fields = from_where.get_value().get_field_names(
			SC_FT_DATA);

	for (list<string>::const_iterator pos = data_fields.begin(); pos !=
			data_fields.end(); ++pos) {
		data_iterator start_of_data = from_where.get_value().
			get_data_location(*pos), current_pos, old_pos;
		current_pos = start_of_data;

		int data_len = from_where.get_value().get_data_length(*pos,
				false),
		    data_count = 0;

		if (data_len <= 0) continue;

	//	our_share.push_back(current_pos-beginning);

		// on obm: data_len = 101974016, data_count = 17519430 and
		// onwards..
		// I have little doubt this is "real"; that is, it interprets
		// the length as that long. But because of the way we count
		// sectors, this leads to an extreme grinding because we store
		// an int for every byte.

		//cout << "[DEBUG: data_len is " << data_len << "]" << endl;

		for (data_count = 0; data_count < data_len && current_pos != 
				end; data_count++) {
			// bug here with unknown data.
			our_share.push_back(current_pos-beginning);
			//cout << data_count << "\t" << data_len << endl;
			old_pos = current_pos;
			int advanced = 0;
	//		cout << "Before advance: current pos minus beginning is " << current_pos - beginning << " and our count is " << data_count << " of " << data_len << endl;
	//		cout << "Unique ID: " << from_where.get_value().get_unique_id() << endl;
			current_pos = data_map.advance(beginning, current_pos,
					end, advanced, from_where.get_value().
					get_unique_id());
	//		cout << "We advanced " << advanced << endl;
	//		cout << "Current pos minus beginning is " << current_pos-beginning << endl;
		}
	}

	for (list<tree<structured_chunk> >::const_iterator child =
			from_where.subordinates.begin(); child != from_where.
			subordinates.end(); ++child) {
		list<int> their_share = get_tree_location(beginning, end,
				*child, data_map);
		copy(their_share.begin(), their_share.end(), inserter(
					our_share, our_share.end()));
	}

	return(our_share);
}

list<int> get_sectors_used(data_iterator beginning, data_iterator end,
		const tree<structured_chunk> & from_where,
		const file_occupancy & data_map, int sector_size) {

	list<int> sectors, bytes = get_tree_location(beginning, end,
			from_where, data_map);

	for (list<int>::const_iterator pos = bytes.begin(); pos != bytes.end();
			++pos) {
//		cout << "VAMOS: " << *pos << endl;
		sectors.push_back((int)floor(*pos/(double)sector_size));
	}
	//cout << endl;

	sectors.sort();
	list<int>::iterator newend = unique(sectors.begin(), sectors.end());
	sectors.erase(newend, sectors.end());

	return(sectors);
}

list<int>::const_iterator print_sector_block(list<int>::const_iterator
		start_at, list<int>::const_iterator end) {

	// If there's only one entry left, print it.
	// Otherwise, take one sector and set adv_one to false
	// Then for as long as the next sector is one more than the last
	// (meaning we have a contiguous range), advance.
	// If we get to the end or a sector that is one more, print the last
	// contiguous sector and then the one we're at (unless we broke
	// because we got to the end). Then return the position so we can
	// continue.
	
	list<int>::const_iterator next = start_at;
	next++;

	cout << *start_at;
	if (next == end) return(end);

	int range_begin = *start_at, range_last = *start_at;
	while (*next - range_last == 1 && next != end) {
		range_last = *next;
		next++;
	}
	// Now start_at is the beginning of the range, range_last is the
	// end, and next is the one after that.
	if (range_last != range_begin) {
		cout << "-" << range_last;
	}

	if (next != end) cout <<", ";

	return(next);
}

void print_stats(data_iterator beginning, data_iterator end,
		const list<file_dump_result> & results, 
		const list<tree<structured_chunk> > & chunks,
		const file_occupancy & data_map, int sector_size,
		bool show_unsuccessful) {

	if (chunks.empty())
		return;

	cout << "Chunk ID\tDump filename\tMD5 digest\tSectors used" << endl;

	list<file_dump_result>::const_iterator fdr_pos = results.begin();
	list<tree<structured_chunk> >::const_iterator chunk_pos = chunks.
		begin();

	list<string> digests = get_md5s(results);
	list<string>::const_iterator md5sum_pos = digests.begin();

	while (chunk_pos != chunks.end()) {
		if (show_unsuccessful || *md5sum_pos != "---NOT-SUCCESSFUL--") {
		cout << chunk_pos->get_value().get_unique_id() << "\t";
		cout << get_filename(fdr_pos->path_name) << "\t";
		cout << *md5sum_pos << "\t" << flush;

		// Allow for some sort of hybrid printing here, e.g
		// 0, 5-9500, 9501, 9800-9900 instead of
		// 0, 5, 6, 7, ... 9500 etc
		list<int> sectors = get_sectors_used(beginning, end,
				*chunk_pos, data_map, sector_size);

		list<int>::const_iterator sectors_pos = sectors.begin();
		while (sectors_pos != sectors.end())
			sectors_pos = print_sector_block(sectors_pos, 
					sectors.end());

		cout << endl;
		}
	/*	copy(sectors.begin(), sectors.end(), ostream_iterator<int>(cout,
					", "));

		cout << endl;*/
		chunk_pos++;
		fdr_pos++;
		md5sum_pos++;
	}
}

data_certificate brute_single_sector(data_iterator begin, data_iterator pos,
		data_iterator end, const tree<data_verifier * > & verifiers, 
		int sector_size, int depth, double ancestral_score, 
		transform_method & which_succeeded) {

	// General idea, as seen in schunk: If analysis of this type
	// succeeds, branch off to all leaves with depth + 1, then take the 
	// maximum. Since the scores are hyperbolic, this ensures the
	// leafwise closest wins as long as it doesn't fail.
	//
	// TODO later: Something like alpha-beta. Already done, rudimentary,
	// by not bothering to evaluate further if we get a negative score
	// (VO_FAIL).
	// TODO bluesky: use advance instead.

	transform_method current_record_type = TM_UNKNOWN;
	data_certificate for_this;
	for_this.outcome = VO_SUCCESS;
	for_this.score = 1;
	if (verifiers.get_value() != NULL) {
		for_this = verifiers.get_value()->verify_data(begin,
				pos, end, sector_size, ancestral_score);
		current_record_type = verifiers.get_value()->get_method_handled();
	} 

	if (for_this.outcome != VO_SUCCESS) {
		for_this.score += copysign(depth, for_this.score);
		return(for_this);
	}

	double score_here = for_this.score;
	data_certificate current_record = for_this;
	bool subordinate_record = false;

	for (list<tree<data_verifier *> >::const_iterator child = verifiers.
			subordinates.begin(); child != verifiers.subordinates.
			end(); ++child)  {
		transform_method candidate_type;

		data_certificate from_this_branch = brute_single_sector(begin,
				pos, end, *child, sector_size, depth+1,
				score_here, candidate_type);

		if (from_this_branch.score > current_record.score &&
				from_this_branch.outcome == VO_SUCCESS) {
			current_record = from_this_branch;
			current_record_type = candidate_type;
			subordinate_record = true;
		}
	}

	// In case of leaves, add the depth
	if (!subordinate_record)
		current_record.score += copysign(depth, current_record.score);

	which_succeeded = current_record_type;

	return(current_record);
}

vector<transform_method> brute_all_sectors(data_iterator begin, 
		data_iterator pos, data_iterator end, 
		const tree<data_verifier *> & verifiers, 
		const file_occupancy & already_used, int sector_size) {

	transform_method which_succeeded;

	int sector_count = (pos-begin)/sector_size;
	int all_sector_count = (end-begin)/sector_size;

	int successes = 0;

	vector<transform_method> toRet(all_sector_count+1, TM_UNKNOWN);
	
	for (data_iterator curpos = pos; curpos < end; curpos += sector_size) {

		data_certificate attempt;

		// If it's already accounted for, don't go spelunking in
		// here.
		if (already_used.is_completely_occupied(begin, curpos, end, 
					sector_size))
			attempt.outcome = VO_FAIL;
		else
			attempt = brute_single_sector(begin, curpos, end, 
					verifiers, sector_size, 0, 1, 
					which_succeeded);

		if (attempt.outcome == VO_SUCCESS) {
			// cout << "Success by " << which_succeeded << " at sector " << sector_count << endl;
		//	assert ((curpos-begin)/sector_size == sector_count);
			toRet[sector_count] = which_succeeded;
			successes++;
		}

		if ((sector_count & 511) == 511) {
			cout << "Brute-forcing data: sector " << sector_count 
				<< "  delta_successes: " << successes 
				<< "    \r" << flush;
			successes = 0;
		}

		sector_count++;
	}
	cout << endl;

	return(toRet);
}

void dump_sectors(const list<int> & sector_references, data_iterator beginning, 
		data_iterator end, string fn, int sector_size) {
	ofstream output(fn.c_str());
	if (!output) {
		cout << "Could not dump sectors to " << fn << endl;
		return;
	}


	for (list<int>::const_iterator pos = sector_references.begin(); pos != 
			sector_references.end(); ++pos) {
		data_iterator datapos = beginning + (*pos * sector_size),
			minend = datapos + sector_size;

		if (end - datapos < sector_size) minend = end;

		copy(datapos, minend, ostream_iterator<char>(output));

		string separator = "\n-------------------------------\n";
		copy(separator.begin(), separator.end(), ostream_iterator<char>(output));
	}
}

int main(int argc, char * * argv) {

	// Control the verbosity.
	bool show_unsuccessful = false;
	bool show_false_positives = false;

	if (argc < 2) {
		cout << "Usage: " << argv[0] << " [disk image]" << endl;
		return(-1);
	}

	// First register all the rippers with rkarp
	// QND
	
	vector<ripper *> rippers;
	rippers.push_back(new zip_ripper);
	rippers.push_back(new informal_png_ripper);
	rippers.push_back(new informal_jpg_ripper);
	rippers.push_back(new informal_pdf_ripper);
	rippers.push_back(new informal_doc_ripper);
	// Slows things down a lot, so wait with it
	rippers.push_back(new bmp_ripper);

	unsigned long long counter;

	// TODO here - "hints"
	int clue_length = 4;
	// Set up the RK searcher
	ripper_lookup none;
	none.corresponding_ripper = NULL;
	none.index_into_spec = -1;
	RKSearch<int> explicit_finder(-1, true, clue_length);

	// Get clue/footprint strings from the rippers
	vector<string> footprints;
	vector<ripper_lookup> connected_ripper;
	ripper_lookup for_this_clue;

	int abscount = 0;

	for (int sec = 0; sec < rippers.size(); ++sec) {
		for_this_clue.corresponding_ripper = rippers[sec];
		for_this_clue.index_into_chunk_listing = sec;
		vector<string> footprints_here = rippers[sec]->
			get_search_strings('?');
	//	copy (footprints_here.begin(), footprints_here.end(), ostream_iterator<string>(cout, "\n"));

		footprints.insert(footprints.end(), 
				footprints_here.begin(), footprints_here.end());

		for (counter = 0; counter < footprints_here.size(); counter++) {
			for_this_clue.index_into_spec = counter;
			connected_ripper.push_back(for_this_clue);
		}
	}

	// Get offsets so that each clue for clue_length bytes from the
	// offset are unique with regard to each other.
	vector<int> offsets = determine_offsets(footprints, clue_length, '?');

	// Then add the clues to the searcher
	for (counter = 0; counter < offsets.size(); counter++) {
		if (offsets[counter] == -1) {
			cout << "Could not find a clue for footprint " <<
				counter << endl;
		} else {
			explicit_finder.add(string(footprints[counter], 
						offsets[counter], clue_length),
					counter);
			cout << "Registered clue for footprint " << counter
				<< endl;
		}
	}

	// Benchmarking
	/*
	int y = 0;
	for (int x = 0; x < 256; x++) {
		if (explicit_finder.add(rand_string(4), -(x+1)))
			y++;
	}

	cout << "Registered " << y << endl;*/

	// Then open our file, once the ordinary way (to get its md5), and
	// once through rope to use later.
	
	bool calculate_md5 = true;
	string infile_md5 = "xxx";
	if (calculate_md5) {
		ifstream infile(argv[1]);
		infile_md5 = md5(infile);
		infile.close();
	}

	file_char_prod * fcp = new file_char_prod(argv[1]);
	cout << "FCPLen " << fcp->len() << endl;
	SGI::crope input_file(fcp, fcp->len(), true);
	cout << "IFLen " << input_file.size() << endl;

	// Construct the required directories to put our inputs into
	string infile_name = get_filename(argv[1]);
	string file_id = infile_name + "_" + infile_md5;

	string output_dir = "extracted_files";
	/*string verified = "verified";
	string unverified = "unverified";
	string nc = "not_checked";*/

	string dirstub = output_dir + "/" + file_id;
	/*string verified_dirstub = dirstub + "/" + verified;
	string unverified_dirstub = dirstub + "/" + unverified;
	string ncheck_dirstub = dirstub + "/" + nc;*/

	mkdir(output_dir.c_str(), 0777);
	mkdir(dirstub.c_str(), 0777);
	/*mkdir(verified_dirstub.c_str(), 0777);
	mkdir(unverified_dirstub.c_str(), 0777);
	mkdir(ncheck_dirstub.c_str(), 0777);*/

	// Then go through the input file, looking for matches
	
	vector<list<tree<structured_chunk> > > chunks_found(rippers.size() + 1);
	int reserved_for_data_only = rippers.size();
	/*vector<list<data_container<data_iterator> > > naively_found(rippers.
			size());*/
	// No branches allowed yet. Now sorta-kinda. If it doesn't work, look
	// at tree.cc, it'll probably be your culprit.

	// Also, make the program not add any chunks that are completely inside
	// other chunks. We're going to need a "data covered" class for that.
	// Only add a chunk if it's sane. (Greedy approach, again! But most
	// of DFRWS07 is in the right order) Make a note that it does use a
	// greedy approach, so I know what to change later if it proves
	// insufficient.
	// And why does hah.zip not coalesce while it does in tng?

	counter = 0;

	// Set some cosmetic and speedup parameters
	// Ideal: set precision so that one significant digit increments each
	// time we show progress
	cout.precision(3);
	cout.sync_with_stdio(false);

	bool shown_progress = false;

	gi_val fsize = input_file.size();

	// For unique IDs, which are used to map the different chunks to
	// different areas of the file (facilitating the process of 
	// elimination).
	int uid_counter = 0;

	vector<double> eta_times, eta_real_times; 
	// for debugging ETA, possibly to find
	// a PID/exponential backoff that works better

	// For now, use a greedy principle of exclusion. Better yet would be
	// to exclude at the reconstruct_hierarchy level so that if we've
	// reconstructed all hierarchies up to p, and there are two uncoalesced
	// blocks leafwise closer than p, then remove the one that is 
	// encapsulated by something else (and then try again).

	// QND for now, allocating twice (except the ngram verifiers, which
	// aren't used for verifying data). Later, get a BFS from the
	// tree and dump them all into the map.
	// Oh, and now I know why the other text_verifier doesn't show up.
	// I'm not using it!
	tree<data_verifier *> scrutinizer_hierarchy(NULL);
	scrutinizer_hierarchy.subordinates.push_back(new deflate_verifier
			(false));
	scrutinizer_hierarchy.subordinates.push_back(new deflate_verifier
			(true));
	scrutinizer_hierarchy.subordinates.push_back(new 
			extended_printable_verifier);
	scrutinizer_hierarchy.subordinates.back().push_back(new
			ngram_verifier("ngram/stats.mail.dat",
				TM_EXTP_MAIL, TM_EXT_PRINTABLE));
	scrutinizer_hierarchy.subordinates.back().subordinates.push_back(
			new mailhdr_verifier);
	scrutinizer_hierarchy.subordinates.back().subordinates.push_back(
			new passthrough_verifier(TM_EXTP_MAIL, 
				TM_EXTP_MAIL_BODY));
	scrutinizer_hierarchy.subordinates.back().push_back(new
			ngram_verifier("ngram/stats.pdfs.dat", TM_EXTP_PDF,
				TM_EXT_PRINTABLE));

	// TODO: BLUESKY: Map referring to the tree. Not needed for now, since
	// when a comple ripper says data is of type TEXT we don't need to know
	// if it's MAIL or PDF (for instance).
	map<transform_method, data_verifier *> scrutinizers;
	add_data_verifier(scrutinizers, new deflate_verifier(false));
	add_data_verifier(scrutinizers, new deflate_verifier(true));
	add_data_verifier(scrutinizers, new extended_printable_verifier);
	//add_data_verifier(scrutinizers, new ngram_verifier("ngram/stats.mail.dat", TM_EXTP_MAIL, TM_EXT_PRINTABLE));
	//add_data_verifier(scrutinizers, new ngram_verifier("ngram/stats.pdfs.dat", TM_EXTP_PDF, TM_EXT_PRINTABLE));

	vector<data_ripper *> data_only_rippers;
	data_only_rippers.push_back(new mail_ripper);

	// Get time
	double start_time = get_time();
	double last_time = start_time;
	double last_rec_eta = 0, cur_rec_eta = 0;
	double last_show_eta = 0, cur_show_eta = 0;
	double time_at_eta;

	cout << "FERNA" << endl;

	double damping_factor = 0.5;
	//cin >> damping_factor;

	// TODO: Fix occupancy error wrt failzip. The problem manifests because
	// the failzip data area is encrypted, so the mark function can't check
	// whether it's correct or not, and therefore it errs on the side of
	// caution. What we need is a form of reasoning of this kind:
	// 	- If b is wholly encapsulated by a, and b's data is
	// 	  completely equal to a, and a's header checks out, then b
	// 	  should not be added.
	// I can see the problem, because there's no way to know, ex ante,
	// if a is a false positive or not (within the data). However, the
	// reasoning above should hold because, if a's header is okay, b is no 
	// better!

	file_occupancy data_map(fsize); // BEWARE! 600 MB of memory required
	for (SGI::crope::const_iterator pos = input_file.begin(); pos !=
			input_file.end(); ++pos) {
		if ((counter++ & 262143) == 262143) {
			// NOTE: Decoherence may happen. For now we take the
			// brute approach of correcting it.
			double fraction_done = counter/(double)
				fsize;
			last_show_eta = cur_show_eta;
			time_at_eta = get_time();
			cur_show_eta = last_show_eta * damping_factor + 
				remaining_time(start_time, time_at_eta, 
						fraction_done) * (1-damping_factor);
			double delta = get_time() - last_time;

			if (delta >= 0.2) {
				cout << " Progress: " << counter << " of "
				<< fsize << "    " << fraction_done * 100.0 
				<< " % done ";
				cout << (time_at_eta-start_time)/fraction_done << " ";
			//cout << eta(start_time, get_time(), fraction_done);
				cout << hhmmss((int)round(cur_show_eta));
				cout << " left     \r" << flush;
				shown_progress = true;

				last_rec_eta = cur_rec_eta;
				cur_rec_eta = cur_show_eta;
				eta_times.push_back(cur_rec_eta);
				eta_real_times.push_back(time_at_eta);
				last_time = get_time();
			}
		}

		int tentative = explicit_finder.found(*pos);

		if (tentative > -1) {
			// Start offset shows how far we need to rewind:
			// enough to get to the start of the header, then
			// an additional explicit_finder.get_length() - 1
			// because the RKSearch only tells us when it has
			// swallowed enough bytes to get to the end of its
			// pattern.
			int start_offset = offsets[tentative] + 
				explicit_finder.get_length() - 1;

			if (shown_progress) cout << endl;
			shown_progress = false;
			// If it matches *BEFORE* the first byte, then it must
			// be a false positive.
			if (counter < start_offset) continue;

			// If we're going to show false positives, we must
			// print "Found chunk type".. first, otherwise it
			// won't make any sense. On the other hand, even if
			// we don't want to show false positives, we should
			// show this, so if !show_false_positives, we'll print
			// it later.
			if (show_false_positives) {
				cout << "Found chunk type " << tentative 
					<< " at " << counter-start_offset <<
					" (offset was " << start_offset << ")"
					<< endl;
			}

			ripper * macro = connected_ripper[tentative].
				corresponding_ripper;
			int micro = connected_ripper[tentative].
				index_into_spec;
			data_iterator adjpos = pos - start_offset;

			//cout << "Before acquisition" << endl;

			// Beware: might give false negatives
			gi_val max_size = fsize * 2; // some leeway permitted
			if (max_size < 0) max_size = INT_MAX;
			//cout << "Maximum size is " << max_size << endl;

			int next_uid = uid_counter;

			structured_chunk candidate = macro->acquire_chunk(
					micro, input_file.begin(), adjpos,
					input_file.end(), max_size, 
					next_uid);

			//cout << "Doing sanity check" << endl;
			if (!macro->is_chunk_sane(micro, candidate, max_size)) {
				if (show_false_positives)
					cout << "But that was a false positive."
						<< endl;
				continue;
			}

		//	cout << "Before encapsulation test" << endl;

			bool encapsulated = data_map.is_completely_occupied(
					input_file.begin(), adjpos, input_file.
					end(), candidate.size());

			if (encapsulated) {
				if (show_false_positives)
					cout << "But that is encapsulated." 
						<< endl;
				continue;
			}

			int tree_number = connected_ripper[tentative].
				index_into_chunk_listing;

			// Commented out while we work on the zip ripper
			// Seems it misjudges size which causes the
			// searcher to miss chunks.
			
			if (!chunks_found[tree_number].empty()) {
				if (is_sane_and_equal_data(candidate, 
							chunks_found
							[tree_number].back().
							get_value())) {
					if (show_false_positives)
						cout << "But that is probably "
							<< "encapsulated." << 
							endl;
					continue;
				}
			}

			// We know that the uid at next_uid will be used, so
			// increment uid counter so it will be truly unique.
			uid_counter++;

			if (!show_false_positives)
				cout << "Found chunk type " << tentative <<
					" at " << counter-start_offset <<
					" (offset was " << start_offset <<
					")" << endl;

			//cout << "Before NE: type is " << candidate.get_type() << endl;
			int ne_offset = macro->get_naive_extraction_offset(
					candidate.get_type(), input_file.
					begin(), adjpos, input_file.end(), 
					data_map, next_uid);

			if (ne_offset != -1) {
				cout << "Verified OK at offset " << ne_offset 
					<< endl;

				candidate = macro->generate_unstructured_chunk(
						input_file.begin(), adjpos, 
						input_file.end(), ne_offset, 
						max_size, next_uid);
			} 

			tree<structured_chunk> to_add(candidate);

			// Poor man's demultiplexing
			chunks_found[connected_ripper[tentative].
				index_into_chunk_listing].push_back(to_add);

			// And mark as used if it checks out
			if (ne_offset == -1)
				mark_as_used(to_add, data_map, tree_checks_out(
							input_file.begin(),
							input_file.end(),
							to_add,	*macro,
							scrutinizers));
			else
				// If we set an unstructured chunk, we *know*
				// the data must be okay, so skip the paperwork
				data_map.mark_as_used(adjpos - input_file.
						begin(), (adjpos + ne_offset) -
						input_file.begin(),
						next_uid);
		}
	}

	// ETA regularization
	/*
	double time_now = get_time();

	for (int counter = eta_times.size() - 1; counter >= 0; counter--)
		eta_times[counter] -= (time_now - eta_real_times[counter]);

	copy(eta_times.begin(), eta_times.end(), 
			ostream_iterator<double>(cerr, "\n"));*/

	for (counter = 0; counter < rippers.size(); ++counter) {
		int sec = 0;
		cout << "[" << rippers[counter]->get_identifier() << "]\tFound " 
			<< chunks_found[counter].size() << " headers in all." 
			<< endl;

		for (list<tree<structured_chunk> >::iterator pos = 
				chunks_found[counter].begin(); pos != 
				chunks_found[counter].end(); ++pos) {
			cout << sec++ << "\t" << pos->get_value().
			get_string("PK_filename") << endl;
		}

		// The above takes 6 seconds with output suppressed on 
		// pii250out.
		// The stuff below, for ZIP alone, takes 24 seconds.

		// TODO: Demultiplexing for speed (and adjointness)
		// Kinda done. HACK.

		rebuild_hierarchy(*rippers[counter], 
				chunks_found[counter], true, uid_counter);
	}

	// TODO: Try naively until there's no more to be gathered; should let
	// us disentangle interleaving of the type [FILE 1][FILE 2][FILE 1]
	// by first getting [FILE 2] then [FILE 1]
	// For all rippers
	// 	For all chunks
	// 		If this is a chunk that can be naively tested
	// 			Test it
	// 			If the test was okay
	// 			Mark off the range
	// 			Travel down, removing chunks within that
	// 			range
	// (Too tired to do this now)
	// TODO: Verify rebuilt hierarchies here, to add them to the principle
	// of exclusion blocker.

	cout << endl << endl;

	vector<int> counts(chunks_found.size(), 0);
	int sector_size = 512;

	// Check data here
	
	// - First brute force all remaining sectors
	vector<transform_method> data_sectors_detected = brute_all_sectors(
			input_file.begin(), input_file.begin(), input_file.
			end(), scrutinizer_hierarchy, data_map, sector_size);

	// - Turn the information into structured chunks
	int last;
	for (int sector = 0; sector < data_sectors_detected.size(); sector++) {
		structured_chunk candidate(-1);
		// If the current sector was classified, then put the 
		// resultant structured chunk into the list reserved for
		// data-only chunks, set the place to read next time as the
		// end of the data, and increment the uid counter.
		if (generate_data_only_chunk(candidate, input_file.begin(),
					input_file.end(), data_map,
					data_sectors_detected, sector, last,
					uid_counter, sector_size)) {
			// Actually a tree<structured_chunk> through copy
			// constructor
			chunks_found[reserved_for_data_only].push_back
				(candidate);
			uid_counter++;
			sector = last;
		}
	}

	// - Get the data rippers to coalesce the chunks
	for (counter = 0; counter < data_only_rippers.size(); counter++) {
		list<tree<structured_chunk> >::iterator docpos;
		for (docpos = chunks_found[reserved_for_data_only].begin();
				docpos != chunks_found[reserved_for_data_only].
				end(); ++docpos) {
			data_only_rippers[counter]->coalesce(chunks_found[
					reserved_for_data_only].begin(),
					docpos, chunks_found[
					reserved_for_data_only].end());
		}
		for (docpos = chunks_found[reserved_for_data_only].begin();
				docpos != chunks_found[reserved_for_data_only].
				end(); ++docpos) {
			docpos->clear_as_combined();
			if (docpos->is_redundant())
				docpos = --chunks_found[reserved_for_data_only].
					erase(docpos);
		}
	}


	// Finally, print stats and dump the stuff.
	structured_tree_op printer;
	for (counter = 0; counter < rippers.size(); counter++) {
		printer.print_hierarchies("Ripper " + itos(counter) + ":\t",
				"\t", rippers[counter]->get_suggested_printable
				(), chunks_found[counter]);

		list<file_dump_result> dumped_by_this_ripper = 
			dump_structured_files(chunks_found[counter], 
					dirstub, "out", 
					counts[counter], *rippers[counter], 
					false);

		// Move this particular thing to the bottom because we may
		// have data-only chunks..
		print_stats(input_file.begin(), input_file.end(), 
				dumped_by_this_ripper, chunks_found[counter],
				data_map, sector_size, show_unsuccessful);

	}

	// NOTE: not properly extednded to the case of multiple data-only
	// rippers.
	printer.print_hierarchies("Data-only: \t", "\t", "N/A", chunks_found[
			reserved_for_data_only]);
	
	vector<int> data_ripper_counts(data_only_rippers.size(), 0);

	for (counter = 0; counter < data_only_rippers.size(); ++counter) {
		list<file_dump_result> dumped_by_this_dripper =
			dump_structured_files(chunks_found[
					reserved_for_data_only], dirstub,
					"out", data_ripper_counts[counter], 
					*data_only_rippers[counter], false);

		print_stats(input_file.begin(), input_file.end(),
				dumped_by_this_dripper, chunks_found[
				reserved_for_data_only], data_map, sector_size,
				show_unsuccessful);
	}
	
	//vector<data_ripper *> data_only_rippers;

	// Sector kludge; find the beginning of orphan data.
	// When we find something, stick that into the list and try to
	// expand it from any other sector, and so on.. Default downwards.
	
	counter = 0;
	int delta_count = 0;

	// Remove later
	deallocate_vector(rippers);
	deallocate_tree(scrutinizer_hierarchy);

	// Feedback cycle
	ofstream clean("cleaned");
	ostream_iterator<char> clout(clean);
	data_iterator inpos = input_file.begin();
	counter = 0;
	for (data_iterator inpos = input_file.begin(); inpos != input_file.end(); ++inpos) {
		if (data_map.is_occupied_by(counter) != -1)
			*clout++ = 0;
		else	*clout++ = *inpos;
	}

	cout << "File occupancy says we've definitely recovered " << 
		data_map.occupied_bytes() << " bytes. " << endl;

}
