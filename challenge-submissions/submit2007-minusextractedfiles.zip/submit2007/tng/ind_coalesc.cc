#ifndef __IND_COALESC
#define __IND_COALESC

#include "tree.cc"
#include "chunk.cc"
#include "equivalence.cc"
#include "schunk_op.cc"
#include "consistency.h"
#include "slptr.h"
#include "cmeth.h"

#include <list>
#include <math.h>

using namespace std;

// STRAT_FAILURE means this strategy is a failure and all successive will be 
// too, STRAT_UNCERTAIN means we didn't find anything with this strategy but
// that others might succeed, and STRAT_SUCCESS means we succeeded, so there's
// no reason to keep trying. STRAT_NO_NEEDLE means there's no needle and
// thus we can't do anything.

typedef enum strategy_response {STRAT_FAILURE, STRAT_UNCERTAIN, STRAT_SUCCESS,
	STRAT_NO_NEEDLE};

class individual_coalescer {

	protected:
		bool has_needle;
		structured_list_ptr cur_needle;

	public:
		virtual void start_combining(list<tree<structured_chunk> > & 
				to_coalesce, structured_list_ptr candidate) = 0;

		structured_list_ptr get_needle() { return(cur_needle); }

		virtual strategy_response try_next_strategy() = 0;
//				list<structured_list_ptr> & haystack) = 0;

		virtual individual_coalescer * make_new() const = 0;

	//	virtual void debug() = 0;

		virtual ~individual_coalescer() {}

};

// Coalescer based on hypothesis generation, be it default or special. 
// Hypothesis generation involves joining a candidate to a known tree, then
// checking if the result is consistent.

// XXX: Document "strategy" err, strategy; i.e, why we're using "strategy" and
// make_new in the first place.

class hypothesis_coalescer : public individual_coalescer {

	private:
		tree<chunk_id> * relation;
		map<chunk_id, coalesce_method> * special_cases;
		// TODO: Make const
		hypothesis_generator * normal_check;
		hypothesis_generator * special_check;
		equivalence * symmetric_mapping;
		equivalence * asymmetric_mapping;
		vector<const specification *> specs;

		list<tree<structured_chunk> > * haystack;

		int strategy;
		coalesce_method prevailing_needle;
		bool has_cleaned_up;

	public:
		hypothesis_coalescer(tree<chunk_id> & relation_in, 
				map<chunk_id, coalesce_method> & 
				special_cases_in, hypothesis_generator & normal,
				hypothesis_generator & special, equivalence &
				sym_mapping, equivalence & asym_mapping,
				vector<const specification *> specs_in);

		individual_coalescer * make_new() const;

		// possible TODO: preload? Has to be done, yee-eees.

		void start_combining(list<tree<structured_chunk> > & 
				to_coalesce, structured_list_ptr needle);

		strategy_response try_next_strategy();

		~hypothesis_coalescer();

};

hypothesis_coalescer::hypothesis_coalescer(tree<chunk_id> & relation_in,
		map<chunk_id, coalesce_method> & special_cases_in,
		hypothesis_generator & normal, hypothesis_generator & special,
		equivalence & sym_mapping, equivalence & asym_mapping,
		vector<const specification *> specs_in) {

	relation = &relation_in;
	special_cases = &special_cases_in;
	normal_check = &normal;
	special_check = &special;
	symmetric_mapping = &sym_mapping;
	asymmetric_mapping = &asym_mapping;
	specs = specs_in;
	has_needle = false;
	strategy = 0;
	has_cleaned_up = false;

}

individual_coalescer * hypothesis_coalescer::make_new() const {
	return(new hypothesis_coalescer(*relation, *special_cases, 
				*normal_check, *special_check, 
				*symmetric_mapping, *asymmetric_mapping, 
				specs)); 
}

void hypothesis_coalescer::start_combining(list<tree<structured_chunk> > &
		to_coalesce, structured_list_ptr needle) {
	haystack = &to_coalesce;
	cur_needle = needle;
	has_needle = true;
	strategy = 0;

	structured_tree_op combiner;

	prevailing_needle = combiner.prevailing_method_for_hierarchy(
			*special_cases, *cur_needle);

	// Add to the winnowing class so that it'll show up in others'
	// haystacks.
	if (prevailing_needle != CM_SPECIAL)
		normal_check->include(cur_needle);
	if (prevailing_needle != CM_ORDINARY)
		special_check->include(cur_needle);
}

strategy_response hypothesis_coalescer::try_next_strategy() {

	// This looks through the haystack for chunk trees that may fit the 
	// tree given by the iterator needle. For all haystack/needle 
	// combinations, it checks if the result is consistent, and if it is,
	// if it's a better match than what it's got so far.
	// If it finds anything, it incorporates the smaller tree into the
	// larger (so it always breaks one way) and sets the other as
	// redundant.
	
	if (!has_needle) {
		cout << "Abort, abort" << endl;
		return(STRAT_NO_NEEDLE);
	}

	// The two strategies are as follows:
	// 	Strategy 0: CM_ORDINARY and CM_BOTH
	// 	Strategy 1: CM_SPECIAL and CM_BOTH

	structured_tree_op combiner;

	list<structured_list_ptr> pared;

	int old_strategy = strategy;
	cout << "Very initial" << "\t" << cur_needle->get_value().get_string("PK_filename") << "\t" << cur_needle->get_value().get_type() << endl;
	cout << "Strategy is " << strategy << endl;
	if (strategy == 2) return(STRAT_FAILURE); // We're done
	strategy++;

	// Cuts time down A LOT.
	// General idea is that PK_ENDDIR_HEADER is not a hypothesis coalescer.
	if (cur_needle->get_value().get_type() == PK_ENDDIR_HEADER) 
		return(STRAT_FAILURE);

	// Move outside of the loop?
	//coalesce_method needle_coal = combiner.prevailing_method_for_hierarchy
	//	(*special_cases, *cur_needle);

	switch(old_strategy) {
		case 0:
			if (prevailing_needle == CM_SPECIAL)
				return(STRAT_UNCERTAIN); // not yet.
			
			pared = normal_check->get_potential_candidates
				(*haystack, cur_needle);
			break;
		case 1:
			if (prevailing_needle == CM_ORDINARY) 
				return(STRAT_UNCERTAIN); // not yet either.

			pared = special_check->get_potential_candidates
				(*haystack, cur_needle);
			break;
		default:
			return(STRAT_FAILURE);
	}

	cout << "Keep on keeping on" << endl;
	// Slow as F.
	//cout << "Pared size is " << pared.size() << endl;
	//cout << "Haystack size is " << haystack->size() << endl;

	double record_consistency = -1, current_consistency;
	bool has_record = false;

	// NOTE: You must check [whether hypothesis_coalescer is the right
	// coalescer] outside of the class, because there's no error checking.
	// Possbly TODO make such error checking.
	
	list<tree<structured_chunk> >::iterator record_superordinate, 
		record_subordinate, candidate;

	assert(!cur_needle->is_redundant());

	structured_chunk dummy(-1);
	tree<structured_chunk> record_combination(dummy), combination(dummy);

	bool fit_any = false;

	// To get the error to show itself.
	for (list<structured_list_ptr>::const_iterator pos = pared.begin(); 
			pos != pared.end(); ++pos) {

		candidate = *pos;

		// If we're staring at the needle, or the haystack entry has
		// already been used, don't do anything.
		if (candidate == cur_needle) continue;
		if (candidate->is_redundant() || candidate->
				was_recently_combined()) continue;

		list<tree<structured_chunk> >::iterator superordinate,
			subordinate;

		// Now check if pos fits within the hierarchy of the needle or
		// vice versa.

		// NOTE: This call is quick.
		int subordinate_direction = relation->get_subtree_direction(
				cur_needle->get_value().get_type(), candidate->
				get_value().get_type(), true);

		if (subordinate_direction == -1) continue; // It didn't.
		else
			fit_any = true;

		if (subordinate_direction == 0) {
			superordinate = cur_needle;
			subordinate = candidate;
		} else {
			superordinate = candidate;
			subordinate = cur_needle;
		}

		/*cout << "Subordinate direction " << subordinate_direction << 
			endl;
		cout << "Originator ID" << cur_needle->get_value().get_type()
			<< "\tpos ID" << candidate->get_value().get_type()
			<< endl;*/

		// Combine the two candidates (needle and candidate) and see
		// if the result passes muster. First of all, it has to be
		// consistent (i.e consistency measure doesn't return NaN),
		// and second, it has to be better than what we have so far.

		// If it can't be joined, obviously it can't be consistent
		// either.
		combination = *superordinate;
		// Note: This call is SLOW.
		if (!combiner.join(*relation, *subordinate, combination))
			continue;

		// Synchronize size fields. May only be needed if the prevailing
		// method is not CM_ORDINARY, or may be needed.. who knows?
		// Assume conservative so far.

		if (prevailing_needle != CM_ORDINARY || combiner.
				prevailing_method_for_hierarchy(*special_cases,
					combination) != CM_ORDINARY)
			combiner.update_size_information(combination,
					*symmetric_mapping, *asymmetric_mapping,
					specs);

		current_consistency = combiner.get_tree_consistency(combination,
				*special_cases, false, normal_check, 
				special_check);

		cout << "Consistency measure for this particular combination is " << current_consistency << endl;

		if (isnan(current_consistency)) continue;

		if (current_consistency > record_consistency || !has_record) {
			has_record = true;

			 cout << "Subordinate direction " << 
				 subordinate_direction << endl;
			 cout << "Originator ID" << cur_needle->get_value().
				 get_type() << "\tpos ID" << candidate->
				 get_value().get_type() << endl;
			cout << "Found new record: " << current_consistency <<
				" vs " << record_consistency << endl;

			record_combination = combination;
			record_superordinate = superordinate;
			record_subordinate = subordinate;
			record_consistency = current_consistency;
		}
	}

	// If we found anything at all..
	if (has_record) {
		cout << "Found something" << endl;
		// Needed to prevent false positives; since the iterator
		// in main proceeds in a linear fashion, it's not enough to
		// use the destructor.
		if (old_strategy == 0) {
			normal_check->exclude(record_subordinate, 
					record_superordinate);
			has_cleaned_up = true;
		}

		*record_superordinate = record_combination;
		/*combiner.print_hierarchy("Subordinate: ", "\t", "PK_filename",
				*record_subordinate);*/
		combiner.print_hierarchy("Combined: ", "\t", "PK_filename", 
				record_combination);

		record_subordinate->set_redundancy(true);
		record_superordinate->set_as_combined();

		return(STRAT_SUCCESS);
	}

	cout << endl;

	// Not really correct...
	//if (!fit_any) return(STRAT_FAILURE);

	return(STRAT_UNCERTAIN);
}

hypothesis_coalescer::~hypothesis_coalescer() {
	if (has_needle && !has_cleaned_up) {
		if (prevailing_needle != CM_SPECIAL)
			normal_check->exclude(cur_needle, cur_needle);
		if (prevailing_needle != CM_ORDINARY)
			special_check->exclude(cur_needle, cur_needle);
	}
}

#endif
