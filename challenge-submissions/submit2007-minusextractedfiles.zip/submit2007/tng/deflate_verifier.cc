#include "data_verifier.cc"
#include "chunk.cc"
#include <vector>
#include <algorithm>
#include <zlib.h>
#include <assert.h>
#include <math.h>

using namespace std;

class deflate_verifier : public data_verifier {

	private:
		bool with_header;

	public:

		deflate_verifier(bool gzip_header);
		transform_method get_method_handled() const;
		data_certificate verify_data(data_iterator beginning, 
				data_iterator pos, data_iterator end,
				int max_length, double ancestral_score) const;
		bool sufficient_prerequisite(const transform_method 
				prerequisite) const { return(true); }
};

transform_method deflate_verifier::get_method_handled() const {
	if (with_header)
		return(TM_GZIP_DEFLATE);
	else	return(TM_RAW_DEFLATE);
}

deflate_verifier::deflate_verifier(bool gzip_header) {
	with_header = gzip_header;
}

// TODO: move to data_verifier.cc (degrading from header)
// TODO: Handle situation where there are more than one data field
/*data_certificate deflate_verifier::verify_chunk(data_iterator beginning, 
		data_iterator end, const structured_chunk & to_check) {
	list<string> fields = to_check.get_field_names();

	for (list<string>::const_iterator pos = fields.begin(); 
			pos != fields.end(); ++pos) {

		if (!to_check.has_data(*pos)) continue;

		return(verify_data(beginning, to_check.get_data_location(*pos),
					end));
	}

	data_certificate none;
	none.outcome = VO_FAIL;
	return(none);
}*/


// TODO: Implement PSUC (ran out of bytes to decompress)
data_certificate deflate_verifier::verify_data(data_iterator beginning, 
		data_iterator pos, data_iterator end,
		int max_length, double ancestral_score) const {
	data_certificate so_far;
	/*so_far.outcome = VO_NOT_APPLICABLE;
	so_far.break_location = -1;*/
	so_far.outcome = VO_INIT_ERROR;
	so_far.score = compound_score(ancestral_score, -1);
	// Beginning, pos, and end are all iterators
	if (beginning > pos || beginning >= end || pos >= end || 
			max_length < 0) 
		return(so_far);

	// Okay, set up the zstream.
	z_stream stream;
	// Set the required pointers to null
	stream.zalloc = Z_NULL;
	stream.zfree = Z_NULL;
	stream.opaque = Z_NULL;
	stream.avail_in = 0;
	stream.next_in = Z_NULL;
	// Initialize. Value < 0 means "don't expect zlib headers"
	if (with_header) {
		if (inflateInit(&stream) != Z_OK)
			return(so_far);
	} else {
		if (inflateInit2(&stream, -15) != Z_OK)
			return(so_far);
	}

	const int chunklen = 256; // Higher is faster but less detailed.

	unsigned char inchunk[chunklen], outchunk[chunklen]; // zlib interface
	string uncompressed_data;

	int state;

	do {
		int next_chunk_length = min(chunklen, min(end-pos, max_length));
		if (next_chunk_length < 0) next_chunk_length = 0;

		stream.avail_in = next_chunk_length;
		// If we used up all the bytes, we're done.
		if (stream.avail_in == 0) break;

		// Else copy the bytes to the input buffer..
		copy(pos, pos + stream.avail_in, inchunk);
		//cout << "Along the border " << (int)((unsigned char)inchunk[0])
		//	<< endl;
		// ... and set the "next chunk in" pointer in z_stream to point
		// at what we just copied.
		stream.next_in = inchunk;

		// Inflate until we run out of uncompressed data
		// (TODO: or exceed uncompressed_len; for zip bombs and such)
		do {
			stream.avail_out = chunklen;
			stream.next_out = outchunk;
			state = inflate(&stream, Z_NO_FLUSH);
			if (state == Z_STREAM_ERROR) {
				so_far.outcome = VO_PROCESSING_ERROR;
				return(so_far);
			}

			// If there's an error, tell the caller and get outta
			// here.
			// TODO: Check if stream.avail* tells us anything about
			// where the error happened.
			if (state == Z_NEED_DICT || state == Z_DATA_ERROR ||
					state == Z_MEM_ERROR) {
				inflateEnd(&stream);
				/*switch(state) {
					case Z_NEED_DICT: cout << "ZND" << endl; break;
					case Z_DATA_ERROR: cout << "DATAERR" << endl; break;
					case Z_MEM_ERROR: cout << "MEMERR" << endl; break;
				}*/
				so_far.outcome = VO_FAIL;
				so_far.break_location = pos - beginning;
				return(so_far);
			}

			// If it uncompressed correctly, write what we got to
			// the output string.
			int bytes_decompressed = chunklen - stream.avail_out;
			uncompressed_data.insert(uncompressed_data.end(),
					outchunk, &outchunk[bytes_decompressed]);

			// and keep doing this as long as we used all chunklen
			// bytes of the output.
		} while (stream.avail_out == 0);

		// AUGH!
		pos += next_chunk_length;
		// and keep doing this as long as we have bytes left to input.
	} while (state != Z_STREAM_END);

	// TODO: Let the user know if we exhausted the compressed data and it
	// still wants more (ie state != Z_STREAM_END or unc_len > real_len)

	// Clean up. 
	inflateEnd(&stream);

	so_far.outcome = VO_SUCCESS;
	so_far.score = compound_score(ancestral_score, 1);
	so_far.break_location = uncompressed_data.size();
	return(so_far);
}

// TODO: Generic function call for CRC32 etc.

/*
int main() {

	file_char_prod * fcp = new file_char_prod("dfverify.gz");
	cout << "FCPLen " << fcp->len() << endl;
	SGI::crope input_file(fcp, fcp->len(), true);
	cout << "IFLen " << input_file.size() << endl;

	SGI::crope::const_iterator beginning, pos, end;
	beginning = input_file.begin() + 10; // escape zlib header
	end = input_file.end() - 4; // escape CRC32
	pos = beginning;

	deflate_verifier x; data_certificate judgement;
	judgement = x.verify_data(beginning, pos, end);

	switch(judgement.outcome) {
		case VO_FAIL: cout << "VO_FAIL"; break;
		case VO_SUCCESS: cout << "VO_SUCCESS"; break;
		case VO_INIT_ERROR: cout << "VO_INIT_ERROR"; break;
		case VO_PROCESSING_ERROR: cout << "VO_PROCESSING_ERROR"; break;
	};
	cout << "\t" << judgement.break_location << endl;

}*/
