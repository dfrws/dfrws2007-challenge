#ifndef __TEXT_VERIFIER
#define __TEXT_VERIFIER

#include "data_verifier.cc"
#include <math.h>

// TODO: Printable Shift JIS / BIG / whatever (for spam)
// Must have at least one printable chars and some control chars are not
// permitted. [DONE]
// TODO: Some sort of meaningful scoring. For now, just -INFINITY on eror
// and +INFINITY on success.

using namespace std;

class text_verifier : public data_verifier {

	public:
		transform_method get_method_handled() const;

		bool sufficient_prerequisite(const transform_method
				prerequisite) const { return(true); }

		data_certificate verify_data(data_iterator beginning,
				data_iterator pos, data_iterator end,
				int max_length, double ancestral_score) const;

};

transform_method text_verifier::get_method_handled() const {
	return (TM_SEVEN_BITS);
}

data_certificate text_verifier::verify_data(data_iterator beginning,
		data_iterator pos, data_iterator end, int max_length,
		double ancestral_score) const {

	data_certificate so_far;
	so_far.outcome = VO_INIT_ERROR;
	so_far.score = compound_score(ancestral_score, -1);
	so_far.break_location = -1;
	if (beginning > pos || beginning >= end || pos >= end || max_length < 0)
		return(so_far);

	so_far.break_location = 0;
	so_far.outcome = VO_FAIL;

	// This used to pass char 0, but that caused too many false
	// positives (ie clutter).

	data_iterator minend = pos + max_length;
	if (minend > end) minend = end;

	for (data_iterator curpos = pos; curpos != minend; ++curpos)
		if (((unsigned char)(*curpos) > 127) || 
				((unsigned char)(*curpos) == 0)) {
			so_far.break_location = curpos - beginning;
			return(so_far);
		}

	so_far.outcome = VO_SUCCESS;
	so_far.break_location = -1;
	so_far.score = compound_score(ancestral_score, 1);

	return(so_far);
}

class extended_printable_verifier : public data_verifier {

	public:
		transform_method get_method_handled() const;
		bool sufficient_prerequisite(const transform_method
				prerequisite) const { return(true); }
		data_certificate verify_data(data_iterator beginning, 
				data_iterator pos, data_iterator end,
				int max_length, double ancestral_score) const;
};

transform_method extended_printable_verifier::get_method_handled() const {
	return(TM_EXT_PRINTABLE);
}

data_certificate extended_printable_verifier::verify_data(data_iterator 
		beginning, data_iterator pos, data_iterator end, int
		max_length, double ancestral_score) const {
	data_certificate so_far;
	so_far.outcome = VO_INIT_ERROR;
	so_far.break_location = -1;
	so_far.score = compound_score(ancestral_score, -1);
	
	if (beginning > pos || beginning >= end || pos >= end || max_length < 0)
		return(so_far);

	so_far.outcome = VO_FAIL;

	// All characters >= space are allowed (since GB and BIG5 make use
	// of all the extended characters). Some control characters are also
	// allowed: CR, LF, tab, and null (provided that there are non-null
	// characters present).
	// To cut down on the false positives, we also demand that there's
	// more than one letter in the chunk. (Warning, all of this destroys
	// locality, where locality is the concept that if [a..b] is invalid,
	// then [a..b+n] for n>0 must also be invalid. Chunk analysis that
	// is not local may cause false negatives in the data coagulation
	// phase.)
	
	bool failed = false, non_null = false, variety = false;
	unsigned char first = *pos;
	data_iterator curpos;

	data_iterator minend = pos + max_length;
	if (minend > end) minend = end;

	for (curpos = pos; curpos != minend && !failed; ++curpos) {
		unsigned char cp = *curpos;

		if (cp < ' ' && cp != 10 /*&& cp != 0*/ && cp != '\t' && 
				cp != 13) {
			so_far.break_location = curpos - beginning;
			return(so_far);
		}

		if (cp != 0) non_null = true;
		if (cp != first) variety = true;
	}

	so_far.break_location = curpos - beginning;

	if (!non_null || !variety) 
		return(so_far);

	so_far.outcome = VO_SUCCESS;
	so_far.score = compound_score(ancestral_score, 1);
	return(so_far);
}


#endif
