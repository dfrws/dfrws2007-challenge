Imports System.IO
Imports System.Security.Cryptography

Public Class JpegHeader
    Public intNumber As Integer
    Public intBlockNumber As Integer
    Public intMarkerPosition As Integer
    Public lngPosition As Long
    Public bteBlock(512) As Byte
    Public dblEntropy As Double
    Public dblPreEntropy As Double
    Public dblNxtEntropy As Double
End Class

Public Class JpegTail
    Public intNumber As Integer
    Public intBlockNumber As Integer
    Public lngPosition As Long
    Public bteBlock(512) As Byte
    Public dblEntropy As Double
    Public dblPreEntropy As Double
    Public dblNxtEntropy As Double
End Class

Public Class JpegBody
    Public intNumber As Integer
    Public intBlockNumber As Integer
    Public bteBlock(512) As Byte
    Public dblEntropy As Double
    Public dblPreEntropy As Double
    Public dblNxtEntropy As Double
End Class

Public Class JpegFile
    Public header As JpegHeader
    Public bodies As Queue(Of JpegBody)
    Public tail As JpegTail
    Public intHeaderCount As Integer
    Public lngCurrentPosition As Long
    Public lngFileLength As Long
    Public intNextBlock As Integer

    Public Sub New()
        header = New JpegHeader
        bodies = New Queue(Of JpegBody)
        tail = New JpegTail
    End Sub
    Public Function FindNextBlock(ByVal objFileStream As FileStream, ByRef sngEntropy() As Double, ByRef intBlockTaken() As Integer, _
ByVal dblF128Etp() As Double, ByVal dblF64Etp() As Double, ByVal dblF32Etp() As Double, ByVal dblL128Etp() As Double, ByVal dblL64Etp() As Double, ByVal dblL32Etp() As Double) As Boolean
        Dim bytes(512) As Byte
        Dim blnRet As Boolean
        Dim dblNextEntropy, dblEntropy, dblNearestEntropy As Double
        Dim intJpegTFound, intBlockNumber As Integer
        Dim objJpegBody As JpegBody
        Dim dblLast128Entropy, dblFirst128Entropy As Double
        Dim dblLast64Entropy, dblFirst64Entropy As Double
        Dim dblLast32Entropy, dblFirst32Entropy As Double
        Dim intBlockNum As Integer
        Try
            If bodies.Count = 0 Or moreHeader() Then ' look at the header block, and check the marker
                If bodies.Count = 0 Then
                    dblEntropy = header.dblEntropy
                    dblNextEntropy = header.dblNxtEntropy
                    intBlockNumber = header.intBlockNumber
                    dblLast128Entropy = CalCulateLastX(header.bteBlock, 384)
                    dblLast64Entropy = CalCulateLastX(header.bteBlock, 448)
                Else
                    objJpegBody = getLastBody()
                    dblEntropy = objJpegBody.dblEntropy
                    dblNextEntropy = objJpegBody.dblNxtEntropy
                    intBlockNumber = objJpegBody.intBlockNumber
                    dblLast128Entropy = CalCulateLastX(objJpegBody.bteBlock, 384)
                    dblLast64Entropy = CalCulateLastX(objJpegBody.bteBlock, 448)
                End If
                If Math.Abs(dblEntropy - dblNextEntropy) > 1.0 Or intBlockTaken(intBlockNumber + 1) <> 0 Then
                    If bodies.Count = 0 Then
                        dblNearestEntropy = getNearestEntropy(sngEntropy, intBlockTaken, dblEntropy, intBlockNum, dblF128Etp, dblF64Etp, dblF32Etp, dblL128Etp, dblL64Etp, dblL32Etp)
                    Else
                        dblNearestEntropy = getNearestEntropy(sngEntropy, intBlockTaken, dblEntropy, intBlockNum, dblF128Etp, dblF64Etp, dblF32Etp, dblL128Etp, dblL64Etp, dblL32Etp)
                    End If
                    If intBlockTaken(intBlockNumber + 1) <> 0 Then
                        lngCurrentPosition = intNextBlock * 512
                    Else
                        objFileStream.Seek(lngCurrentPosition + 512, SeekOrigin.Begin)
                        objFileStream.Read(bytes, 0, 512)
                        dblFirst128Entropy = CalCulateFirstX(bytes, 127)
                        dblFirst64Entropy = CalCulateFirstX(bytes, 63)
                        If Math.Abs(dblLast128Entropy - dblFirst128Entropy) < 1.0 Or Math.Abs(dblFirst64Entropy - dblLast64Entropy) < 1.0 Then
                            If bodies.Count = 0 Then
                                lngCurrentPosition = header.lngPosition + 512
                            Else
                                lngCurrentPosition = lngCurrentPosition + 512
                            End If
                        Else
                            lngCurrentPosition = intNextBlock * 512
                        End If
                    End If
                Else
                    If bodies.Count = 0 Then
                        lngCurrentPosition = header.lngPosition + 512
                    Else
                        lngCurrentPosition = (objJpegBody.intBlockNumber + 1) * 512
                    End If
                End If
                objFileStream.Seek(lngCurrentPosition, SeekOrigin.Begin)
                blnRet = True
            Else
                objJpegBody = getLastBody()
                If objJpegBody.intBlockNumber = 371097 Then
                    Debug.Print("Stop")
                End If
                intJpegTFound = CountJpegT(objJpegBody.bteBlock, byteJpegT)
                If intJpegTFound >= intHeaderCount Then
                    blnRet = False
                Else
                    If intJpegTFound = 1 Then
                        intHeaderCount -= 1
                    End If
                    intBlockNumber = lngCurrentPosition / 512
                    dblEntropy = sngEntropy(intBlockNumber)
                    dblNextEntropy = sngEntropy(intBlockNumber + 1)
                    objFileStream.Seek(lngCurrentPosition + 512, SeekOrigin.Begin)
                    objFileStream.Read(bytes, 0, 512)
                    If Math.Abs(dblEntropy - dblNextEntropy) > 1.0 Or intBlockTaken(intBlockNumber + 1) <> 0 Or Not IsJpegBody(dblNextEntropy) Then
                        dblNearestEntropy = getNearestEntropy(sngEntropy, intBlockTaken, dblEntropy, objJpegBody.intBlockNumber, dblF128Etp, dblF64Etp, dblF32Etp, dblL128Etp, dblL64Etp, dblL32Etp)
                        If intBlockTaken(intBlockNumber + 1) <> 0 Then 'We need do something here, for example, compare the two blocks last and first 128, 64 entropy
                            lngCurrentPosition = intNextBlock * 512
                        ElseIf Not IsJpegBody(dblNextEntropy) Then
                            lngCurrentPosition = intNextBlock * 512
                        Else
                            objFileStream.Seek(lngCurrentPosition + 512, SeekOrigin.Begin)
                            objFileStream.Read(bytes, 0, 512)
                            dblFirst128Entropy = CalCulateFirstX(bytes, 127)
                            dblFirst64Entropy = CalCulateFirstX(bytes, 63)
                            dblLast64Entropy = CalCulateLastX(objJpegBody.bteBlock, 448)
                            dblFirst32Entropy = CalCulateFirstX(bytes, 31)
                            dblLast32Entropy = CalCulateLastX(objJpegBody.bteBlock, 480)
                            dblLast128Entropy = CalCulateLastX(objJpegBody.bteBlock, 384)
                            If Math.Abs(dblLast128Entropy - dblFirst128Entropy) < 1.0 Or Math.Abs(dblFirst64Entropy - dblLast64Entropy) < 1.0 Or Math.Abs(dblFirst32Entropy - dblLast32Entropy) < 1.5 Then
                                lngCurrentPosition = (objJpegBody.intBlockNumber + 1) * 512
                            Else
                                lngCurrentPosition = intNextBlock * 512
                            End If
                        End If
                    Else
                        lngCurrentPosition = (objJpegBody.intBlockNumber + 1) * 512
                    End If
                    objFileStream.Seek(lngCurrentPosition, SeekOrigin.Begin)
                    blnRet = True
                End If
            End If
        Catch ex As Exception
            Debug.Print(ex.Message)
        End Try
        Return blnRet
    End Function

    Public Function moreHeader() As Boolean
        Dim intToNextMarker As Integer
        intToNextMarker = 512 + bodies.Count * 512
        If intToNextMarker <= header.intMarkerPosition Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Function getLastBody() As JpegBody
        Dim objJpegBody As JpegBody
        Dim intCB As Integer = 0
        For Each objJpegBody In bodies
            intCB += 1
            If intCB = bodies.Count Then 'get the last body block
                Return objJpegBody
            End If
        Next
        Return Nothing
    End Function

    Public Function getNearestEntropy(ByVal sngEntropy() As Double, ByVal intBlockTaken() As Integer, ByVal dblEntropy As Double, ByVal intBlockNum As Integer, _
ByVal dblF128Etp() As Double, ByVal dblF64Etp() As Double, ByVal dblF32Etp() As Double, ByVal dblL128Etp() As Double, ByVal dblL64Etp() As Double, ByVal dblL32Etp() As Double) As Double
        Dim dblNearestEpy As Double
        Dim dblSmallest As Double = 0.01
        Dim dblTemp As Double
        Dim intC, intN As Integer
        Dim dblLast128Entropy, dblFirst128Entropy As Double
        Dim dblLast64Entropy, dblFirst64Entropy As Double
        Dim dblLast32Entropy, dblFirst32Entropy As Double
        Dim dblFirstNear As Double = 1.0
        Dim intForVar As Integer = intBlockNum
        While intN = 0
            For intC = intForVar To sngEntropy.Length - 1
                dblNearestEpy = sngEntropy(intC)
                If intBlockTaken(intC) = 0 Then
                    If Math.Abs(dblEntropy - dblNearestEpy) < dblFirstNear Then
                        dblLast128Entropy = dblL128Etp(intBlockNum)
                        dblLast64Entropy = dblL64Etp(intBlockNum)
                        dblLast32Entropy = dblL32Etp(intBlockNum)
                        dblFirst32Entropy = dblF32Etp(intC)
                        dblFirst64Entropy = dblF64Etp(intC)
                        dblFirst128Entropy = dblF128Etp(intC)
                        dblTemp = Math.Abs(dblLast128Entropy - dblFirst128Entropy)
                        dblTemp += Math.Abs(dblLast64Entropy - dblFirst64Entropy)
                        dblTemp += Math.Abs(dblLast32Entropy - dblFirst32Entropy)
                        If dblTemp < dblSmallest Then
                            'dblSmallest = dblTemp
                            intN = intC
                            Exit For
                        End If
                    End If
                End If
            Next
            intForVar = 0
            dblSmallest += 0.01
            dblFirstNear += 0.1
        End While
        intNextBlock = intN
        Return sngEntropy(intN)
    End Function

    Public Function writeOut(ByVal sngEntropy() As Double, ByVal strDirectory As String) As Boolean
        Dim bytes(lngFileLength) As Byte
        Dim myFile As File
        Dim strDescription As String
        Dim intPreviousBlock As Integer
        Dim txtWriter As TextWriter = myFile.AppendText(strDirectory & "\" & header.intBlockNumber & ".txt")
        txtWriter.WriteLine(header.intBlockNumber & " " & (header.intBlockNumber * 512).ToString & " " & sngEntropy(header.intBlockNumber))
        strDescription = header.intBlockNumber
        intPreviousBlock = header.intBlockNumber
        Array.Copy(header.bteBlock, 0, bytes, 0, header.bteBlock.Length)
        Dim objBody As JpegBody
        Dim intC As Integer = 1

        Dim intLastBlockLength As Integer = lngFileLength - bodies.Count * 512
        For Each objBody In bodies
            If objBody.intBlockNumber - intPreviousBlock = 1 Then
            Else
                strDescription += "-" & intPreviousBlock.ToString & "," & objBody.intBlockNumber.ToString
            End If
            intPreviousBlock = objBody.intBlockNumber

            txtWriter.WriteLine(objBody.intBlockNumber & " " & (objBody.intBlockNumber * 512).ToString & " " & sngEntropy(objBody.intBlockNumber))
            If intC = bodies.Count Then
                Array.Copy(objBody.bteBlock, 0, bytes, intC * 512, intLastBlockLength)
            Else
                Array.Copy(objBody.bteBlock, 0, bytes, intC * 512, 512)
            End If
            intC += 1
        Next
        strDescription += "-" & intPreviousBlock
        txtWriter.WriteLine(strDescription)
        Dim Md5 As New MD5CryptoServiceProvider()
        'Compute the hash value from the source
        Dim ByteHash() As Byte = Md5.ComputeHash(bytes)
        txtWriter.WriteLine(Convert.ToBase64String(ByteHash))
        txtWriter.Close()
        Dim oFileStream As System.IO.FileStream
        oFileStream = New System.IO.FileStream(strDirectory & "\" & header.intBlockNumber & ".jpg", System.IO.FileMode.Create)
        oFileStream.Write(bytes, 0, lngFileLength)
        oFileStream.Close()
    End Function
End Class

'Dim dblNearestEpy As Double
'Dim dblSmallest As Double = 0.01
'Dim dblTemp As Double
'Dim intC, intN As Integer
'Dim dblLast128Entropy, dblFirst128Entropy As Double
'Dim dblLast64Entropy, dblFirst64Entropy As Double
'Dim dblLast32Entropy, dblFirst32Entropy As Double
'Dim dblFirstNear As Double = 1.0
'Dim intForVar As Integer = intBlockNum
'While intN = 0
'    For intC = intForVar To sngEntropy.Length - 1
'        dblNearestEpy = sngEntropy(intC)
'        If intBlockTaken(intC) = 0 Then
'            If Math.Abs(dblEntropy - dblNearestEpy) < dblFirstNear Then
'                dblLast128Entropy = dblL128Etp(intBlockNum)
'                dblLast64Entropy = dblL64Etp(intBlockNum)
'                dblLast32Entropy = dblL32Etp(intBlockNum)
'                dblFirst32Entropy = dblF32Etp(intC)
'                dblFirst64Entropy = dblF64Etp(intC)
'                dblFirst128Entropy = dblF128Etp(intC)
'                dblTemp = Math.Abs(dblLast128Entropy - dblFirst128Entropy)
'                dblTemp += Math.Abs(dblLast64Entropy - dblFirst64Entropy)
'                dblTemp += Math.Abs(dblLast32Entropy - dblFirst32Entropy)
'                If dblTemp < dblSmallest Then
'                    intN = intC
'                    Exit For
'                End If
'            End If
'        End If
'    Next
'    intForVar = 0
'    dblSmallest += 0.01
'    dblFirstNear += 0.1
'End While
'intNextBlock = intN
'Return sngEntropy(intN)
