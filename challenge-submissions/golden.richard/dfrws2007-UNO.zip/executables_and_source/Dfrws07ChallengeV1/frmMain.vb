Public Class frmMain
    Private intPgbMax As Integer = 0
    Dim intCount As Integer

    Private Sub btnFind_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFind.Click
        If txtFile.Text = "" Then
            MessageBox.Show("Please choose image file.")
            Exit Sub
        End If
        If txtFolder.Text = "" Then
            MessageBox.Show("Please set up output directory.")
            Exit Sub
        End If
        Dim WC As New MyWorker
        WC.mstrFile = txtFile.Text
        WC.mstrDirectory = txtFolder.Text
        pgb1.Value = 0
        bgw1.RunWorkerAsync(WC)
    End Sub
    Private Sub Bgw1_DoWork(ByVal sender As Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles bgw1.DoWork
        Dim worker As System.ComponentModel.BackgroundWorker
        worker = CType(sender, System.ComponentModel.BackgroundWorker)

        ' Get the Works object and call the main method.
        Dim WC As MyWorker = CType(e.Argument, MyWorker)
        WC.FindJpeg(worker, e)
    End Sub

    Private Sub bgw1_ProgressChanged(ByVal sender As Object, ByVal e As System.ComponentModel.ProgressChangedEventArgs) Handles bgw1.ProgressChanged
        Dim state As MyWorker.CurrentState = CType(e.UserState, MyWorker.CurrentState)
        Me.lblStatus.Text = state.strStatus
        Me.lblStatus.Text = Me.lblStatus.Text & ". Time elapsed " & state.span.Hours & ":" & state.span.Minutes & ":" & state.span.Seconds
        Try
            If state.intMax > 0 Then
                pgb1.Maximum = state.intMax
                If intPgbMax <> state.intMax Then
                    intPgbMax = state.intMax
                    pgb1.Value = 0
                End If
                If pgb1.Value >= pgb1.Maximum Then
                    pgb1.Value = 0
                End If
                If pgb1.Value + state.intIncrease >= pgb1.Maximum Then
                    pgb1.Value = pgb1.Maximum
                Else
                    pgb1.Value += state.intIncrease
                End If
            Else
            End If

        Catch ex As Exception
            pgb1.Value = 0
        End Try
    End Sub

    Private Sub bgw1_RunWorkerCompleted(ByVal sender As Object, ByVal e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles bgw1.RunWorkerCompleted
        If e.Error IsNot Nothing Then
            MsgBox("Error: " & e.Error.Message)
        ElseIf e.Cancelled Then
            MsgBox("CreateAll canceled.")
        Else
            'lblStatus.Text = "Done."
            pgb1.Value = pgb1.Maximum
        End If
    End Sub

    Private Sub btnFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFile.Click
        Dim fDialog As OpenFileDialog = New OpenFileDialog
        If fDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
            txtFile.Text = fDialog.FileName
        End If
    End Sub

    Private Sub btnSetFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSetFolder.Click
        Dim folder As New FolderBrowserDialog
        If folder.ShowDialog = Windows.Forms.DialogResult.OK Then
            txtFolder.Text = folder.SelectedPath
        End If
    End Sub
End Class
