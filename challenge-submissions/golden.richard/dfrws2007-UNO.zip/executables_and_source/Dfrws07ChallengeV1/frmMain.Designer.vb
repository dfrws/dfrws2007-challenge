<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblStatus = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.bgw1 = New System.ComponentModel.BackgroundWorker
        Me.pgb1 = New System.Windows.Forms.ProgressBar
        Me.btnFind = New System.Windows.Forms.Button
        Me.txtFile = New System.Windows.Forms.TextBox
        Me.btnFile = New System.Windows.Forms.Button
        Me.txtFolder = New System.Windows.Forms.TextBox
        Me.btnSetFolder = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'lblStatus
        '
        Me.lblStatus.AutoSize = True
        Me.lblStatus.Location = New System.Drawing.Point(73, 180)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(0, 13)
        Me.lblStatus.TabIndex = 50
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(27, 180)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 13)
        Me.Label1.TabIndex = 49
        Me.Label1.Text = "Status:"
        '
        'bgw1
        '
        Me.bgw1.WorkerReportsProgress = True
        Me.bgw1.WorkerSupportsCancellation = True
        '
        'pgb1
        '
        Me.pgb1.Location = New System.Drawing.Point(30, 146)
        Me.pgb1.Name = "pgb1"
        Me.pgb1.Size = New System.Drawing.Size(537, 12)
        Me.pgb1.TabIndex = 48
        '
        'btnFind
        '
        Me.btnFind.Location = New System.Drawing.Point(266, 97)
        Me.btnFind.Name = "btnFind"
        Me.btnFind.Size = New System.Drawing.Size(75, 23)
        Me.btnFind.TabIndex = 47
        Me.btnFind.Text = "Find Jpegs"
        Me.btnFind.UseVisualStyleBackColor = True
        '
        'txtFile
        '
        Me.txtFile.Enabled = False
        Me.txtFile.Location = New System.Drawing.Point(239, 15)
        Me.txtFile.Name = "txtFile"
        Me.txtFile.Size = New System.Drawing.Size(285, 20)
        Me.txtFile.TabIndex = 53
        Me.txtFile.Text = "C:\VCPrj\dfrws-2007-challenge\dfrws-2007-challenge.img"
        '
        'btnFile
        '
        Me.btnFile.Location = New System.Drawing.Point(134, 12)
        Me.btnFile.Name = "btnFile"
        Me.btnFile.Size = New System.Drawing.Size(86, 23)
        Me.btnFile.TabIndex = 52
        Me.btnFile.Text = "Get Image"
        Me.btnFile.UseVisualStyleBackColor = True
        '
        'txtFolder
        '
        Me.txtFolder.Enabled = False
        Me.txtFolder.Location = New System.Drawing.Point(239, 54)
        Me.txtFolder.Name = "txtFolder"
        Me.txtFolder.Size = New System.Drawing.Size(285, 20)
        Me.txtFolder.TabIndex = 55
        Me.txtFolder.Text = "C:\VCPrj\CarveBytes\BlockNum"
        '
        'btnSetFolder
        '
        Me.btnSetFolder.Location = New System.Drawing.Point(119, 51)
        Me.btnSetFolder.Name = "btnSetFolder"
        Me.btnSetFolder.Size = New System.Drawing.Size(114, 23)
        Me.btnSetFolder.TabIndex = 54
        Me.btnSetFolder.Text = "Set Output Directory"
        Me.btnSetFolder.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(597, 219)
        Me.Controls.Add(Me.txtFolder)
        Me.Controls.Add(Me.btnSetFolder)
        Me.Controls.Add(Me.txtFile)
        Me.Controls.Add(Me.btnFile)
        Me.Controls.Add(Me.lblStatus)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.pgb1)
        Me.Controls.Add(Me.btnFind)
        Me.Name = "frmMain"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblStatus As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents bgw1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents pgb1 As System.Windows.Forms.ProgressBar
    Friend WithEvents btnFind As System.Windows.Forms.Button
    Friend WithEvents txtFile As System.Windows.Forms.TextBox
    Friend WithEvents btnFile As System.Windows.Forms.Button
    Friend WithEvents txtFolder As System.Windows.Forms.TextBox
    Friend WithEvents btnSetFolder As System.Windows.Forms.Button

End Class
