Imports System.IO
Imports System.Math

Module CommonFunctions
    Public byteJpegH() As Byte = {255, 216, 255, 224, 0, 16}
    Public byteJpegT() As Byte = {255, 217}
    Public byteMpgH1() As Byte = {0, 0, 1, 186}
    Public byteMpgH2() As Byte = {0, 0, 1, 179}
    Public byteMpgT1() As Byte = {0, 0, 1, 185}
    Public byteMpgT2() As Byte = {0, 0, 1, 183}
    Public byteZipH() As Byte = {50, 75, 3, 4}
    Public byteDocH() As Byte = {208, 207, 17, 224, 161, 177}
    Public Function EntropyOfBlock(ByVal bytes() As Byte) As Double
        Dim intC As Integer
        Dim intSum As Integer
        Dim sngPi As Double
        Dim sngHxi As Double = 0.0
        For intC = 0 To 511
            intSum += bytes(intC)
        Next
        If intSum = 0 Then
            Return 0.0
        End If
        For intC = 0 To 511
            sngPi = bytes(intC) / intSum
            If sngPi <= 0 Then
                'Debug.Print("0 appears")
                Continue For
            End If
            sngHxi += -sngPi * Math.Log(sngPi, 2)
        Next
        Return sngHxi
    End Function

    Public Function CalCulateFirstX(ByVal bytes() As Byte, ByVal intX As Integer) As Double
        Dim intC As Integer
        Dim intSum As Integer
        Dim sngPi As Double
        Dim sngHxi As Double = 0.0
        For intC = 0 To intX
            intSum += bytes(intC)
        Next
        If intSum = 0 Then
            Return 0.0
        End If
        For intC = 0 To intX
            sngPi = bytes(intC) / intSum
            If sngPi <= 0 Then
                'Debug.Print("0 appears")
                Continue For
            End If
            sngHxi += -sngPi * Math.Log(sngPi, 2)
        Next
        Return sngHxi
    End Function

    Public Function CalCulateLastX(ByVal bytes() As Byte, ByVal intX As Integer) As Double
        Dim intC As Integer
        Dim intSum As Integer
        Dim sngPi As Double
        Dim sngHxi As Double = 0.0
        For intC = intX To 511
            intSum += bytes(intC)
        Next
        If intSum = 0 Then
            Return 0.0
        End If
        For intC = intX To 511
            sngPi = bytes(intC) / intSum
            If sngPi <= 0 Then
                'Debug.Print("0 appears")
                Continue For
            End If
            sngHxi += -sngPi * Math.Log(sngPi, 2)
        Next
        Return sngHxi
    End Function

    Public Function IsTxtFile(ByVal bytes() As Byte) As Boolean
        Dim intC As Integer = 0
        Dim blnRet As Boolean = True
        For intC = 0 To 511
            If bytes(intC) < 9 Or bytes(intC) > 122 Then
                blnRet = False
                Exit For
            End If
        Next
        Return blnRet
    End Function

    Public Function IsMpgH(ByVal byteBlock As Byte()) As Boolean
        Dim byteB(4) As Byte
        Dim intC As Integer = 0
        Dim blnRet As Boolean = False
        Try
            Array.Copy(byteBlock, intC, byteB, 0, 4)
            If CompareEqual(byteMpgH1, byteB) Then
                blnRet = True
            ElseIf CompareEqual(byteMpgH2, byteB) Then
                blnRet = True
            End If
        Catch ex As Exception
            Debug.Print(ex.Message)
        End Try
        Return blnRet
    End Function


    Public Function CompareEqual(ByVal b1 As Byte(), ByVal b2 As Byte()) As Boolean
        Dim blnRet As Boolean = True
        For intc As Integer = 0 To b1.Length - 1
            If b1(intc) <> b2(intc) Then
                blnRet = False
                Exit For
            End If
        Next
        Return blnRet
    End Function


    Public Function CountMpgT(ByVal byteBlock As Byte()) As Integer
        Dim byteB(4) As Byte
        Dim intC As Integer
        Dim intRet As Integer = 0
        Try
            While intC < 497
                If byteBlock(intC) = 255 Then
                    Array.Copy(byteBlock, intC, byteB, 0, 4)
                    If CompareEqual(byteMpgT1, byteB) Or CompareEqual(byteMpgT2, byteB) Then
                        intRet += 1
                        intC += 4
                    Else
                        intC += 1
                    End If
                Else
                    intC += 1
                End If
            End While
        Catch ex As Exception
            Debug.Print(ex.Message)
        End Try
        Return intRet
    End Function

    Public Function ContainZipH(ByVal byteBlock As Byte()) As Boolean
        Dim byteB(4) As Byte
        Dim intC As Integer = 0
        Dim blnRet As Boolean = False
        Try
            While intC < 508
                If byteBlock(intC) = 50 And byteBlock(intC + 1) = 75 Then
                    Array.Copy(byteBlock, intC, byteB, 0, 4)
                    If CompareEqual(byteZipH, byteB) Then
                        blnRet = True
                        Exit While
                    Else
                        intC += 1
                    End If
                Else
                    intC += 1
                End If

            End While
        Catch ex As Exception
            Debug.Print(ex.Message)
        End Try
        Return blnRet
    End Function

    Public Function ContainDocH(ByVal byteBlock As Byte()) As Boolean
        Dim byteB(6) As Byte
        Dim intC As Integer = 0
        Dim blnRet As Boolean = False
        Try
            While intC < 506
                If byteBlock(intC) = 208 And byteBlock(intC + 1) = 207 Then
                    Array.Copy(byteBlock, intC, byteB, 0, 6)
                    If CompareEqual(byteZipH, byteB) Then
                        blnRet = True
                        Exit While
                    Else
                        intC += 1
                    End If
                Else
                    intC += 1
                End If

            End While
        Catch ex As Exception
            Debug.Print(ex.Message)
        End Try

        Return blnRet
    End Function

    Public Function CountJpegH(ByVal byteBlock As Byte(), ByVal JpegH As Byte(), ByRef intMarkerPosition As Integer) As Integer
        Dim byteB(6) As Byte
        Dim intC As Integer = 0
        Dim intRet As Integer = 0
        Dim intDataBlock As Integer
        intMarkerPosition = 0
        Try
            While intC < 508
                If byteBlock(intC) = 255 And byteBlock(intC + 1) = 216 Then
                    Array.Copy(byteBlock, intC, byteB, 0, 6)
                    If CompareEqual(JpegH, byteB) Then
                        intRet += 1
                        intC += 20
                        If byteBlock(intC) = 255 Then
                            intC += 2
                            intDataBlock = byteBlock(intC) * 256 + byteBlock(intC + 1)
                            If intDataBlock + intC > 512 Then
                                intMarkerPosition = intDataBlock + intC
                                Exit While
                            Else
                                intC += intDataBlock
                            End If
                        End If
                    Else
                        intC += 1
                    End If
                Else
                    If intRet > 0 Then
                        If byteBlock(intC) = 255 Then
                            intC += 2
                            intDataBlock = byteBlock(intC) * 256 + byteBlock(intC + 1)
                            If intDataBlock + intC > 512 Then
                                intMarkerPosition = intDataBlock + intC
                                Exit While
                            Else
                                intC += intDataBlock
                            End If
                        Else
                            intC += 1
                        End If
                    Else
                        intC += 1
                    End If

                End If
            End While
        Catch ex As Exception
            Debug.Print(ex.Message)
        End Try

        Return intRet
    End Function

    Public Function IsJpegH(ByVal byteBlock As Byte()) As Boolean
        Dim byteB(6) As Byte
        Dim intC As Integer = 0
        Dim blnRet As Boolean = False
        Dim TiffH() As Byte = {255, 216, 255, 224, 0, 16}
        Try
            Array.Copy(byteBlock, intC, byteB, 0, 6)
            If CompareEqual(TiffH, byteB) Then
                blnRet = True
            End If

        Catch ex As Exception
            Debug.Print(ex.Message)
        End Try
        Return blnRet
    End Function

    Public Function FindHeadPos(ByVal byteBlock As Byte()) As Integer
        Dim byteB(6) As Byte
        Dim intC As Integer = 0
        Dim intRet As Integer
        While intC < 508
            If byteBlock(intC) = 255 And byteBlock(intC + 1) = 216 Then
                Array.Copy(byteBlock, intC, byteB, 0, 6)
                If CompareEqual(byteJpegH, byteB) Then
                    intRet = intC
                    Exit While
                End If
            Else
                intC += 1
            End If
        End While
        Return intRet
    End Function
    Public Function CountJpegT(ByVal byteBlock As Byte(), ByVal JpegT As Byte()) As Integer
        Dim byteB(3) As Byte
        Dim intC As Integer
        Dim intRet As Integer = 0
        Try

            While intC < 498
                If byteBlock(intC) = 255 And byteBlock(intC + 1) = 217 Then
                    If byteBlock(intC) = 255 And byteBlock(intC + 1) = 217 And byteBlock(intC + 2) = 255 And byteBlock(intC + 3) = 219 Then
                        intC += 4
                    ElseIf byteBlock(intC) = 255 And byteBlock(intC + 1) = 217 And byteBlock(intC + 2) = 199 And byteBlock(intC + 3) = 143 Then
                        intC += 4
                    ElseIf IsInPairOfBar(byteBlock, intC) Then
                        intC += 2
                    Else
                        intRet += 1
                        intC += 2
                    End If
                Else
                    intC += 1
                End If
            End While
        Catch ex As Exception
            Debug.Print(ex.Message)
        End Try
        Return intRet
    End Function

    Public Function IsInPairOfBar(ByVal byteBlock As Byte(), ByVal intC As Integer) As Boolean
        Dim intFirstBar As Integer = 1
        Dim intSecondBar As Integer = 1
        Dim blnFirstBar, blnSecondBar As Boolean
        While intFirstBar < 35
            If intC - intFirstBar < 0 Then
                Exit While
            End If
            If byteBlock(intC - intFirstBar) > 126 And byteBlock(intC - intFirstBar) < 160 Then
                blnFirstBar = True
            End If
            intFirstBar += 1
        End While
        While intSecondBar < 35
            If intC + intSecondBar > 512 Then
                Exit While
            End If
            If byteBlock(intC + intSecondBar) > 126 And byteBlock(intC + intSecondBar) < 160 Then
                blnSecondBar = True
            End If
            intSecondBar += 1
        End While
        Return blnFirstBar And blnSecondBar
    End Function

    Public Function IsJpegBody(ByVal dbl As Double) As Boolean
        If dbl > 6.5 And dbl < 8.8 Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Function getTailPos(ByVal byteBlock() As Byte) As Integer
        Dim intC As Integer
        Dim byteB(2) As Byte
        Try
            While intC < 511
                If byteBlock(intC) = 255 Then
                    Array.Copy(byteBlock, intC, byteB, 0, 2)
                    If CompareEqual(byteJpegT, byteB) Then
                        intC += 2
                        Exit While
                    Else
                        intC += 1
                    End If
                Else
                    intC += 1
                End If
            End While
        Catch ex As Exception
            Debug.Print(ex.Message)
        End Try
        Return intC
    End Function
End Module
