Imports System.IO

Public Class MyWorker
    Public Class CurrentState
        Public strStatus As String
        Public span As TimeSpan
        Public intMax As Integer
        Public intIncrease As Integer
        Public blnTimerOn As Boolean
    End Class
    Public mstrFile As String
    Public mstrDirectory As String
    Public Sub FindJpeg(ByVal worker As System.ComponentModel.BackgroundWorker, _
        ByVal e As System.ComponentModel.DoWorkEventArgs)
        Dim startTime As DateTime
        startTime = DateTime.Now()
        Dim state As New CurrentState
        state.intMax = 0
        state.intIncrease = 0
        Try
            Dim objFileStream As New _
            FileStream(mstrFile, FileMode.Open, FileAccess.Read, FileShare.Read)
            'FileStream("C:\VCPrj\dfrws-2007-challenge\dfrws-2007-challenge.img", FileMode.Open, FileAccess.Read, FileShare.Read)
            Dim bytes(512) As Byte
            Dim intCount As Integer = 0
            state.strStatus = "Importing Policyinfo..."
            state.span = DateTime.Now.Subtract(startTime)
            state.intMax = 677678
            worker.ReportProgress(0, state)
            Dim dblEntropySum As Double = 0.0
            Dim dblMaxEntropy As Double = 0.0
            Dim dblMinEntropy As Double = 10.0
            Dim dblTemp As Double
            Dim sngEntropy(677678) As Double
            Dim dblF128Etp(677678) As Double
            Dim dblF64Etp(677678) As Double
            Dim dblF32Etp(677678) As Double
            Dim dblL128Etp(677678) As Double
            Dim dblL64Etp(677678) As Double
            Dim dblL32Etp(677678) As Double
            Dim intBlockTaken(677678) As Integer
            Dim intJpegHFound As Integer
            Dim intMarkerPosition As Integer = 0
            Dim intJpegHCount As Integer = 0
            Dim objJPegFile As JpegFile
            Dim jPegFiles As New Queue(Of JpegFile)
            Dim objJPegBody As JpegBody

            While (objFileStream.Read(bytes, 0, 512))
                dblTemp = EntropyOfBlock(bytes)
                dblEntropySum += dblTemp
                If dblTemp > 0 Then
                    If dblTemp > dblMaxEntropy Then
                        dblMaxEntropy = dblTemp
                    End If
                    If dblTemp < dblMinEntropy Then
                        dblMinEntropy = dblTemp
                    End If
                End If
                sngEntropy(intCount) = dblTemp
                dblF128Etp(intCount) = CalCulateFirstX(bytes, 127)
                dblF64Etp(intCount) = CalCulateFirstX(bytes, 63)
                dblF32Etp(intCount) = CalCulateFirstX(bytes, 31)
                dblL128Etp(intCount) = CalCulateLastX(bytes, 384)
                dblL64Etp(intCount) = CalCulateLastX(bytes, 448)
                dblL32Etp(intCount) = CalCulateLastX(bytes, 480)
                If IsTxtFile(bytes) Then
                    intBlockTaken(intCount) = 3 '0=possible jpeg block, 1=taken by carving, 2=empty block, 3= text block
                ElseIf dblTemp = 0.0 Then
                    intBlockTaken(intCount) = 2
                ElseIf IsMpgH(bytes) Then
                    intBlockTaken(intCount) = 4 'mpg header block
                ElseIf CountMpgT(bytes) > 0 Then
                    intBlockTaken(intCount) = 5 'mpg tail block
                ElseIf ContainZipH(bytes) Then
                    intBlockTaken(intCount) = 6 'Zip header block
                ElseIf ContainDocH(bytes) Then
                    intBlockTaken(intCount) = 7 'Doc header block
                ElseIf dblTemp > 8.85 Then
                    intBlockTaken(intCount) = 8 ' impossible jpeg block, we see >>>>>>> all the way
                Else
                    intBlockTaken(intCount) = 0
                End If
                intJpegHFound = CountJpegH(bytes, byteJpegH, intMarkerPosition)
                If intJpegHFound > 0 Then
                    intJpegHCount += 1
                    objJPegFile = New JpegFile
                    objJPegFile.intHeaderCount = intJpegHFound
                    objJPegFile.header.intNumber = intJpegHCount
                    objJPegFile.header.intBlockNumber = intCount
                    objJPegFile.header.intMarkerPosition = intMarkerPosition
                    If IsJpegH(bytes) Then
                        objJPegFile.header.lngPosition = intCount * 512
                        Array.Copy(bytes, 0, objJPegFile.header.bteBlock, 0, 512)
                        intBlockTaken(intCount) = 1
                        objJPegFile.header.dblEntropy = dblTemp
                        objJPegFile.header.dblPreEntropy = sngEntropy(intCount)
                        jPegFiles.Enqueue(objJPegFile)
                    Else
                        Dim intHeaderPos As Integer = FindHeadPos(bytes)
                        objJPegFile.header.lngPosition = intCount * 512 + intHeaderPos
                        Array.Copy(bytes, intHeaderPos, objJPegFile.header.bteBlock, 0, 512 - intHeaderPos)
                        intBlockTaken(intCount) = 1
                        objJPegFile.header.dblEntropy = dblTemp
                        objJPegFile.header.dblPreEntropy = sngEntropy(intCount)
                        jPegFiles.Enqueue(objJPegFile)
                    End If
                End If
                intCount += 1
                If intCount Mod 500 = 0 Then
                    state.strStatus = intCount.ToString & " of " & state.intMax & " blocks."
                    state.span = DateTime.Now.Subtract(startTime)
                    state.intIncrease = 500
                    worker.ReportProgress(0, state)
                End If
            End While
            Debug.Print("C:\VCPrj\CarveBytes\2bytes.jpg Max Entropy= " & dblMaxEntropy & " Min = " & dblMinEntropy & " Average = " & dblEntropySum / intCount)
            state.strStatus = "Carving files..."
            state.span = DateTime.Now.Subtract(startTime)
            state.intMax = jPegFiles.Count
            worker.ReportProgress(0, state)
            Dim intFileNum As Integer = 0
            For Each objJPegFile In jPegFiles
                objJPegFile.header.dblNxtEntropy = sngEntropy(objJPegFile.header.intBlockNumber + 1)
                While objJPegFile.FindNextBlock(objFileStream, sngEntropy, intBlockTaken, _
                        dblF128Etp, dblF64Etp, dblF32Etp, dblL128Etp, dblL64Etp, dblL32Etp) ' IsJpegBody(bytes, objJPegFile)
                    objJPegBody = New JpegBody
                    objJPegBody.intNumber = objJPegFile.bodies.Count + 1
                    objJPegBody.intBlockNumber = objJPegFile.lngCurrentPosition / 512
                    intBlockTaken(objJPegBody.intBlockNumber) = 1
                    objFileStream.Read(objJPegBody.bteBlock, 0, 512)
                    intJpegHFound = CountJpegH(objJPegBody.bteBlock, byteJpegH, intMarkerPosition)
                    objJPegFile.intHeaderCount += intJpegHFound
                    objJPegBody.dblEntropy = sngEntropy(objJPegBody.intBlockNumber)
                    If objJPegBody.intBlockNumber > 677677 Then
                        objJPegBody.dblNxtEntropy = sngEntropy(0)
                    Else
                        objJPegBody.dblNxtEntropy = sngEntropy(objJPegBody.intBlockNumber + 1)
                    End If
                    objJPegFile.bodies.Enqueue(objJPegBody)

                End While
                intFileNum += 1
                state.strStatus = intFileNum.ToString & " of " & state.intMax & " blocks."
                state.span = DateTime.Now.Subtract(startTime)
                state.intIncrease = 1
                worker.ReportProgress(0, state)
            Next
            Dim dblTotalLength As Double
            Dim intTailPos, intBodyCount As Integer
            For Each objJPegFile In jPegFiles
                dblTotalLength = 512
                intBodyCount = 0
                For Each objJPegBody In objJPegFile.bodies
                    intBodyCount += 1
                    If intBodyCount = objJPegFile.bodies.Count Then
                        intTailPos = getTailPos(objJPegBody.bteBlock)
                        dblTotalLength += intTailPos
                    Else
                        dblTotalLength += 512
                    End If
                Next
                objJPegFile.lngFileLength = dblTotalLength
            Next
            For Each objJPegFile In jPegFiles
                If objJPegFile.writeOut(sngEntropy, mstrDirectory) Then

                End If
            Next
            state.strStatus = "Jpeg header" & intJpegHCount.ToString
            state.span = DateTime.Now.Subtract(startTime)
            worker.ReportProgress(0, state)

            objFileStream.Dispose()

        Catch ex As Exception
            Debug.Print("ex=" & ex.Message)
        End Try
    End Sub
End Class
