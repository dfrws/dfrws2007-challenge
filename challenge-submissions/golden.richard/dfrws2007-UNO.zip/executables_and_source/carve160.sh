dd if=dfrws-2007-challenge.img bs=512  skip=242124   count=195    > chunk-160_001
cp chunk-160_001 head-160_001.mp3
dd if=dfrws-2007-challenge.img bs=512  skip=242319   count=1 > block-0003B28F
dd if=dfrws-2007-challenge.img bs=512  skip=242319   count=6937   > chunk-160_002
cp chunk-160_002 chunk-160_002.mp3
dd if=dfrws-2007-challenge.img bs=512  skip=242318   count=1 > block-0003B28E
dd if=dfrws-2007-challenge.img bs=512  skip=249256   count=1 > block-0003CDA8
dd if=dfrws-2007-challenge.img bs=512  skip=249256   count=2638   > chunk-160_003
cp chunk-160_003 chunk-160_003.mp3
dd if=dfrws-2007-challenge.img bs=512  skip=249255   count=1 > block-0003CDA7
dd if=dfrws-2007-challenge.img bs=512  skip=251894   count=1 > block-0003D7F6
dd if=dfrws-2007-challenge.img bs=512  skip=499510   count=2619   > chunk-160_004
cp chunk-160_004 chunk-160_004.mp3
dd if=dfrws-2007-challenge.img bs=512  skip=499509   count=1 > block-00079F35
dd if=dfrws-2007-challenge.img bs=512  skip=502129   count=1 > block-0007A971
dd if=dfrws-2007-challenge.img bs=512  skip=502897   count=5829   > chunk-160_005
cp chunk-160_005 head-160_005.mp3
dd if=dfrws-2007-challenge.img bs=512  skip=508726   count=1 > block-0007C336
cat chunk-160_001 chunk-160_003 > chunk-160_001-160_003
cat chunk-160_001-160_003 chunk-160_002 > chunk-160_001-160_003-160_002.mp3
cat chunk-160_001 chunk-160_003 > chunk-160_001-160_003.mp3
cat chunk-160_005 chunk-160_004 > chunk-160_005-160_004.mp3
cat chunk-160_003 chunk-160_002 > chunk-160_003-160_002.mp3
