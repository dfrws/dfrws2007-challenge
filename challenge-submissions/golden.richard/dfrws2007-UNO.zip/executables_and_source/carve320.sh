dd if=dfrws-2007-challenge.img bs=512  skip=71439    count=592    > chunk-320_001
cp chunk-320_001 chunk-320_001.mp3
dd if=dfrws-2007-challenge.img bs=512  skip=71438    count=1 > block-0001170E
dd if=dfrws-2007-challenge.img bs=512  skip=72031    count=1 > block-0001195F
dd if=dfrws-2007-challenge.img bs=512  skip=72033    count=593    > chunk-320_002
cp chunk-320_002 head-320_002.mp3
dd if=dfrws-2007-challenge.img bs=512  skip=72626    count=1 > block-00011BB2
dd if=dfrws-2007-challenge.img bs=512  skip=156545   count=7552   > chunk-320_003
cp chunk-320_003 head-320_003.mp3
dd if=dfrws-2007-challenge.img bs=512  skip=164097   count=1 > block-00028101
dd if=dfrws-2007-challenge.img bs=512  skip=165740   count=5931   > chunk-320_004
cp chunk-320_004 chunk-320_004.mp3
dd if=dfrws-2007-challenge.img bs=512  skip=165739   count=1 > block-0002876B
dd if=dfrws-2007-challenge.img bs=512  skip=171671   count=1 > block-00029E97
dd if=dfrws-2007-challenge.img bs=512  skip=229424   count=2086   > chunk-320_005
cp chunk-320_005 head-320_005.mp3
dd if=dfrws-2007-challenge.img bs=512  skip=231510   count=1 > block-00038856
dd if=dfrws-2007-challenge.img bs=512  skip=232294   count=219    > chunk-320_006
cp chunk-320_006 chunk-320_006.mp3
dd if=dfrws-2007-challenge.img bs=512  skip=232293   count=1 > block-00038B65
dd if=dfrws-2007-challenge.img bs=512  skip=232513   count=1 > block-00038C41
dd if=dfrws-2007-challenge.img bs=512  skip=440423   count=4117   > chunk-320_007
cp chunk-320_007 head-320_007.mp3
dd if=dfrws-2007-challenge.img bs=512  skip=444540   count=1 > block-0006C87C
cp chunk-320_002 chunk-320_002--10--320-001
cp chunk-320_002 chunk-320_002--01--320-001
cat chunk-320_002 block-00011BB2 chunk-320_001 > chunk-320_002--10--320-001.mp3
cat chunk-320_002 block-0001170E chunk-320_001 > chunk-320_002--01--320-001.mp3
cp chunk-320_003 chunk-320_003--10--320-004
cp chunk-320_003 chunk-320_003--01--320-004
cat chunk-320_003 block-00028101 chunk-320_004 > chunk-320_003--10--320-004.mp3
cat chunk-320_003 block-0002876B chunk-320_004 > chunk-320_003--01--320-004.mp3
cp chunk-320_005 chunk-320_005--10--320-006
cp chunk-320_005 chunk-320_005--01--320-006
cat chunk-320_005 block-00038856 chunk-320_006 > chunk-320_005--10--320-006.mp3
cat chunk-320_005 block-00038B65 chunk-320_006 > chunk-320_005--01--320-006.mp3
