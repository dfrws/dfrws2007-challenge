#!/usr/bin/perl

use IO::Seekable;

$file = 'dfrws-2007-challenge.img';

$recsize = 512;

$recno = 0;

open(FH, $file);

$footer = 0;

$header = 0;

$xref = 0;

#seek(FH, $addr, SEEK_SET) or die "Seek error: $!\n";

#$line = read(FH, $buffer, $recsize) or die "Couldn't read from HANDLE : $!\n";

#$pos = tell(FH); print "I'm $pos bytes from the start of DATAFILE.\n";

#$string = <FH>

while(<FH>) {
	
	$address = $recsize * $recno; 
	seek(FH, $address, 0) or die "seek:$!"; 
	read(FH, $buffer, $recsize);
	
	if($buffer =~ /%PDF/) {
		$header = $header + 1;
		print "header $header at $address\n";
		
	}
	if($buffer =~ /%%EOF/) {
		$footer = $footer + 1;
		print "footer $footer at $address\n";
		
	}
	if($buffer =~ /startxref/) {
		$xref = $xref + 1;
		print "xref $xref at $address\n";
		
	}
	$recno = $recno + 1;
}

close (FH);



	