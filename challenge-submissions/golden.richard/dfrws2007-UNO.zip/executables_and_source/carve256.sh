dd if=dfrws-2007-challenge.img bs=512  skip=176274   count=6157   > chunk-256_001
cp chunk-256_001 head-256_001.mp3
dd if=dfrws-2007-challenge.img bs=512  skip=182431   count=1 > block-0002C89F
dd if=dfrws-2007-challenge.img bs=512  skip=182432   count=512    > chunk-256_002
cp chunk-256_002 chunk-256_002.mp3
dd if=dfrws-2007-challenge.img bs=512  skip=182431   count=1 > block-0002C89F
dd if=dfrws-2007-challenge.img bs=512  skip=182944   count=1 > block-0002CAA0
